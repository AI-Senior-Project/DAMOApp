"""
API ของหน้าแชทกับผู้ช่วย AI (qwen2.5:7b บน Ollama) — ใช้ได้เฉพาะเจ้าของร้าน
  GET  /api/chat                       ข้อความในแชทล่าสุดของร้าน
  POST /api/chat                       ส่งข้อความ {text}
  POST /api/chat/action/{id_action}    ยืนยัน / ยกเลิกรายการที่ AI ขอทำ {confirm: true|false}
  POST /api/chat/new                   เริ่มแชทใหม่
  POST /api/chat/upload                แนบรูป {name, data(base64)} → คืนที่อยู่ /uploads/...

ขั้นตอน (เหมือน Ai_shop/assistant.py เดิม แต่ย้ายมาเป็นเว็บ):
1. บันทึกข้อความผู้ใช้ลง message_box แล้วส่งให้โมเดลพร้อมรายการเครื่องมือ
2. ถ้าโมเดลขอเรียกเครื่องมือ
   - แบบอ่าน   ทำทันที
   - แบบแก้ไข  ตรวจค่า → บันทึกลง ai_action_log เป็น pending → หน้าเว็บขึ้นการ์ดให้กดยืนยัน
     กดยืนยัน → ทำจริง (success) / กดยกเลิก หรือพังตอนทำ → failed
3. ส่งผลกลับให้โมเดลสรุปเป็นคำตอบ แล้วบันทึกคำตอบลง message_box

ประวัติที่ส่งให้โมเดลอ่านจาก message_box ทุกครั้ง (ปิดเซิร์ฟเวอร์แล้วเปิดใหม่ก็คุยต่อได้)
  role=assistant ที่ขึ้นต้นด้วย TOOL_MARK = ข้อความที่โมเดลขอเรียกเครื่องมือ (ไม่แสดงในหน้าแชท)
  role=tool      = ผลของเครื่องมือ เก็บเป็น JSON {name, result, id_action, summary, status}
"""
import base64
import calendar
import datetime
import hashlib
import json
import re
import uuid
from pathlib import Path
from types import SimpleNamespace

from fastapi import APIRouter, Request
from pydantic import BaseModel

import ai_tools as tools
import config
from common import error
from db import get_db
from products import get_owner

router = APIRouter()

MODEL = getattr(config, "AI_MODEL", "qwen2.5:7b")
OLLAMA_HOST = getattr(config, "OLLAMA_HOST", "http://127.0.0.1:11434")
OPTIONS = {"temperature": 0.3, "top_p": 0.8, "repeat_penalty": 1.0, "num_ctx": 8192}
MAX_ROUNDS = 5      # กันโมเดลเรียกเครื่องมือวนไม่จบ
KEEP_TURNS = 6      # ส่งประวัติให้โมเดลแค่กี่คำสั่งล่าสุด
MAX_TEXT = 2000
SHOW_LAST = 200     # หน้าแชทแสดงย้อนหลังกี่ข้อความ
TOOL_MARK = "⟦tool_calls⟧"
PROMPT_FILE = Path(__file__).resolve().parent / "ai_prompt.txt"
THAI_WEEKDAYS = ["จันทร์", "อังคาร", "พุธ", "พฤหัสบดี", "ศุกร์", "เสาร์", "อาทิตย์"]

MAX_IMAGE_BYTES = 5 * 1024 * 1024
IMAGE_EXT = {"jpeg": ".jpg", "png": ".png", "gif": ".gif", "webp": ".webp"}


def to_json(data):
    return json.dumps(data, ensure_ascii=False, default=str)


def load_prompt():
    text = PROMPT_FILE.read_text(encoding="utf-8-sig").strip()
    return text, hashlib.sha1(text.encode("utf-8")).hexdigest()[:8]   # version = ลายนิ้วมือของ prompt


def system_prompt(ctx, prompt):
    today = datetime.date.today()
    tomorrow = today + datetime.timedelta(days=1)
    month_end = today.replace(day=calendar.monthrange(today.year, today.month)[1])
    branch = ctx["branch_name"] if ctx["id_branch"] else "ทุกสาขา (ดูจำนวนรวม เพิ่ม/ลดสต็อกไม่ได้จนกว่าจะเลือกสาขา)"
    return (
        f"{prompt}\n\n"
        f"ร้านที่ดูแลอยู่: {ctx['brand']}\n"
        f"สาขาที่เลือกอยู่: {branch}\n"
        f"วันนี้คือวัน{THAI_WEEKDAYS[today.weekday()]}ที่ {today:%Y-%m-%d} "
        f"พรุ่งนี้คือ {tomorrow:%Y-%m-%d} สิ้นเดือนนี้คือ {month_end:%Y-%m-%d}\n"
        f"เวลาใส่วันที่ให้เครื่องมือ ใช้รูปแบบ YYYY-MM-DD และใช้ปี ค.ศ. เสมอ"
    )


# =====================================================================
# แปลงข้อความ (ย้ายมาจาก assistant.py เดิม)
# =====================================================================
THAI_DIGITS = {"ศูนย์": 0, "หนึ่ง": 1, "เอ็ด": 1, "สอง": 2, "ยี่": 2, "สาม": 3, "สี่": 4,
               "ห้า": 5, "หก": 6, "เจ็ด": 7, "แปด": 8, "เก้า": 9}
THAI_MULTIPLIERS = {"สิบ": 10, "ร้อย": 100, "พัน": 1000, "หมื่น": 10000, "แสน": 100000}
COUNT_UNITS = ["ขวด", "ชิ้น", "ซอง", "ห่อ", "กล่อง", "กระป๋อง", "แพ็ค", "แพ็ก", "โหล", "ลัง",
               "ถุง", "แผ่น", "อัน", "บาท", "เปอร์เซ็นต์", "วัน", "แก้ว", "ชุด", "ก้อน", "ลูก",
               "ตัว", "ใบ", "หน่วย", "กิโล", "ขีด", "คู่", "เม็ด", "ถ้วย"]
_NUMBER_WORDS = sorted(list(THAI_DIGITS) + list(THAI_MULTIPLIERS), key=len, reverse=True)
_THAI_NUMBER = re.compile("((?:" + "|".join(_NUMBER_WORDS) + ")+)(?=\\s*(?:" + "|".join(COUNT_UNITS) + "))")
_NUMBER_TOKEN = re.compile("|".join(_NUMBER_WORDS))


def _thai_words_to_int(words):
    total, current, last_was_digit = 0, None, False
    for token in _NUMBER_TOKEN.findall(words):
        if token in THAI_DIGITS:
            if last_was_digit:
                return None          # "สามสี่" = ประมาณ 3-4 ไม่แปลง
            current, last_was_digit = THAI_DIGITS[token], True
        else:
            total += (1 if current is None else current) * THAI_MULTIPLIERS[token]
            current, last_was_digit = None, False
    return total + (current or 0)


def normalize_numbers(text):
    """แปลงเลขคำไทยที่ตามด้วยหน่วยนับเป็นตัวเลข เช่น ยี่สิบสี่ขวด → 24 ขวด"""
    def replace(match):
        value = _thai_words_to_int(match.group(1))
        return match.group(1) if value is None else f" {value} "
    return re.sub(r" {2,}", " ", _THAI_NUMBER.sub(replace, text)).strip()


AGREE = re.compile(
    r"^(?:ตกลง|โอเค|ok|okay|ได้|ใช่|เอา|ยืนยัน|จัดไป|ตามนั้น|y|yes)"
    r"(?:\s*(?:เลย|ตามนั้น|ตามที่เสนอ|ตามนี้|ครับ|ค่ะ|คะ|นะ|จ้า|จ้ะ|เลยครับ|เลยค่ะ))*[\s!.]*$", re.I)


def agreed_proposal(history):
    """ผู้ใช้ตอบตกลงสั้น ๆ → คืนข้อความที่ผู้ช่วยเสนอไว้ก่อนหน้า (ตัวเลขในนั้นถือว่าผู้ใช้เห็นแล้ว)"""
    for i in range(len(history) - 1, -1, -1):
        if history[i]["role"] == "user":
            if not AGREE.match(str(history[i]["content"]).strip()):
                return None
            for earlier in reversed(history[:i]):
                if earlier["role"] == "user":
                    return None
                if earlier["role"] == "assistant" and earlier.get("content", "").strip():
                    return earlier["content"]
            return None
    return None


def recent(history):
    starts = [i for i, m in enumerate(history) if m["role"] == "user"]
    if len(starts) <= KEEP_TURNS:
        return history
    return history[starts[-KEEP_TURNS]:]


def extract_text_tool_calls(content):
    """qwen บางครั้งพิมพ์ {"name": ..., "arguments": {...}} เป็นข้อความแทนการเรียกจริง"""
    known = set(tools.READ_TOOLS) | set(tools.WRITE_TOOLS)
    decoder = json.JSONDecoder()
    calls, pieces, position = [], [], 0
    for match in re.finditer(r"\{\s*\"name\"", content):
        if match.start() < position:
            continue
        try:
            data, end = decoder.raw_decode(content, match.start())
        except ValueError:
            continue
        name = data.get("name") if isinstance(data, dict) else None
        arguments = data.get("arguments", {}) if isinstance(data, dict) else None
        if name in known and isinstance(arguments, dict):
            calls.append(SimpleNamespace(function=SimpleNamespace(name=name, arguments=arguments)))
            pieces.append(content[position:match.start()])
            position = end
    if not calls:
        return content, []
    pieces.append(content[position:])
    return re.sub(r"</?tool_call>|```(?:json)?", "", "".join(pieces)).strip(), calls


FOREIGN_SCRIPT = re.compile(r"[　-ヿ㐀-鿿가-힯＀-￯]+")
ANNOUNCE_ONLY = re.compile(r"เรียก(?:ใช้)?เครื่องมือ|ที่จะ(?:เปลี่ยน|แก้|เพิ่ม|ลด|บันทึก|สร้าง)|(?:จะ|กำลัง)(?:ทำการ|ดำเนินการ)|รอสักครู่")
CALL_NOW = ("เมื่อกี้คุณแค่บอกว่าจะทำ แต่ยังไม่ได้เรียกเครื่องมือจริง ข้อมูลยังไม่ถูกบันทึก "
            "ถ้าข้อมูลครบแล้วให้เรียกเครื่องมือเลยตอนนี้ ไม่ต้องพิมพ์บอกก่อน ถ้าข้อมูลยังไม่ครบให้ถามผู้ใช้สั้นๆ")
THAI_KEY_ANSWERS = {"ั": "ตกลง", "ื": "ไม่"}   # แป้นไทยพิมพ์ y เป็น "ั" และ n เป็น "ื"


# =====================================================================
# Ollama
# =====================================================================
class AIError(Exception):
    pass


def ollama_chat(messages, use_tools=True):
    try:
        import ollama
    except ImportError:
        raise AIError("ยังไม่ได้ติดตั้งตัวต่อ Ollama ให้รัน  py -m pip install ollama  แล้วเปิดเซิร์ฟเวอร์ใหม่") from None
    try:
        client = ollama.Client(host=OLLAMA_HOST)
        kwargs = {"tools": tools.TOOL_SCHEMAS} if use_tools else {}
        return client.chat(model=MODEL, messages=messages, options=OPTIONS, **kwargs).message
    except Exception as e:
        raise AIError(f"ต่อผู้ช่วย AI ไม่ได้ เช็กว่าเปิด Ollama และมีโมเดล {MODEL} แล้ว ({type(e).__name__})") from None


# =====================================================================
# ฐานข้อมูล
# =====================================================================
def get_ctx(cur, user):
    cur.execute("SELECT name_brand FROM business WHERE id_business = %s", (user["id_business"],))
    brand = cur.fetchone()["name_brand"]
    name = None
    if user.get("id_branch"):
        cur.execute("SELECT branch_name FROM branch WHERE id_branch = %s", (user["id_branch"],))
        row = cur.fetchone()
        name = row["branch_name"] if row else None
    return {"user": user, "id_business": user["id_business"], "id_branch": user.get("id_branch") if name else None,
            "branch_name": name or "ทุกสาขา", "brand": brand}


def current_conversation(cur, id_business, create=True):
    cur.execute("SELECT MAX(id_conversation) AS id FROM conversation WHERE id_business = %s", (id_business,))
    row = cur.fetchone()
    if row["id"] or not create:
        return row["id"]
    cur.execute("INSERT INTO conversation (id_business) VALUES (%s)", (id_business,))
    return cur.lastrowid


def save_message(cur, conv, role, content):
    cur.execute("INSERT INTO message_box (id_conversation, role, content) VALUES (%s, %s, %s)", (conv, role, content))
    return cur.lastrowid


def load_rows(cur, conv, limit=400):
    cur.execute(
        """SELECT * FROM (SELECT id_message, role, content, carete_date FROM message_box
                          WHERE id_conversation = %s ORDER BY id_message DESC LIMIT %s) x
           ORDER BY id_message""",
        (conv, limit),
    )
    return cur.fetchall()


def parse_tool(content):
    try:
        data = json.loads(content)
        return data if isinstance(data, dict) else None
    except ValueError:
        return None


def model_history(rows):
    """แถวใน message_box → ข้อความที่ส่งให้โมเดล"""
    out = []
    for r in rows:
        c = r["content"]
        if r["role"] == "user":
            out.append({"role": "user", "content": normalize_numbers(THAI_KEY_ANSWERS.get(c.strip(), c))})
        elif r["role"] == "assistant":
            if c.startswith(TOOL_MARK):
                data = json.loads(c[len(TOOL_MARK):])
                out.append({"role": "assistant", "content": data.get("text", ""), "tool_calls": data["calls"]})
            else:
                out.append({"role": "assistant", "content": c})
        elif r["role"] == "tool":
            t = parse_tool(c) or {}
            out.append({"role": "tool", "tool_name": t.get("name", ""), "content": to_json(t.get("result", {}))})
    return out


def log_action(cur, id_message, prompt, version, name, arguments, status, summary=None, err=None):
    cur.execute(
        """INSERT INTO ai_action_log (id_message, ai_name, prompt, version, tool_name, arguments, result, error_message, status)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
        (id_message, MODEL, prompt, version, name, to_json(arguments), summary, err, status),
    )
    return cur.lastrowid


# =====================================================================
# หนึ่งรอบการคิดของโมเดล (วนจนได้คำตอบ หรือเจอรายการที่ต้องรอยืนยัน)
# =====================================================================
def run_model(conn, cur, ctx, conv, id_message):
    prompt, version = load_prompt()
    sys_msg = {"role": "system", "content": system_prompt(ctx, prompt)}
    nudge, nudged = [], False

    for _ in range(MAX_ROUNDS):
        history = recent(model_history(load_rows(cur, conv)))
        conn.commit()   # ปล่อย transaction ไว้ระหว่างรอโมเดลคิด
        message = ollama_chat([sys_msg] + history + nudge)
        calls = list(message.tool_calls or [])
        content = message.content or ""
        if not calls:
            content, calls = extract_text_tool_calls(content)

        # บอกว่าจะทำแต่ไม่ได้เรียกจริง → เตือนหนึ่งครั้ง
        if not calls and not nudged and ANNOUNCE_ONLY.search(content):
            nudged = True
            nudge = [{"role": "assistant", "content": content}, {"role": "user", "content": CALL_NOW}]
            continue
        nudge = []

        if not calls:
            reply = content.strip()
            if FOREIGN_SCRIPT.search(reply):   # มีภาษาอื่นปน → ให้ตอบใหม่หนึ่งครั้ง
                again = ollama_chat([sys_msg] + history + [
                    {"role": "assistant", "content": reply},
                    {"role": "user", "content": "คำตอบล่าสุดมีภาษาอื่นปน ช่วยตอบข้อความเดิมใหม่เป็นภาษาไทยล้วน ห้ามมีตัวอักษรจีนหรือญี่ปุ่นแม้แต่ตัวเดียว"},
                ], use_tools=False)
                reply = re.sub(r"[ \t]{2,}", " ", FOREIGN_SCRIPT.sub("", again.content or "")).strip()
            save_message(cur, conv, "assistant", reply or "ขอโทษครับ ยังตอบไม่ได้ ลองพิมพ์ใหม่อีกครั้ง")
            conn.commit()
            return

        tool_calls = [{"function": {"name": c.function.name, "arguments": dict(c.function.arguments or {})}} for c in calls]
        save_message(cur, conv, "assistant", TOOL_MARK + to_json({"text": content, "calls": tool_calls}))

        user_texts = [m["content"] for m in history if m["role"] == "user"]
        proposal = agreed_proposal(history)
        if proposal:
            user_texts.append(proposal)

        pending = False
        for call in tool_calls:
            name, args = call["function"]["name"], call["function"]["arguments"]
            record = {"name": name}
            if name in tools.READ_TOOLS:
                fn = tools.READ_TOOLS[name]
                try:
                    tools.check_arguments(fn, args)
                    record["result"] = fn(ctx, cur, **args)
                except tools.ToolError as e:
                    record["result"] = {"ok": False, "error": str(e)}
            elif name not in tools.WRITE_TOOLS:
                record["result"] = {"ok": False, "error": f"ไม่มีเครื่องมือชื่อ '{name}'"}
            elif pending:
                record["result"] = {"ok": False, "error": "ทำได้ทีละรายการ รอผู้ใช้ยืนยันรายการก่อนหน้าแล้วค่อยเรียกใหม่"}
            else:
                fn = tools.WRITE_TOOLS[name]
                try:
                    tools.check_arguments(fn, args)
                    args = tools.fix_details(name, args, user_texts)
                    args = tools.fix_image_path(name, args, user_texts)
                    summary, _ = fn(ctx, cur, **args)
                    tools.check_user_said(name, args, user_texts)   # กันโมเดลแต่งราคา/ส่วนลด/วันที่เอง
                except tools.ToolError as e:
                    log_action(cur, id_message, prompt, version, name, args, "failed", err=str(e))
                    record["result"] = {"ok": False, "error": str(e)}
                else:
                    record.update(
                        id_action=log_action(cur, id_message, prompt, version, name, args, "pending", summary),
                        summary=summary, status="pending",
                        result={"ok": False, "pending": True, "error": "รอผู้ใช้กดยืนยัน"},
                    )
                    pending = True
            save_message(cur, conv, "tool", to_json(record))
        conn.commit()
        if pending:
            return   # หยุดรอผู้ใช้กดยืนยันในหน้าเว็บ

    save_message(cur, conv, "assistant", "ทำหลายขั้นแล้วยังไม่จบ ลองสั่งทีละอย่างดูครับ")
    conn.commit()


def find_pending(cur, conv):
    """การ์ดที่ยังรอยืนยัน (แถว tool ที่ status = pending)"""
    cur.execute(
        """SELECT id_message, content FROM message_box
           WHERE id_conversation = %s AND role = 'tool' AND content LIKE %s
           ORDER BY id_message DESC""",
        (conv, '%"status": "pending"%'),
    )
    out = []
    for r in cur.fetchall():
        t = parse_tool(r["content"])
        if t and t.get("status") == "pending":
            out.append((r["id_message"], t))
    return out


def resolve(cur, msg_id, record, status, result, err=None, target=None):
    record.update(status=status, result=result)
    if err:
        record["error"] = err
    cur.execute("UPDATE message_box SET content = %s WHERE id_message = %s", (to_json(record), msg_id))
    cur.execute(
        "UPDATE ai_action_log SET status = %s, result = %s, error_message = %s, target_table = %s, target_id = %s WHERE id_action = %s",
        ("success" if status == "success" else "failed", record.get("summary"), err,
         (target or {}).get("target_table"), (target or {}).get("target_id"), record["id_action"]),
    )


def cancel_pending(cur, conv, reason="ผู้ใช้พิมพ์คำสั่งใหม่แทนการยืนยัน"):
    for msg_id, record in find_pending(cur, conv):
        resolve(cur, msg_id, record, "cancelled",
                {"ok": False, "cancelled": True, "error": "ผู้ใช้ไม่ยืนยัน จึงยังไม่ได้ทำรายการนี้"}, reason)


# =====================================================================
# สิ่งที่หน้าเว็บเห็น
# =====================================================================
def display(cur, ctx, conv, err=None):
    rows = load_rows(cur, conv, SHOW_LAST) if conv else []
    items = []
    for r in rows:
        if r["role"] == "user":
            items.append({"role": "user", "text": r["content"], "time": r["carete_date"].strftime("%H:%M")})
        elif r["role"] == "assistant" and not r["content"].startswith(TOOL_MARK):
            items.append({"role": "assistant", "text": r["content"], "time": r["carete_date"].strftime("%H:%M")})
        elif r["role"] == "tool":
            t = parse_tool(r["content"]) or {}
            if t.get("id_action"):
                res = t.get("result") or {}
                items.append({"role": "action", "id_action": t["id_action"], "summary": t.get("summary", ""),
                              "status": t.get("status"), "error": t.get("error") or (None if res.get("ok") else res.get("error"))})
    return {"ok": True, "items": items, "error": err, "model": MODEL,
            "brand": ctx["brand"], "branch": ctx["branch_name"], "id_branch": ctx["id_branch"],
            "pending": any(i["role"] == "action" and i["status"] == "pending" for i in items)}


# =====================================================================
# Endpoints
# =====================================================================
@router.get("/api/chat")
def get_chat(request: Request):
    user = get_owner(request)
    if not user:
        return error("ผู้ช่วย AI ใช้ได้เฉพาะเจ้าของร้าน", 401)
    with get_db() as conn, conn.cursor() as cur:
        ctx = get_ctx(cur, user)
        return display(cur, ctx, current_conversation(cur, user["id_business"], create=False))


class ChatBody(BaseModel):
    text: str


@router.post("/api/chat")
def send_chat(body: ChatBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("ผู้ช่วย AI ใช้ได้เฉพาะเจ้าของร้าน", 401)
    text = body.text.strip()[:MAX_TEXT]
    if not text:
        return error("พิมพ์ข้อความก่อนนะ")
    with get_db() as conn, conn.cursor() as cur:
        ctx = get_ctx(cur, user)
        conv = current_conversation(cur, user["id_business"])
        cancel_pending(cur, conv)
        id_message = save_message(cur, conv, "user", text)
        conn.commit()
        err = None
        try:
            run_model(conn, cur, ctx, conv, id_message)
        except AIError as e:
            conn.rollback()
            err = str(e)
        return display(cur, ctx, conv, err)


class ActionBody(BaseModel):
    confirm: bool


@router.post("/api/chat/action/{id_action}")
def answer_action(id_action: int, body: ActionBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("ผู้ช่วย AI ใช้ได้เฉพาะเจ้าของร้าน", 401)
    with get_db() as conn, conn.cursor() as cur:
        ctx = get_ctx(cur, user)
        conv = current_conversation(cur, user["id_business"], create=False)
        found = [(m, t) for m, t in (find_pending(cur, conv) if conv else []) if t.get("id_action") == id_action]
        if not found:
            return error("รายการนี้ถูกยืนยันหรือยกเลิกไปแล้ว", 404)
        msg_id, record = found[0]
        cur.execute("SELECT id_message, tool_name, arguments FROM ai_action_log WHERE id_action = %s FOR UPDATE", (id_action,))
        act = cur.fetchone()
        args = act["arguments"] if isinstance(act["arguments"], dict) else json.loads(act["arguments"] or "{}")

        if not body.confirm:
            resolve(cur, msg_id, record, "cancelled",
                    {"ok": False, "cancelled": True, "error": "ผู้ใช้ไม่ยืนยัน จึงยังไม่ได้ทำรายการนี้"}, "ผู้ใช้กดยกเลิก")
        else:
            try:
                # คำนวณใหม่จากข้อมูลล่าสุด (เผื่อมีคนแก้ระหว่างรอยืนยัน) แล้วทำจริง
                summary, do = tools.WRITE_TOOLS[act["tool_name"]](ctx, cur, **args)
                result = do(cur)
            except Exception as e:
                conn.rollback()
                msg = str(e) if isinstance(e, tools.ToolError) else "บันทึกลงฐานข้อมูลไม่สำเร็จ"
                if not isinstance(e, tools.ToolError):
                    print(f"[AI action {id_action}] {e!r}")
                resolve(cur, msg_id, record, "failed", {"ok": False, "error": msg}, msg)
            else:
                record["summary"] = summary
                resolve(cur, msg_id, record, "success",
                        {"ok": True, "message": "บันทึกเรียบร้อยแล้ว: " + summary,
                         **{k: v for k, v in result.items() if k not in ("ok", "target_table", "target_id")}},
                        target=result)
        conn.commit()

        err = None
        if not find_pending(cur, conv):   # ไม่มีรายการรอแล้ว → ให้โมเดลสรุปผล
            try:
                run_model(conn, cur, ctx, conv, act["id_message"])
            except AIError as e:
                conn.rollback()
                err = str(e)
        return display(cur, ctx, conv, err)


@router.post("/api/chat/new")
def new_chat(request: Request):
    user = get_owner(request)
    if not user:
        return error("ผู้ช่วย AI ใช้ได้เฉพาะเจ้าของร้าน", 401)
    with get_db() as conn, conn.cursor() as cur:
        ctx = get_ctx(cur, user)
        old = current_conversation(cur, user["id_business"], create=False)
        if old:
            cancel_pending(cur, old, "เริ่มแชทใหม่")
        cur.execute("INSERT INTO conversation (id_business) VALUES (%s)", (user["id_business"],))
        conv = cur.lastrowid
        conn.commit()
        return display(cur, ctx, conv)


class UploadBody(BaseModel):
    name: str = ""
    data: str   # base64 (จะมี data:image/...;base64, นำหน้าหรือไม่ก็ได้)


def image_kind(head):
    """ดูจากไบต์แรก ๆ ว่าเป็นรูปจริง (กันไฟล์อื่นที่แค่ตั้งชื่อเป็น .jpg)"""
    if head.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    return None


@router.post("/api/chat/upload")
def upload_image(body: UploadBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("ผู้ช่วย AI ใช้ได้เฉพาะเจ้าของร้าน", 401)
    data = body.data.split(",", 1)[1] if body.data.startswith("data:") else body.data
    if len(data) > MAX_IMAGE_BYTES * 4 // 3 + 8:
        return error("รูปใหญ่เกินไป รับได้ไม่เกิน 5 MB")
    try:
        raw = base64.b64decode(data, validate=True)
    except ValueError:
        return error("อ่านไฟล์รูปไม่ได้")
    if not raw or len(raw) > MAX_IMAGE_BYTES:
        return error("รูปใหญ่เกินไป รับได้ไม่เกิน 5 MB")
    kind = image_kind(raw[:12])
    if not kind:
        return error("รองรับเฉพาะไฟล์รูป jpg png webp gif")
    folder = tools.UPLOAD_DIR / f"shop_{int(user['id_business'])}"
    folder.mkdir(parents=True, exist_ok=True)
    # ชื่อไฟล์ตั้งเอง ไม่ใช้ชื่อที่ผู้ใช้ส่งมา
    name = f"img_{datetime.datetime.now():%Y%m%d%H%M%S}_{uuid.uuid4().hex[:6]}{IMAGE_EXT[kind]}"
    (folder / name).write_bytes(raw)
    return {"ok": True, "path": f"/uploads/shop_{int(user['id_business'])}/{name}"}
