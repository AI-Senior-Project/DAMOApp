"""
API ของหน้าสินค้าและอุปกรณ์ — ใช้ได้เฉพาะเจ้าของร้าน
  GET    /api/items?kind=product|equipment&q=   รายการของร้าน + จำนวนคงเหลือรวมทุกสาขา
  POST   /api/items                           เพิ่ม
  POST   /api/items/{kind}/{id}               แก้ไข
  DELETE /api/items/{kind}/{id}               ลบ (ได้เฉพาะตัวที่ยังไม่เคยเข้าสต็อก/โปร/บิล)

ทุกการเพิ่ม/แก้/ลบ บันทึกลง history_transaction_user (ค่าเดิม → ค่าใหม่)
"""
import json
from decimal import Decimal

import pymysql
from fastapi import APIRouter, Request
from pydantic import BaseModel

from common import KINDS, error, get_user
from db import get_db

router = APIRouter()

FIELDS = ("name", "price", "type", "details", "image")  # ช่องที่แก้ได้ (ชื่อใน API)


def get_owner(request: Request):
    user = get_user(request)
    if not user or user["role"] != "owner":
        return None
    return user


def log_edit(cur, user, table, target_id, action, old=None, new=None):
    def clean(d):
        return None if d is None else json.dumps(
            {k: (float(v) if isinstance(v, Decimal) else v) for k, v in d.items()}, ensure_ascii=False)
    cur.execute(
        """INSERT INTO history_transaction_user (id_branch, target_table, target_id, action, old_value, new_value)
           VALUES (%s, %s, %s, %s, %s, %s)""",
        (user.get("id_branch"), table, target_id, action, clean(old), clean(new)),
    )


def select_item(cur, k, user, item_id, lock=False):
    cur.execute(
        f"""SELECT i.{k['iid']} AS id, i.{k['name']} AS name, i.price, i.type, i.details, i.image
            FROM {k['item']} i JOIN {k['owner']} o ON o.{k['iid']} = i.{k['iid']}
            WHERE i.{k['iid']} = %s AND o.id_business = %s""" + (" FOR UPDATE" if lock else ""),
        (item_id, user["id_business"]),
    )
    return cur.fetchone()


# -----------------------------------------------------------------
# รายการ
# -----------------------------------------------------------------
@router.get("/api/items")
def list_items(request: Request, kind: str = "product", q: str = ""):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    k = KINDS.get(kind)
    if not k:
        return error("ประเภทไม่ถูกต้อง")
    sql = f"""
        SELECT i.{k['iid']} AS id, i.{k['name']} AS name, i.price, i.type, i.details, i.image, i.input_date,
               (SELECT COALESCE(SUM(s.quantity), 0) FROM {k['storage']} s
                  JOIN carete_branch cb ON cb.id_branch = s.id_branch
                 WHERE s.{k['iid']} = i.{k['iid']} AND cb.id_business = %s) AS stock
        FROM {k['item']} i JOIN {k['owner']} o ON o.{k['iid']} = i.{k['iid']}
        WHERE o.id_business = %s
    """
    args = [user["id_business"], user["id_business"]]
    if q.strip():
        sql += f" AND i.{k['name']} LIKE %s"
        args.append(f"%{q.strip()}%")
    sql += f" ORDER BY i.{k['name']}"
    with get_db() as conn, conn.cursor() as cur:
        cur.execute(sql, args)
        rows = cur.fetchall()
    for r in rows:
        r["price"] = float(r["price"])
        r["stock"] = int(r["stock"])
        r["input_date"] = r["input_date"].strftime("%d/%m/%Y") if r["input_date"] else None
    return {"ok": True, "items": rows}


# -----------------------------------------------------------------
# เพิ่ม / แก้ไข
# -----------------------------------------------------------------
class ItemBody(BaseModel):
    kind: str = "product"
    name: str
    price: float
    type: str = ""
    details: str = ""
    image: str = ""


def clean_body(body: ItemBody):
    name = body.name.strip()[:150]
    if not name:
        return None, "กรุณาใส่ชื่อ"
    if not (0 <= body.price <= 10_000_000):
        return None, "ราคาต้องอยู่ระหว่าง 0 ถึง 10,000,000"
    return {
        "name": name,
        "price": round(body.price, 2),
        "type": body.type.strip()[:50] or None,
        "details": body.details.strip() or None,
        "image": body.image.strip()[:255] or None,
    }, None


@router.post("/api/items")
def create_item(body: ItemBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    k = KINDS.get(body.kind)
    if not k:
        return error("ประเภทไม่ถูกต้อง")
    v, err = clean_body(body)
    if err:
        return error(err)
    with get_db() as conn, conn.cursor() as cur:
        cur.execute(
            f"INSERT INTO {k['item']} ({k['name']}, price, type, details, image) VALUES (%s, %s, %s, %s, %s)",
            (v["name"], v["price"], v["type"], v["details"], v["image"]),
        )
        new_id = cur.lastrowid
        cur.execute(f"INSERT INTO {k['owner']} ({k['iid']}, id_business) VALUES (%s, %s)", (new_id, user["id_business"]))
        log_edit(cur, user, k["item"], new_id, "create", new=v)
        conn.commit()
    return {"ok": True, "id": new_id}


@router.post("/api/items/{kind}/{item_id}")
def update_item(kind: str, item_id: int, body: ItemBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    k = KINDS.get(kind)
    if not k:
        return error("ประเภทไม่ถูกต้อง")
    v, err = clean_body(body)
    if err:
        return error(err)
    with get_db() as conn, conn.cursor() as cur:
        old = select_item(cur, k, user, item_id, lock=True)
        if not old:
            return error("ไม่พบรายการนี้ในร้านของคุณ", 404)
        old["price"] = float(old["price"])
        changed_old = {f: old[f] for f in FIELDS if old[f] != v[f]}
        if not changed_old:
            return {"ok": True, "changed": False}
        cur.execute(
            f"""UPDATE {k['item']} SET {k['name']} = %s, price = %s, type = %s, details = %s, image = %s
                WHERE {k['iid']} = %s""",
            (v["name"], v["price"], v["type"], v["details"], v["image"], item_id),
        )
        # เก็บเฉพาะช่องที่เปลี่ยน
        log_edit(cur, user, k["item"], item_id, "update", old=changed_old, new={f: v[f] for f in changed_old})
        conn.commit()
    return {"ok": True, "changed": True}


# -----------------------------------------------------------------
# ลบ
# -----------------------------------------------------------------
@router.delete("/api/items/{kind}/{item_id}")
def delete_item(kind: str, item_id: int, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    k = KINDS.get(kind)
    if not k:
        return error("ประเภทไม่ถูกต้อง")
    with get_db() as conn, conn.cursor() as cur:
        old = select_item(cur, k, user, item_id, lock=True)
        if not old:
            return error("ไม่พบรายการนี้ในร้านของคุณ", 404)
        try:
            # carete_product / carete_equipment ถูกลบตามอัตโนมัติ (ON DELETE CASCADE)
            cur.execute(f"DELETE FROM {k['item']} WHERE {k['iid']} = %s", (item_id,))
        except pymysql.err.IntegrityError:
            conn.rollback()
            return error("ลบไม่ได้ เพราะรายการนี้เคยเข้าสต็อก มีโปรโมชัน หรืออยู่ในบิลแล้ว")
        log_edit(cur, user, k["item"], item_id, "delete", old=old)
        conn.commit()
    return {"ok": True}
