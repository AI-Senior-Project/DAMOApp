"""
ตั้งค่าของเครื่องตัวเอง — ใส่รหัส MySQL ไว้ที่นี่ไฟล์เดียว
(อัปเดต app.py รอบหน้าจะได้ไม่ต้องใส่รหัสใหม่ทุกครั้ง และอย่าอัปไฟล์นี้ขึ้น Git)
"""
import os

DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_USER = os.getenv("DB_USER", "root")
DB_PASSWORD = os.getenv("DB_PASSWORD", "0871427439Aa!@")      # <-- ใส่รหัส MySQL ตรงนี้
DB_NAME = os.getenv("DB_NAME", "ai_end")

SECRET_KEY = os.getenv("SECRET_KEY", "change-me-to-a-long-random-string")

LOW_STOCK_LIMIT = 5   # สต็อกเหลือเท่านี้หรือน้อยกว่า = ใกล้หมด
