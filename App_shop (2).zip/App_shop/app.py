"""
Ai_end - ระบบล็อกอิน + หน้าเมนู + สต็อก + รับเข้า/เบิกออก (FastAPI + MySQL)
ใช้ตารางตาม ERD_App_16
รัน:  py -m uvicorn app:app --reload
แล้วเปิด http://127.0.0.1:8000
"""
import os

import bcrypt
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from pydantic import BaseModel
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

import config  # รหัส DB อยู่ใน config.py
from common import get_login, get_user
import brands  # API หน้าเลือกร้าน (brands.py)
import products  # API หน้าสินค้าและอุปกรณ์ (products.py)
import promotions  # API หน้าโปรโมชัน (promotions.py)
import employees  # API หน้าพนักงาน (employees.py)
import branches  # API หน้าสาขา (branches.py)
import sell  # API หน้าขายสินค้า (sell.py)
import bills  # API หน้าประวัติการขาย (bills.py)
import ai_chat  # API หน้าแชทผู้ช่วย AI (ai_chat.py + ai_tools.py)
import ai_log  # API หน้าบันทึกการทำงานของ AI (ai_log.py)
import dashboard  # API หน้าภาพรวมร้าน (dashboard.py)
import register  # API สมัครใช้งาน (register.py)
import movement  # API รับเข้า/เบิกออก (movement.py)
import stock     # API หน้าสต็อก (stock.py)
from db import get_db

app = FastAPI()
app.add_middleware(SessionMiddleware, secret_key=config.SECRET_KEY, max_age=60 * 60 * 8)  # อยู่ได้ 8 ชม.

app.include_router(stock.router)
app.include_router(movement.router)
app.include_router(brands.router)
app.include_router(products.router)
app.include_router(promotions.router)
app.include_router(employees.router)
app.include_router(branches.router)
app.include_router(sell.router)
app.include_router(bills.router)
app.include_router(ai_chat.router)
app.include_router(ai_log.router)
app.include_router(dashboard.router)
app.include_router(register.router)

# รูปที่แนบในแชท AI (เก็บไว้ที่โฟลเดอร์ uploads/)
os.makedirs(os.path.join(os.path.dirname(__file__), "uploads"), exist_ok=True)
app.mount("/uploads", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "uploads")), name="uploads")

BASE = os.path.dirname(__file__)


def check_password(plain: str, hashed: str | None) -> bool:
    """เทียบรหัสที่พิมพ์มา กับค่า hash ใน DB"""
    if not hashed:
        return False
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except ValueError:  # hash ใน DB ผิดรูปแบบ (เช่นยังเป็นค่าหลอก)
        return False


def page(name: str):
    return FileResponse(os.path.join(BASE, "static", name))


# =================================================================
# 1) ล็อกอิน / ออกจากระบบ
# =================================================================
class LoginBody(BaseModel):
    mode: str        # "employee" หรือ "owner"
    username: str    # พนักงาน = id_login, เจ้าของ = email
    password: str


@app.post("/api/login")
def login(body: LoginBody, request: Request):
    fail = JSONResponse({"ok": False, "message": "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"}, status_code=401)

    if not body.username or not body.password or len(body.password.encode("utf-8")) > 72:
        return fail

    with get_db() as conn, conn.cursor() as cur:
        if body.mode == "employee":
            # พนักงาน → หาสาขาจาก carete_employee แล้วหาร้านจาก carete_branch
            cur.execute(
                """SELECT e.id_employee, e.name, e.password_login,
                          ce.id_branch, cb.id_business
                   FROM employee e
                   JOIN carete_employee ce ON ce.id_employee = e.id_employee
                   JOIN carete_branch cb   ON cb.id_branch = ce.id_branch
                   WHERE e.id_login = %s""",
                (body.username,),  # ใช้ %s เสมอ ห้ามต่อ string เอง (กัน SQL injection)
            )
            row = cur.fetchone()
            if not row or not check_password(body.password, row["password_login"]):
                return fail
            session_user = {
                "role": "employee",
                "id": row["id_employee"],
                "name": row["name"],
                "id_business": row["id_business"],
                "id_branch": row["id_branch"],
            }

        elif body.mode == "owner":
            cur.execute("SELECT id_user, name, password FROM `user` WHERE email = %s", (body.username,))
            row = cur.fetchone()
            if not row or not check_password(body.password, row["password"]):
                return fail
            session_user = {
                "role": "owner",
                "id": row["id_user"],
                "name": row["name"],
                "id_business": None,  # ยังไม่เลือกร้าน → ไปเลือกที่หน้า /brands
                "id_branch": None,    # เจ้าของดูได้ทุกสาขา
            }
        else:
            return fail

    request.session.clear()
    request.session["user"] = session_user
    return {"ok": True, "user": session_user}


@app.get("/api/me")
def me(request: Request):
    user = get_user(request)
    if not user:
        return JSONResponse({"ok": False}, status_code=401)
    return {"ok": True, "user": user}


@app.post("/api/logout")
def logout(request: Request):
    request.session.clear()
    return {"ok": True}


# =================================================================
# 2) ข้อมูลสรุปสำหรับหน้าเมนู
#    พนักงาน = เห็นเฉพาะสาขาตัวเอง / เจ้าของ = เห็นทั้งร้าน
#    ค่า id_business, id_branch เอามาจาก session เท่านั้น (ไม่รับจากหน้าเว็บ)
# =================================================================
@app.get("/api/menu-summary")
def menu_summary(request: Request):
    user = get_user(request)
    if not user:
        return JSONResponse({"ok": False}, status_code=401)

    biz = user["id_business"]
    branch = user["id_branch"]  # None = ทุกสาขา
    result = {
        "ok": True,
        "brand": None,
        "branch": "ทุกสาขา" if branch is None else None,
        "products": 0,
        "low_stock": 0,
        "active_promotions": 0,
        "sales_today": 0,
        "bills_today": 0,
        "low_stock_limit": config.LOW_STOCK_LIMIT,
    }
    if biz is None:  # เจ้าของที่ยังไม่มีร้าน
        return result

    branch_sql = "" if branch is None else " AND cb.id_branch = %s"
    branch_arg = () if branch is None else (branch,)

    with get_db() as conn, conn.cursor() as cur:
        cur.execute("SELECT name_brand FROM business WHERE id_business = %s", (biz,))
        row = cur.fetchone()
        result["brand"] = row["name_brand"] if row else None

        if branch is not None:
            cur.execute("SELECT branch_name FROM branch WHERE id_branch = %s", (branch,))
            row = cur.fetchone()
            result["branch"] = row["branch_name"] if row else None

        # จำนวนสินค้าของร้าน
        cur.execute("SELECT COUNT(*) AS n FROM carete_product WHERE id_business = %s", (biz,))
        result["products"] = cur.fetchone()["n"]

        # สินค้าใกล้หมด (ร้านเรา = สาขาที่อยู่ใน carete_branch ของร้านนี้)
        cur.execute(
            """SELECT COUNT(*) AS n FROM storage_product sp
               JOIN carete_branch cb ON cb.id_branch = sp.id_branch
               WHERE cb.id_business = %s AND sp.quantity <= %s""" + branch_sql,
            (biz, config.LOW_STOCK_LIMIT) + branch_arg,
        )
        result["low_stock"] = cur.fetchone()["n"]

        # โปรที่ใช้ได้ตอนนี้
        cur.execute(
            """SELECT COUNT(*) AS n FROM promotions p
               JOIN carete_promotions cp ON cp.id_promotions = p.id_promotions
               WHERE cp.id_business = %s AND p.status = 'active'
                 AND NOW() BETWEEN p.start_date AND p.end_date""",
            (biz,),
        )
        result["active_promotions"] = cur.fetchone()["n"]

        # ยอดขายวันนี้
        cur.execute(
            """SELECT COALESCE(SUM(b.total_price), 0) AS total, COUNT(*) AS n
               FROM bill b
               JOIN carete_branch cb ON cb.id_branch = b.id_branch
               WHERE cb.id_business = %s
                 AND b.sell_date >= CURDATE() AND b.sell_date < CURDATE() + INTERVAL 1 DAY""" + branch_sql,
            (biz,) + branch_arg,
        )
        row = cur.fetchone()
        result["sales_today"] = float(row["total"])
        result["bills_today"] = row["n"]

    return result


# =================================================================
# 3) หน้าเว็บ
# =================================================================
def guarded(request: Request, name: str):
    """ยังไม่ล็อกอิน → /login, เจ้าของที่ยังไม่เลือกร้าน → /brands"""
    if not get_login(request):
        return RedirectResponse("/login")
    if not get_user(request):
        return RedirectResponse("/brands")
    return page(name)


@app.get("/")
def index(request: Request):
    return RedirectResponse("/menu" if get_login(request) else "/login")


@app.get("/login")
def login_page(request: Request):
    if get_login(request):
        return RedirectResponse("/menu")
    return page("login.html")


@app.get("/register")
def register_page(request: Request):
    if get_login(request):
        return RedirectResponse("/menu")
    return page("register.html")


@app.get("/brands")
def brands_page(request: Request):
    user = get_login(request)
    if not user:
        return RedirectResponse("/login")
    if user["role"] != "owner":  # พนักงานไม่ต้องเลือกร้าน
        return RedirectResponse("/menu")
    return page("brands.html")


@app.get("/menu")
def menu_page(request: Request):
    return guarded(request, "menu.html")


@app.get("/stock")
def stock_page(request: Request):
    return guarded(request, "stock.html")


@app.get("/movement")
def movement_page(request: Request):
    return guarded(request, "movement.html")


@app.get("/products")
def products_page(request: Request):
    user = get_user(request)
    if user and user["role"] != "owner":  # พนักงานเข้าไม่ได้
        return RedirectResponse("/menu")
    return guarded(request, "products.html")


@app.get("/promotions")
def promotions_page(request: Request):
    user = get_user(request)
    if user and user["role"] != "owner":  # พนักงานเข้าไม่ได้
        return RedirectResponse("/menu")
    return guarded(request, "promotions.html")


@app.get("/employees")
def employees_page(request: Request):
    user = get_user(request)
    if user and user["role"] != "owner":  # พนักงานเข้าไม่ได้
        return RedirectResponse("/menu")
    return guarded(request, "employees.html")


@app.get("/branches")
def branches_page(request: Request):
    user = get_user(request)
    if user and user["role"] != "owner":  # พนักงานเข้าไม่ได้
        return RedirectResponse("/menu")
    return guarded(request, "branches.html")


@app.get("/sell")
def sell_page(request: Request):
    return guarded(request, "sell.html")


@app.get("/bills")
def bills_page(request: Request):
    return guarded(request, "bills.html")


@app.get("/chat")
def chat_page(request: Request):
    user = get_user(request)
    if user and user["role"] != "owner":  # พนักงานเข้าไม่ได้
        return RedirectResponse("/menu")
    return guarded(request, "chat.html")


@app.get("/ai-log")
def ai_log_page(request: Request):
    user = get_user(request)
    if user and user["role"] != "owner":  # พนักงานเข้าไม่ได้
        return RedirectResponse("/menu")
    return guarded(request, "ai_log.html")


@app.get("/dashboard")
def dashboard_page(request: Request):
    user = get_user(request)
    if user and user["role"] != "owner":  # พนักงานเข้าไม่ได้
        return RedirectResponse("/menu")
    return guarded(request, "dashboard.html")


@app.get("/home")
def home_page():
    return RedirectResponse("/menu")  # ลิงก์เก่า /home ให้ไปหน้าเมนูแทน
