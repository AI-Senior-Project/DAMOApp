"""
ตั้งรหัสผ่าน (เก็บเป็น bcrypt hash ลง DB)

ใช้แบบนี้:
  python set_password.py employee emp001 1234
  python set_password.py owner owner@example.com 1234
"""
import sys

import bcrypt

from db import get_db

if len(sys.argv) != 4 or sys.argv[1] not in ("employee", "owner"):
    print(__doc__)
    sys.exit(1)

mode, username, password = sys.argv[1:]
if len(password.encode("utf-8")) > 72:
    sys.exit("รหัสผ่านยาวเกินไป (bcrypt รับได้ไม่เกิน 72 byte)")

hashed = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")

with get_db() as conn, conn.cursor() as cur:
    if mode == "employee":
        n = cur.execute("UPDATE employee SET password_login = %s WHERE id_login = %s", (hashed, username))
    else:
        n = cur.execute("UPDATE `user` SET password = %s WHERE email = %s", (hashed, username))
    conn.commit()

print("ตั้งรหัสผ่านเรียบร้อย" if n else "ไม่เจอผู้ใช้นี้ในฐานข้อมูล")
