-- =====================================================================
--  Ai_end : Shop / Stock App + AI Assistant
--  MySQL 8.0+   (สร้างตาม ERD_App_16)
--
--  ⚠️ ไฟล์นี้ลบฐานข้อมูล ai_end เดิมทิ้งทั้งหมดแล้วสร้างใหม่
--     ข้อมูลที่เคยใส่ไว้จะหายหมด
--
--  รัน:  mysql -u root -p < ai_end_schema.sql
--        หรือเปิดใน MySQL Workbench แล้วกด ⚡
-- =====================================================================

DROP DATABASE IF EXISTS ai_end;
CREATE DATABASE ai_end
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;   -- รองรับภาษาไทย
USE ai_end;

-- ---------------------------------------------------------------------
-- 1) เจ้าของร้าน / ร้าน
-- ---------------------------------------------------------------------
CREATE TABLE `user` (
  id_user     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  image       VARCHAR(255) NULL,
  email       VARCHAR(150) NOT NULL,
  password    VARCHAR(255) NULL,               -- เก็บเป็น bcrypt hash เท่านั้น
  UNIQUE KEY uq_user_email (email)
) ENGINE=InnoDB;

CREATE TABLE business (
  id_business  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_user      INT UNSIGNED NOT NULL,          -- เจ้าของร้าน (ร้านละ 1 คน)
  name_model   VARCHAR(100) NOT NULL,
  name_brand   VARCHAR(100) NOT NULL,
  logo_brand   VARCHAR(255) NULL,
  carete_date  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_business_user FOREIGN KEY (id_user) REFERENCES `user`(id_user)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2) สาขา
-- ---------------------------------------------------------------------
CREATE TABLE branch (
  id_branch    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  branch_name  VARCHAR(100) NOT NULL,
  location     VARCHAR(255) NULL
) ENGINE=InnoDB;

-- ร้าน ↔ สาขา  (PK = id_branch → 1 สาขาเป็นของร้านเดียว, 1 ร้านมีได้หลายสาขา)
CREATE TABLE carete_branch (
  id_branch    INT UNSIGNED NOT NULL PRIMARY KEY,
  id_business  INT UNSIGNED NOT NULL,
  carete_date  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_cb_business (id_business),
  CONSTRAINT fk_cb_branch   FOREIGN KEY (id_branch) REFERENCES branch(id_branch) ON DELETE CASCADE,
  CONSTRAINT fk_cb_business FOREIGN KEY (id_business) REFERENCES business(id_business)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 3) พนักงาน
-- ---------------------------------------------------------------------
CREATE TABLE employee (
  id_employee     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(100) NOT NULL,
  position        VARCHAR(50)  NULL,
  salary          DECIMAL(10,2) NULL,
  id_login        VARCHAR(50)  NOT NULL,
  password_login  VARCHAR(255) NOT NULL,       -- bcrypt hash
  UNIQUE KEY uq_employee_login (id_login)
) ENGINE=InnoDB;

-- สาขา ↔ พนักงาน  (PK = id_employee → พนักงาน 1 คนอยู่สาขาเดียว)
CREATE TABLE carete_employee (
  id_employee  INT UNSIGNED NOT NULL PRIMARY KEY,
  id_branch    INT UNSIGNED NOT NULL,
  carete_date  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ce_branch (id_branch),
  CONSTRAINT fk_ce_employee FOREIGN KEY (id_employee) REFERENCES employee(id_employee) ON DELETE CASCADE,
  CONSTRAINT fk_ce_branch   FOREIGN KEY (id_branch) REFERENCES branch(id_branch)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4) สินค้า / อุปกรณ์
-- ---------------------------------------------------------------------
CREATE TABLE product (
  id_product    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name_product  VARCHAR(150) NOT NULL,
  image         VARCHAR(255) NULL,
  price         DECIMAL(10,2) NOT NULL,
  type          VARCHAR(50)  NULL,
  details       TEXT NULL,
  input_date    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_product_price CHECK (price >= 0)
) ENGINE=InnoDB;

CREATE TABLE carete_product (
  id_product   INT UNSIGNED NOT NULL PRIMARY KEY,   -- สินค้า 1 ตัวเป็นของร้านเดียว
  id_business  INT UNSIGNED NOT NULL,
  KEY idx_cp_business (id_business),
  CONSTRAINT fk_cp_product  FOREIGN KEY (id_product) REFERENCES product(id_product) ON DELETE CASCADE,
  CONSTRAINT fk_cp_business FOREIGN KEY (id_business) REFERENCES business(id_business)
) ENGINE=InnoDB;

CREATE TABLE equipment (
  id_equipment    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name_equipment  VARCHAR(150) NOT NULL,
  image           VARCHAR(255) NULL,
  price           DECIMAL(10,2) NOT NULL,
  type            VARCHAR(50)  NULL,
  details         TEXT NULL,
  input_date      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_equipment_price CHECK (price >= 0)
) ENGINE=InnoDB;

CREATE TABLE carete_equipment (
  id_equipment  INT UNSIGNED NOT NULL PRIMARY KEY,
  id_business   INT UNSIGNED NOT NULL,
  KEY idx_ceq_business (id_business),
  CONSTRAINT fk_ceq_equipment FOREIGN KEY (id_equipment) REFERENCES equipment(id_equipment) ON DELETE CASCADE,
  CONSTRAINT fk_ceq_business  FOREIGN KEY (id_business) REFERENCES business(id_business)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 5) สต็อกแต่ละสาขา
--    UNIQUE (สาขา, สินค้า) → สินค้าเดียวกันในสาขาเดียวกันมีได้แถวเดียว
-- ---------------------------------------------------------------------
CREATE TABLE storage_product (
  id_storage_product  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_branch           INT UNSIGNED NOT NULL,
  id_product          INT UNSIGNED NOT NULL,
  quantity            INT NOT NULL DEFAULT 0,
  mfg_date            DATE NULL,                  -- วันผลิต
  exp_date            DATE NULL,                  -- วันหมดอายุ
  UNIQUE KEY uq_sp (id_branch, id_product),
  CONSTRAINT chk_sp_qty CHECK (quantity >= 0),
  CONSTRAINT fk_sp_branch  FOREIGN KEY (id_branch) REFERENCES branch(id_branch),
  CONSTRAINT fk_sp_product FOREIGN KEY (id_product) REFERENCES product(id_product)
) ENGINE=InnoDB;

CREATE TABLE storage_equipment (
  id_storage_equipment  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_branch             INT UNSIGNED NOT NULL,
  id_equipment          INT UNSIGNED NOT NULL,
  quantity              INT NOT NULL DEFAULT 0,
  mfg_date              DATE NULL,
  exp_date              DATE NULL,
  UNIQUE KEY uq_se (id_branch, id_equipment),
  CONSTRAINT chk_se_qty CHECK (quantity >= 0),
  CONSTRAINT fk_se_branch    FOREIGN KEY (id_branch) REFERENCES branch(id_branch),
  CONSTRAINT fk_se_equipment FOREIGN KEY (id_equipment) REFERENCES equipment(id_equipment)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 6) ประวัติ รับเข้า / เบิกออก / ปรับยอด  (1 แถว = สินค้า 1 รายการ)
--    id_employee = NULL → เจ้าของร้าน (หรือ AI ที่เจ้าของสั่ง) เป็นคนทำ
-- ---------------------------------------------------------------------
CREATE TABLE transaction_product (
  id_transaction_product  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_employee             INT UNSIGNED NULL,
  id_storage_product      INT UNSIGNED NOT NULL,
  transaction_type        ENUM('receive','issue','adjust') NOT NULL,  -- รับเข้า / เบิกออก / ปรับยอด
  quantity_changed        INT NOT NULL,           -- +24 = รับเข้า 24, -3 = เบิกออก 3
  balance_before          INT NOT NULL,
  balance_after           INT NOT NULL,
  details                 VARCHAR(255) NULL,      -- เหตุผล / หมายเหตุ
  reference_no            VARCHAR(50)  NULL,      -- เลขที่ใบส่งของ ฯลฯ
  mfg_date                DATE NULL,              -- วันผลิตที่ตั้งในรายการนี้ (NULL = ไม่ได้เปลี่ยน)
  exp_date                DATE NULL,              -- วันหมดอายุที่ตั้งในรายการนี้
  created_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_tp_math CHECK (balance_after = balance_before + quantity_changed),
  CONSTRAINT chk_tp_neg  CHECK (balance_after >= 0),
  CONSTRAINT fk_tp_employee FOREIGN KEY (id_employee) REFERENCES employee(id_employee),
  CONSTRAINT fk_tp_storage  FOREIGN KEY (id_storage_product) REFERENCES storage_product(id_storage_product),
  KEY idx_tp_date (created_at)
) ENGINE=InnoDB;

CREATE TABLE transaction_equipment (
  id_transaction_equipment  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_employee               INT UNSIGNED NULL,
  id_storage_equipment      INT UNSIGNED NOT NULL,
  transaction_type          ENUM('receive','issue','adjust') NOT NULL,
  quantity_changed          INT NOT NULL,
  balance_before            INT NOT NULL,
  balance_after             INT NOT NULL,
  details                   VARCHAR(255) NULL,
  reference_no              VARCHAR(50)  NULL,
  mfg_date                  DATE NULL,
  exp_date                  DATE NULL,
  created_at                DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_te_math CHECK (balance_after = balance_before + quantity_changed),
  CONSTRAINT chk_te_neg  CHECK (balance_after >= 0),
  CONSTRAINT fk_te_employee FOREIGN KEY (id_employee) REFERENCES employee(id_employee),
  CONSTRAINT fk_te_storage  FOREIGN KEY (id_storage_equipment) REFERENCES storage_equipment(id_storage_equipment),
  KEY idx_te_date (created_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 7) โปรโมชัน
-- ---------------------------------------------------------------------
CREATE TABLE promotions (
  id_promotions   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_product      INT UNSIGNED NOT NULL,
  name            VARCHAR(150) NOT NULL,
  discount_type   ENUM('percent','amount') NOT NULL,
  discount_value  DECIMAL(10,2) NOT NULL,
  start_date      DATETIME NOT NULL,
  end_date        DATETIME NOT NULL,
  status          ENUM('draft','active','inactive','expired') NOT NULL DEFAULT 'draft',
  carete_date     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_promo_value   CHECK (discount_value > 0),
  CONSTRAINT chk_promo_percent CHECK (discount_type <> 'percent' OR discount_value <= 100),
  CONSTRAINT chk_promo_dates   CHECK (end_date > start_date),
  CONSTRAINT fk_promo_product FOREIGN KEY (id_product) REFERENCES product(id_product)
) ENGINE=InnoDB;

CREATE TABLE carete_promotions (
  id_promotions  INT UNSIGNED NOT NULL PRIMARY KEY,
  id_business    INT UNSIGNED NOT NULL,
  KEY idx_cpr_business (id_business),
  CONSTRAINT fk_cpr_promo    FOREIGN KEY (id_promotions) REFERENCES promotions(id_promotions) ON DELETE CASCADE,
  CONSTRAINT fk_cpr_business FOREIGN KEY (id_business) REFERENCES business(id_business)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 8) บิล
-- ---------------------------------------------------------------------
CREATE TABLE bill (
  id_bill        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_employee    INT UNSIGNED NULL,               -- NULL = เจ้าของร้านขายเอง
  id_branch      INT UNSIGNED NOT NULL,
  total_price    DECIMAL(12,2) NOT NULL DEFAULT 0,
  discount       DECIMAL(12,2) NOT NULL DEFAULT 0,
  id_promotions  INT UNSIGNED NULL,
  type_pay       ENUM('cash','transfer','qr','card','other') NOT NULL DEFAULT 'cash',
  sell_date      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bill_employee FOREIGN KEY (id_employee) REFERENCES employee(id_employee),
  CONSTRAINT fk_bill_branch   FOREIGN KEY (id_branch) REFERENCES branch(id_branch),
  CONSTRAINT fk_bill_promo    FOREIGN KEY (id_promotions) REFERENCES promotions(id_promotions),
  KEY idx_bill_date (id_branch, sell_date)
) ENGINE=InnoDB;

CREATE TABLE bill_item (
  id_bill_item        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_bill             INT UNSIGNED NOT NULL,
  id_storage_product  INT UNSIGNED NOT NULL,
  volume              INT NOT NULL,
  price               DECIMAL(10,2) NOT NULL,     -- ราคาต่อชิ้น ณ ตอนขาย
  CONSTRAINT chk_bi_volume CHECK (volume > 0),
  CONSTRAINT fk_bi_bill    FOREIGN KEY (id_bill) REFERENCES bill(id_bill) ON DELETE CASCADE,
  CONSTRAINT fk_bi_storage FOREIGN KEY (id_storage_product) REFERENCES storage_product(id_storage_product)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 9) แชท AI (ใช้ได้เฉพาะเจ้าของร้าน)
-- ---------------------------------------------------------------------
CREATE TABLE conversation (
  id_conversation  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_business      INT UNSIGNED NOT NULL,
  CONSTRAINT fk_conv_business FOREIGN KEY (id_business) REFERENCES business(id_business)
) ENGINE=InnoDB;

CREATE TABLE message_box (
  id_message       INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_conversation  INT UNSIGNED NOT NULL,
  role             ENUM('user','assistant','system','tool') NOT NULL,
  content          TEXT NOT NULL,
  carete_date      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_msg_conversation FOREIGN KEY (id_conversation) REFERENCES conversation(id_conversation) ON DELETE CASCADE,
  KEY idx_msg_history (id_conversation, carete_date)
) ENGINE=InnoDB;

CREATE TABLE ai_action_log (
  id_action      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_message     INT UNSIGNED NULL,
  ai_name        VARCHAR(100) NOT NULL,          -- เช่น 'qwen2.5:7b'
  prompt         TEXT NULL,
  version        VARCHAR(20)  NULL,
  tool_name      VARCHAR(100) NOT NULL,          -- เช่น 'update_stock'
  arguments      JSON NULL,
  result         TEXT NULL,
  error_message  TEXT NULL,
  target_id      INT UNSIGNED NULL,
  target_table   VARCHAR(50)  NULL,
  status         ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
  created_date   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_log_message FOREIGN KEY (id_message) REFERENCES message_box(id_message) ON DELETE SET NULL,
  KEY idx_log_target (target_table, target_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 10) ประวัติการแก้ไขข้อมูลโดยเจ้าของร้าน
-- ---------------------------------------------------------------------
CREATE TABLE history_transaction_user (
  id_transaction_user  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_branch            INT UNSIGNED NULL,        -- NULL = ไม่ได้เจาะจงสาขา (เช่น แก้ราคาสินค้า)
  target_table         VARCHAR(50)  NOT NULL,    -- 'product', 'promotions', 'employee' ...
  target_id            INT UNSIGNED NOT NULL,
  action               ENUM('create','update','delete') NOT NULL,
  old_value            JSON NULL,
  new_value            JSON NULL,
  created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_hist_branch FOREIGN KEY (id_branch) REFERENCES branch(id_branch),
  KEY idx_hist_target (target_table, target_id)
) ENGINE=InnoDB;


-- =====================================================================
--  ข้อมูลตัวอย่าง (ไว้ทดสอบ)  — ไม่ใช้ก็ลบส่วนนี้ทิ้งได้
--  รหัสผ่านยังเป็น NULL / ค่าหลอก → ต้องรัน set_password.py ก่อนล็อกอิน
-- =====================================================================
INSERT INTO `user` (name, email) VALUES ('เจ้าของร้าน', 'owner@example.com');
INSERT INTO business (id_user, name_model, name_brand) VALUES (1, 'ร้านกาแฟ', 'Ai Coffee');

INSERT INTO branch (branch_name, location) VALUES ('สาขาหลัก', 'กรุงเทพ'), ('สาขา 2', 'นนทบุรี');
INSERT INTO carete_branch (id_branch, id_business) VALUES (1, 1), (2, 1);

INSERT INTO employee (name, position, salary, id_login, password_login) VALUES
  ('สมชาย', 'cashier', 15000, 'emp001', 'REPLACE_WITH_REAL_BCRYPT_HASH');
INSERT INTO carete_employee (id_employee, id_branch) VALUES (1, 1);

INSERT INTO product (name_product, price, type) VALUES ('ลาเต้เย็น', 55.00, 'drink'), ('ครัวซองต์', 45.00, 'bakery');
INSERT INTO carete_product (id_product, id_business) VALUES (1, 1), (2, 1);

INSERT INTO equipment (name_equipment, price, type) VALUES ('แก้วพลาสติก 16oz', 2.50, 'packaging');
INSERT INTO carete_equipment (id_equipment, id_business) VALUES (1, 1);

INSERT INTO storage_product (id_branch, id_product, quantity) VALUES (1, 1, 50), (1, 2, 20), (2, 1, 30);
INSERT INTO storage_equipment (id_branch, id_equipment, quantity) VALUES (1, 1, 500);
