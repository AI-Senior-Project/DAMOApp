"""
API สมัครใช้งาน (สร้างบัญชีเจ้าของร้านใหม่ในตาราง user)
  POST /api/register   {name, email, password}
สมัครเสร็จ → ล็อกอินให้เลย แล้วหน้าเว็บพาไปหน้าเลือกร้าน (/brands) เพื่อสร้างร้านแรก
พนักงานสมัครเองไม่ได้ เจ้าของร้านเป็นคนเพิ่มให้ที่หน้าพนักงาน
"""
import re
import time

import bcrypt
import pymysql
from fastapi import APIRouter, Request
from pydantic import BaseModel

from common import error
from db import get_db

router = APIRouter()

EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MIN_PASSWORD = 8
LIMIT, WINDOW = 5, 600      # สมัครได้ไม่เกิน 5 ครั้ง / 10 นาที ต่อเครื่อง (กันยิงสมัครรัว ๆ)
_tries: dict[str, list[float]] = {}


def too_many(ip: str) -> bool:
    now = time.time()
    hits = [t for t in _tries.get(ip, []) if now - t < WINDOW]
    _tries[ip] = hits
    if len(hits) >= LIMIT:
        return True
    hits.append(now)
    return False


class RegisterBody(BaseModel):
    name: str
    email: str
    password: str


@router.post("/api/register")
def register(body: RegisterBody, request: Request):
    name = body.name.strip()[:100]
    email = body.email.strip().lower()
    if not name:
        return error("กรุณาใส่ชื่อ")
    if len(email) > 150 or not EMAIL.match(email):
        return error("อีเมลไม่ถูกต้อง")
    if len(body.password) < MIN_PASSWORD:
        return error(f"รหัสผ่านต้องยาว {MIN_PASSWORD} ตัวขึ้นไป")
    if len(body.password.encode("utf-8")) > 72:
        return error("รหัสผ่านยาวเกินไป")
    if too_many(request.client.host if request.client else "?"):
        return error("สมัครหลายครั้งเกินไป ลองใหม่อีกครั้งในอีก 10 นาที", 429)

    hashed = bcrypt.hashpw(body.password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    with get_db() as conn, conn.cursor() as cur:
        try:
            cur.execute("INSERT INTO `user` (name, email, password) VALUES (%s, %s, %s)", (name, email, hashed))
        except pymysql.err.IntegrityError:   # email ซ้ำ (UNIQUE)
            return error("อีเมลนี้มีบัญชีอยู่แล้ว ลองเข้าสู่ระบบแทน")
        new_id = cur.lastrowid
        conn.commit()

    # ล็อกอินให้เลย (เหมือนล็อกอินแบบเจ้าของร้าน)
    user = {"role": "owner", "id": new_id, "name": name, "id_business": None, "id_branch": None}
    request.session.clear()
    request.session["user"] = user
    return {"ok": True, "user": user}
