"""
API ของหน้าโปรโมชัน — ใช้ได้เฉพาะเจ้าของร้าน
  GET    /api/promotions              โปรทั้งหมดของร้าน (+ สถานะตอนนี้)
  POST   /api/promotions              สร้าง
  POST   /api/promotions/{id}         แก้ไข
  POST   /api/promotions/{id}/toggle  เปิด / ปิด
  DELETE /api/promotions/{id}         ลบ (ได้เฉพาะโปรที่ยังไม่เคยถูกใช้ในบิล)

สถานะที่เก็บใน DB: active (เปิด) / inactive (ปิด)
สถานะที่แสดง (คำนวณจากวันที่): ใช้งานอยู่ / รอเริ่ม / หมดเวลา / ปิดอยู่
ทุกการเปลี่ยนแปลงบันทึกลง history_transaction_user
"""
from datetime import datetime
from decimal import Decimal

import pymysql
from fastapi import APIRouter, Request
from pydantic import BaseModel

from common import error
from db import get_db
from products import get_owner, log_edit

router = APIRouter()

FIELDS = ("id_product", "name", "discount_type", "discount_value", "start_date", "end_date", "status")


def live_state(status, start, end, now):
    if status != "active":
        return "off"
    if now < start:
        return "upcoming"
    if now > end:
        return "ended"
    return "running"


def select_promo(cur, user, promo_id, lock=False):
    cur.execute(
        """SELECT p.id_promotions AS id, p.id_product, p.name, p.discount_type, p.discount_value,
                  p.start_date, p.end_date, p.status
           FROM promotions p JOIN carete_promotions cp ON cp.id_promotions = p.id_promotions
           WHERE p.id_promotions = %s AND cp.id_business = %s""" + (" FOR UPDATE" if lock else ""),
        (promo_id, user["id_business"]),
    )
    return cur.fetchone()


def for_log(d):
    return {k: (v.strftime("%Y-%m-%d %H:%M") if isinstance(v, datetime) else float(v) if isinstance(v, Decimal) else v)
            for k, v in d.items()}


# -----------------------------------------------------------------
# รายการ
# -----------------------------------------------------------------
@router.get("/api/promotions")
def list_promotions(request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    with get_db() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT p.id_promotions AS id, p.id_product, pr.name_product AS product, pr.price,
                      p.name, p.discount_type, p.discount_value, p.start_date, p.end_date, p.status, NOW() AS now
               FROM promotions p
               JOIN carete_promotions cp ON cp.id_promotions = p.id_promotions
               JOIN product pr ON pr.id_product = p.id_product
               WHERE cp.id_business = %s
               ORDER BY p.end_date DESC""",
            (user["id_business"],),
        )
        rows = cur.fetchall()
        # สินค้าของร้าน (ไว้เลือกในฟอร์ม)
        cur.execute(
            """SELECT pr.id_product AS id, pr.name_product AS name, pr.price
               FROM product pr JOIN carete_product cp ON cp.id_product = pr.id_product
               WHERE cp.id_business = %s ORDER BY pr.name_product""",
            (user["id_business"],),
        )
        products = cur.fetchall()

    for r in rows:
        r["state"] = live_state(r["status"], r["start_date"], r["end_date"], r.pop("now"))
        price = float(r["price"])
        value = float(r["discount_value"])
        r["price"] = price
        r["discount_value"] = value
        cut = price * value / 100 if r["discount_type"] == "percent" else value
        r["sale_price"] = round(max(price - cut, 0), 2)
        r["start_date"] = r["start_date"].strftime("%Y-%m-%dT%H:%M")
        r["end_date"] = r["end_date"].strftime("%Y-%m-%dT%H:%M")
    for p in products:
        p["price"] = float(p["price"])
    return {"ok": True, "items": rows, "products": products}


# -----------------------------------------------------------------
# สร้าง / แก้ไข
# -----------------------------------------------------------------
class PromoBody(BaseModel):
    id_product: int
    name: str
    discount_type: str          # percent | amount
    discount_value: float
    start_date: datetime
    end_date: datetime
    status: str = "active"      # active | inactive


def clean_body(cur, user, body: PromoBody):
    name = body.name.strip()[:150]
    if not name:
        return None, "กรุณาใส่ชื่อโปร"
    if body.discount_type not in ("percent", "amount"):
        return None, "รูปแบบส่วนลดไม่ถูกต้อง"
    if body.discount_value <= 0:
        return None, "ส่วนลดต้องมากกว่า 0"
    if body.discount_type == "percent" and body.discount_value > 100:
        return None, "ลดเป็น % ได้ไม่เกิน 100"
    if body.end_date <= body.start_date:
        return None, "วันจบต้องอยู่หลังวันเริ่ม"
    if body.status not in ("active", "inactive"):
        return None, "สถานะไม่ถูกต้อง"
    # สินค้าต้องเป็นของร้านเรา
    cur.execute(
        """SELECT pr.price FROM product pr JOIN carete_product cp ON cp.id_product = pr.id_product
           WHERE pr.id_product = %s AND cp.id_business = %s""",
        (body.id_product, user["id_business"]),
    )
    row = cur.fetchone()
    if not row:
        return None, "ไม่พบสินค้านี้ในร้านของคุณ"
    if body.discount_type == "amount" and body.discount_value > float(row["price"]):
        return None, f"ส่วนลดมากกว่าราคาสินค้า (฿{float(row['price']):,.2f})"
    return {
        "id_product": body.id_product,
        "name": name,
        "discount_type": body.discount_type,
        "discount_value": round(body.discount_value, 2),
        "start_date": body.start_date.replace(tzinfo=None, second=0, microsecond=0),
        "end_date": body.end_date.replace(tzinfo=None, second=0, microsecond=0),
        "status": body.status,
    }, None


@router.post("/api/promotions")
def create_promotion(body: PromoBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    with get_db() as conn, conn.cursor() as cur:
        v, err = clean_body(cur, user, body)
        if err:
            return error(err)
        cur.execute(
            """INSERT INTO promotions (id_product, name, discount_type, discount_value, start_date, end_date, status)
               VALUES (%s, %s, %s, %s, %s, %s, %s)""",
            tuple(v[f] for f in FIELDS),
        )
        new_id = cur.lastrowid
        cur.execute("INSERT INTO carete_promotions (id_promotions, id_business) VALUES (%s, %s)", (new_id, user["id_business"]))
        log_edit(cur, user, "promotions", new_id, "create", new=for_log(v))
        conn.commit()
    return {"ok": True, "id": new_id}


@router.post("/api/promotions/{promo_id}")
def update_promotion(promo_id: int, body: PromoBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    with get_db() as conn, conn.cursor() as cur:
        old = select_promo(cur, user, promo_id, lock=True)
        if not old:
            return error("ไม่พบโปรนี้ในร้านของคุณ", 404)
        v, err = clean_body(cur, user, body)
        if err:
            return error(err)
        old["discount_value"] = float(old["discount_value"])
        changed = [f for f in FIELDS if old[f] != v[f]]
        if not changed:
            return {"ok": True, "changed": False}
        cur.execute(
            """UPDATE promotions SET id_product = %s, name = %s, discount_type = %s, discount_value = %s,
                      start_date = %s, end_date = %s, status = %s
               WHERE id_promotions = %s""",
            tuple(v[f] for f in FIELDS) + (promo_id,),
        )
        log_edit(cur, user, "promotions", promo_id, "update",
                 old=for_log({f: old[f] for f in changed}), new=for_log({f: v[f] for f in changed}))
        conn.commit()
    return {"ok": True, "changed": True}


@router.post("/api/promotions/{promo_id}/toggle")
def toggle_promotion(promo_id: int, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    with get_db() as conn, conn.cursor() as cur:
        old = select_promo(cur, user, promo_id, lock=True)
        if not old:
            return error("ไม่พบโปรนี้ในร้านของคุณ", 404)
        new_status = "inactive" if old["status"] == "active" else "active"
        cur.execute("UPDATE promotions SET status = %s WHERE id_promotions = %s", (new_status, promo_id))
        log_edit(cur, user, "promotions", promo_id, "update", old={"status": old["status"]}, new={"status": new_status})
        conn.commit()
    return {"ok": True, "status": new_status}


@router.delete("/api/promotions/{promo_id}")
def delete_promotion(promo_id: int, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    with get_db() as conn, conn.cursor() as cur:
        old = select_promo(cur, user, promo_id, lock=True)
        if not old:
            return error("ไม่พบโปรนี้ในร้านของคุณ", 404)
        try:
            # carete_promotions ถูกลบตามอัตโนมัติ (ON DELETE CASCADE)
            cur.execute("DELETE FROM promotions WHERE id_promotions = %s", (promo_id,))
        except pymysql.err.IntegrityError:
            conn.rollback()
            return error("ลบไม่ได้ เพราะโปรนี้ถูกใช้ในบิลแล้ว ให้กดปิดแทน")
        log_edit(cur, user, "promotions", promo_id, "delete", old=for_log(old))
        conn.commit()
    return {"ok": True}
