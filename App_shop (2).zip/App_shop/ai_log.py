"""
API ของหน้าบันทึกการทำงานของ AI — ใช้ได้เฉพาะเจ้าของร้าน
  GET /api/ai-log?date_from=&date_to=&status=&tool=   รายการที่ AI ขอทำ (เฉพาะแบบแก้ไขข้อมูล)
  GET /api/ai-log/{id}                                 รายละเอียด + ข้อความที่สั่ง

ai_action_log ไม่มี id_business เลยหาร้านผ่าน message_box → conversation
สถานะในหน้าเว็บ: success = ทำแล้ว / failed + "ผู้ใช้..." = ยกเลิก / failed อื่น ๆ = ไม่สำเร็จ / pending = รอยืนยัน
"""
import json
from datetime import date, timedelta

from fastapi import APIRouter, Request

from common import error
from db import get_db
from products import get_owner

router = APIRouter()

TOOL_LABEL = {
    "add_product": "เพิ่มสินค้า",
    "edit_product": "แก้ไขสินค้า",
    "update_stock": "เพิ่ม/ลดสต็อกสินค้า",
    "create_promotion": "สร้างโปรโมชัน",
    "update_equipment_stock": "เพิ่ม/ลดอุปกรณ์",
    "add_equipment": "เพิ่มอุปกรณ์",
    "set_image": "ใส่รูป",
    "list_employee": "ค้นหาพนักงาน",
}
MAX_ROWS = 500
CANCEL_PREFIX = ("ผู้ใช้", "เริ่มแชทใหม่")   # error_message ของรายการที่ถูกยกเลิก (ดู ai_chat.py)

BASE_SQL = """
    FROM ai_action_log a
    JOIN message_box m  ON m.id_message = a.id_message
    JOIN conversation c ON c.id_conversation = m.id_conversation
    WHERE c.id_business = %s
"""


def state_of(status, err):
    if status == "failed" and err and err.startswith(CANCEL_PREFIX):
        return "cancelled"
    return status


@router.get("/api/ai-log")
def list_log(request: Request, date_from: date | None = None, date_to: date | None = None,
             status: str = "", tool: str = ""):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    date_to = date_to or date.today()
    date_from = date_from or date_to - timedelta(days=6)
    if date_from > date_to:
        return error("วันเริ่มต้องไม่อยู่หลังวันสิ้นสุด")
    if (date_to - date_from).days > 366:
        return error("ดูได้ครั้งละไม่เกิน 1 ปี")

    sql = BASE_SQL + " AND a.created_date >= %s AND a.created_date < %s"
    args = [user["id_business"], date_from, date_to + timedelta(days=1)]
    if tool:
        if tool not in TOOL_LABEL:
            return error("ประเภทไม่ถูกต้อง")
        sql += " AND a.tool_name = %s"
        args.append(tool)
    with get_db() as conn, conn.cursor() as cur:
        # สรุปแยกสถานะ (ก่อนกรองสถานะ)
        cur.execute(f"SELECT a.status, a.error_message {sql}", args)
        counts = {"success": 0, "failed": 0, "cancelled": 0, "pending": 0}
        for r in cur.fetchall():
            counts[state_of(r["status"], r["error_message"])] += 1

        cur.execute(
            f"""SELECT a.id_action AS id, a.tool_name, a.result, a.error_message, a.status, a.created_date,
                       a.target_table, a.target_id, m.content AS command
                {sql} ORDER BY a.id_action DESC LIMIT {MAX_ROWS * 2}""",
            args,
        )
        rows = cur.fetchall()

    items = []
    for r in rows:
        st = state_of(r["status"], r["error_message"])
        if status and st != status:
            continue
        items.append({
            "id": r["id"], "tool": r["tool_name"], "tool_label": TOOL_LABEL.get(r["tool_name"], r["tool_name"]),
            "summary": r["result"], "error": r["error_message"], "status": st,
            "date": r["created_date"].strftime("%d/%m/%Y"), "time": r["created_date"].strftime("%H:%M"),
            "command": (r["command"] or "")[:200],
        })
        if len(items) >= MAX_ROWS:
            break
    return {"ok": True, "counts": counts, "items": items, "more": len(items) >= MAX_ROWS,
            "tools": TOOL_LABEL, "date_from": date_from.isoformat(), "date_to": date_to.isoformat()}


@router.get("/api/ai-log/{id_action}")
def log_detail(id_action: int, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    with get_db() as conn, conn.cursor() as cur:
        cur.execute(
            f"""SELECT a.*, m.content AS command, m.carete_date AS command_date {BASE_SQL} AND a.id_action = %s""",
            (user["id_business"], id_action),
        )
        r = cur.fetchone()
    if not r:
        return error("ไม่พบรายการนี้", 404)
    args = r["arguments"]
    if isinstance(args, str):
        try:
            args = json.loads(args)
        except ValueError:
            pass
    return {"ok": True, "item": {
        "id": r["id_action"], "tool": r["tool_name"], "tool_label": TOOL_LABEL.get(r["tool_name"], r["tool_name"]),
        "status": state_of(r["status"], r["error_message"]), "summary": r["result"], "error": r["error_message"],
        "arguments": args, "model": r["ai_name"], "version": r["version"],
        "target": f"{r['target_table']} #{r['target_id']}" if r["target_table"] else None,
        "date": r["created_date"].strftime("%d/%m/%Y %H:%M:%S"),
        "command": r["command"],
    }}
