-- อัปเดตตาราง Storage: ลบ lot + เพิ่มวันผลิต / วันหมดอายุ
-- รันครั้งเดียว (ข้อมูลเดิมไม่หาย)
-- ถ้าเคยรันไฟล์นี้เวอร์ชันก่อน (ที่เพิ่มวันผลิต/หมดอายุ) ไปแล้ว ให้รันแค่ส่วน "ลบ lot" ด้านล่าง
USE ai_end;

-- เพิ่มวันผลิต / วันหมดอายุ
ALTER TABLE storage_product
  ADD COLUMN mfg_date DATE NULL,      -- วันผลิต
  ADD COLUMN exp_date DATE NULL;      -- วันหมดอายุ
ALTER TABLE storage_equipment
  ADD COLUMN mfg_date DATE NULL,
  ADD COLUMN exp_date DATE NULL;

-- ลบ lot (สินค้า 1 ตัว มีได้ 1 แถวต่อสาขา)
-- เพิ่ม UNIQUE ตัวใหม่ก่อน แล้วค่อยลบตัวเก่า (fk ของ id_branch ต้องมี index ใช้ตลอด)
ALTER TABLE storage_product   ADD UNIQUE KEY uq_sp_new (id_branch, id_product);
ALTER TABLE storage_product   DROP INDEX uq_sp, DROP COLUMN lot;
ALTER TABLE storage_product   RENAME INDEX uq_sp_new TO uq_sp;

ALTER TABLE storage_equipment ADD UNIQUE KEY uq_se_new (id_branch, id_equipment);
ALTER TABLE storage_equipment DROP INDEX uq_se, DROP COLUMN lot;
ALTER TABLE storage_equipment RENAME INDEX uq_se_new TO uq_se;
