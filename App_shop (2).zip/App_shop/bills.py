"""
API ของหน้าประวัติการขาย — เจ้าของร้านดูได้ทุกสาขา / พนักงานดูได้เฉพาะสาขาตัวเอง
  GET /api/bills?store=&date_from=&date_to=&pay=   สรุปยอด + รายการบิลในช่วงวันที่
  GET /api/bills/{id}                               รายละเอียดบิล (สินค้าในบิล)
"""
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Request

from common import error, get_user, resolve_branch
from db import get_db
from sell import PAY_TYPES

router = APIRouter()

MAX_DAYS = 366
MAX_BILLS = 500


def f(x):
    return float(x) if isinstance(x, Decimal) else (x or 0)


@router.get("/api/bills")
def list_bills(request: Request, store: str | None = None, date_from: date | None = None,
               date_to: date | None = None, pay: str = ""):
    user = get_user(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบ", 401)
    today = date.today()
    date_to = date_to or today
    date_from = date_from or date_to
    if date_from > date_to:
        return error("วันเริ่มต้องไม่อยู่หลังวันสิ้นสุด")
    if (date_to - date_from).days >= MAX_DAYS:
        return error("ดูได้ครั้งละไม่เกิน 1 ปี")
    if pay and pay not in PAY_TYPES:
        return error("วิธีจ่ายเงินไม่ถูกต้อง")

    with get_db() as conn, conn.cursor() as cur:
        branch_id, err = resolve_branch(cur, user, store)
        if err:
            return error(err)

        where = """FROM bill b JOIN carete_branch cb ON cb.id_branch = b.id_branch
                   WHERE cb.id_business = %s AND b.sell_date >= %s AND b.sell_date < %s"""
        args = [user["id_business"], date_from, date_to + timedelta(days=1)]
        if branch_id is not None:
            where += " AND b.id_branch = %s"
            args.append(branch_id)
        where_pay = where + (" AND b.type_pay = %s" if pay else "")
        args_pay = args + ([pay] if pay else [])

        # สรุปยอด
        cur.execute(f"SELECT COUNT(*) AS n, COALESCE(SUM(b.total_price),0) AS total, "
                    f"COALESCE(SUM(b.discount),0) AS discount {where_pay}", args_pay)
        s = cur.fetchone()
        summary = {"bills": s["n"], "total": f(s["total"]), "discount": f(s["discount"]),
                   "avg": round(f(s["total"]) / s["n"], 2) if s["n"] else 0}

        # แยกตามวิธีจ่าย (ไม่กรอง pay เพื่อให้เห็นภาพรวม)
        cur.execute(f"SELECT b.type_pay, COUNT(*) AS n, SUM(b.total_price) AS total {where} GROUP BY b.type_pay", args)
        by_pay = [{"type_pay": r["type_pay"], "label": PAY_TYPES.get(r["type_pay"], r["type_pay"]),
                   "bills": r["n"], "total": f(r["total"])} for r in cur.fetchall()]
        by_pay.sort(key=lambda r: -r["total"])

        # รายวัน
        cur.execute(f"SELECT DATE(b.sell_date) AS d, COUNT(*) AS n, SUM(b.total_price) AS total "
                    f"{where_pay} GROUP BY DATE(b.sell_date) ORDER BY d", args_pay)
        days = {r["d"]: r for r in cur.fetchall()}
        by_day = []
        d = date_from
        while d <= date_to:
            r = days.get(d)
            by_day.append({"date": d.strftime("%d/%m"), "bills": r["n"] if r else 0, "total": f(r["total"]) if r else 0})
            d += timedelta(days=1)

        # สินค้าขายดี
        cur.execute(
            f"""SELECT p.name_product AS name, SUM(bi.volume) AS qty, SUM(bi.volume * bi.price) AS total
                FROM bill_item bi
                JOIN storage_product sp ON sp.id_storage_product = bi.id_storage_product
                JOIN product p ON p.id_product = sp.id_product
                WHERE bi.id_bill IN (SELECT b.id_bill {where_pay})
                GROUP BY p.id_product, p.name_product
                ORDER BY total DESC LIMIT 5""",
            args_pay,
        )
        top = [{"name": r["name"], "qty": int(r["qty"]), "total": f(r["total"])} for r in cur.fetchall()]

        # รายการบิล
        cur.execute(
            f"""SELECT b.id_bill AS id, b.sell_date, b.total_price, b.discount, b.type_pay,
                       br.branch_name AS branch, e.name AS employee, pr.name AS promo,
                       (SELECT SUM(bi.volume) FROM bill_item bi WHERE bi.id_bill = b.id_bill) AS qty
                FROM bill b
                JOIN carete_branch cb ON cb.id_branch = b.id_branch
                JOIN branch br ON br.id_branch = b.id_branch
                LEFT JOIN employee e ON e.id_employee = b.id_employee
                LEFT JOIN promotions pr ON pr.id_promotions = b.id_promotions
                {where_pay[where_pay.index('WHERE'):]}
                ORDER BY b.sell_date DESC, b.id_bill DESC
                LIMIT {MAX_BILLS + 1}""",
            args_pay,
        )
        rows = cur.fetchall()

    more = len(rows) > MAX_BILLS
    bills = [{
        "id": r["id"], "no": f"BILL-{r['id']}",
        "date": r["sell_date"].strftime("%d/%m/%Y"), "time": r["sell_date"].strftime("%H:%M"),
        "branch": r["branch"], "seller": r["employee"] or "เจ้าของร้าน",
        "type_pay": PAY_TYPES.get(r["type_pay"], r["type_pay"]),
        "total": f(r["total_price"]), "discount": f(r["discount"]),
        "promo": r["promo"], "qty": int(r["qty"] or 0),
    } for r in rows[:MAX_BILLS]]

    return {"ok": True, "role": user["role"], "summary": summary, "by_pay": by_pay, "by_day": by_day,
            "top": top, "bills": bills, "more": more, "pay_types": PAY_TYPES,
            "date_from": date_from.isoformat(), "date_to": date_to.isoformat()}


@router.get("/api/bills/{bill_id}")
def bill_detail(bill_id: int, request: Request):
    user = get_user(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบ", 401)
    with get_db() as conn, conn.cursor() as cur:
        sql = """SELECT b.id_bill AS id, b.sell_date, b.total_price, b.discount, b.type_pay, b.id_branch,
                        br.branch_name AS branch, e.name AS employee, pr.name AS promo
                 FROM bill b
                 JOIN carete_branch cb ON cb.id_branch = b.id_branch
                 JOIN branch br ON br.id_branch = b.id_branch
                 LEFT JOIN employee e ON e.id_employee = b.id_employee
                 LEFT JOIN promotions pr ON pr.id_promotions = b.id_promotions
                 WHERE b.id_bill = %s AND cb.id_business = %s"""
        args = [bill_id, user["id_business"]]
        if user["role"] == "employee":  # พนักงานดูได้เฉพาะบิลสาขาตัวเอง
            sql += " AND b.id_branch = %s"
            args.append(user["id_branch"])
        cur.execute(sql, args)
        b = cur.fetchone()
        if not b:
            return error("ไม่พบบิลนี้", 404)
        cur.execute(
            """SELECT p.name_product AS name, bi.volume AS quantity, bi.price
               FROM bill_item bi
               JOIN storage_product sp ON sp.id_storage_product = bi.id_storage_product
               JOIN product p ON p.id_product = sp.id_product
               WHERE bi.id_bill = %s ORDER BY bi.id_bill_item""",
            (bill_id,),
        )
        lines = [{"name": r["name"], "quantity": r["quantity"], "price": f(r["price"]),
                  "amount": f(r["price"]) * r["quantity"]} for r in cur.fetchall()]
    total, discount = f(b["total_price"]), f(b["discount"])
    return {"ok": True, "bill": {
        "id": b["id"], "no": f"BILL-{b['id']}", "branch": b["branch"],
        "seller": b["employee"] or "เจ้าของร้าน", "date": b["sell_date"].strftime("%d/%m/%Y %H:%M"),
        "type_pay": PAY_TYPES.get(b["type_pay"], b["type_pay"]), "promo": b["promo"],
        "lines": lines, "subtotal": round(total + discount, 2), "discount": discount, "total": total,
    }}
