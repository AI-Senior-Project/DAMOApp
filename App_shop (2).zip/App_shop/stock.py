"""
API ของหน้าสต็อก
  GET  /api/stores            รายชื่อสาขาที่ผู้ใช้คนนี้เห็นได้
  GET  /api/stock             รายการสต็อก (กรองตามประเภท / สาขา / ค้นหา / ใกล้หมด)
  GET  /api/stock/items       สินค้าทั้งหมดของร้าน (ไว้เลือกตอนเพิ่มเข้าสต็อก)
  POST /api/stock/add         เอาสินค้าเข้าสต็อกของสาขา

การเพิ่ม/ลดจำนวน ไม่ทำที่นี่ → ไปทำผ่าน รับเข้า/เบิกออก ใน movement.py

กฎสิทธิ์:
  - พนักงาน: ดู/แก้ได้เฉพาะสาขาตัวเอง
  - เจ้าของร้าน: ดู/แก้ได้ทุกสาขาในร้านตัวเอง
  - id ร้าน / สาขา ของผู้ใช้ อ่านจาก session เท่านั้น

หมายเหตุ: ใน API ใช้คำว่า store = สาขา (id_branch)
"""
from datetime import date

from fastapi import APIRouter, Request
from pydantic import BaseModel
import pymysql

import config
from common import KINDS, MAX_QTY, error, get_user, resolve_branch
from db import get_db
from movement import MovementError, record_movement

router = APIRouter()


# -----------------------------------------------------------------
# รายชื่อสาขา
# -----------------------------------------------------------------
@router.get("/api/stores")
def stores(request: Request):
    user = get_user(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบ", 401)
    with get_db() as conn, conn.cursor() as cur:
        if user["role"] == "employee":
            cur.execute(
                "SELECT id_branch AS id, branch_name AS name FROM branch WHERE id_branch = %s",
                (user["id_branch"],),
            )
        else:
            cur.execute(
                """SELECT b.id_branch AS id, b.branch_name AS name
                   FROM branch b JOIN carete_branch cb ON cb.id_branch = b.id_branch
                   WHERE cb.id_business = %s ORDER BY b.id_branch""",
                (user["id_business"],),
            )
        return {"ok": True, "role": user["role"], "current": user.get("id_branch"), "stores": cur.fetchall()}


# -----------------------------------------------------------------
# รายการสต็อก
# -----------------------------------------------------------------
@router.get("/api/stock")
def list_stock(request: Request, kind: str = "product", store: str | None = None,
               q: str = "", low: bool = False):
    user = get_user(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบ", 401)
    k = KINDS.get(kind)
    if not k:
        return error("ประเภทไม่ถูกต้อง")

    with get_db() as conn, conn.cursor() as cur:
        branch_id, err = resolve_branch(cur, user, store)
        if err:
            return error(err)

        # last_update = เวลาที่มีการ รับเข้า/เบิกออก ครั้งล่าสุด (ดูจากตาราง transaction)
        sql = f"""
            SELECT s.{k['sid']} AS id_storage, s.quantity, s.mfg_date, s.exp_date,
                   DATEDIFF(s.exp_date, CURDATE()) AS days_left,
                   i.{k['iid']} AS id_item, i.{k['name']} AS name, i.type, i.price,
                   b.id_branch AS id_store, b.branch_name,
                   (SELECT MAX(t.created_at) FROM {k['tx']} t
                     WHERE t.{k['sid']} = s.{k['sid']}) AS last_update
            FROM {k['storage']} s
            JOIN {k['item']} i       ON i.{k['iid']} = s.{k['iid']}
            JOIN branch b            ON b.id_branch = s.id_branch
            JOIN carete_branch cb    ON cb.id_branch = s.id_branch
            WHERE cb.id_business = %s
        """
        args = [user["id_business"]]
        if branch_id is not None:
            sql += " AND s.id_branch = %s"
            args.append(branch_id)
        if q.strip():
            sql += f" AND i.{k['name']} LIKE %s"
            args.append(f"%{q.strip()}%")
        if low:
            sql += " AND s.quantity <= %s"
            args.append(config.LOW_STOCK_LIMIT)
        sql += f" ORDER BY s.quantity ASC, i.{k['name']}"

        cur.execute(sql, args)
        rows = cur.fetchall()

    for r in rows:
        r["price"] = float(r["price"])
        r["last_update"] = r["last_update"].strftime("%d/%m/%Y %H:%M") if r["last_update"] else None
        r["mfg_date"] = r["mfg_date"].strftime("%d/%m/%Y") if r["mfg_date"] else None
        r["exp_date"] = r["exp_date"].strftime("%d/%m/%Y") if r["exp_date"] else None
    return {"ok": True, "items": rows, "low_limit": config.LOW_STOCK_LIMIT}


# -----------------------------------------------------------------
# เพิ่มสินค้าเข้าสต็อกของสาขา
# -----------------------------------------------------------------
@router.get("/api/stock/items")
def shop_items(request: Request, kind: str = "product", store: str | None = None):
    """สินค้าทั้งหมดของร้าน + บอกว่ามีในสต็อกของสาขานี้แล้วหรือยัง"""
    user = get_user(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบ", 401)
    k = KINDS.get(kind)
    if not k:
        return error("ประเภทไม่ถูกต้อง")
    with get_db() as conn, conn.cursor() as cur:
        branch_id, err = resolve_branch(cur, user, store)
        if err:
            return error(err)
        if branch_id is None:
            return error("กรุณาเลือกสาขา")
        cur.execute(
            f"""SELECT i.{k['iid']} AS id_item, i.{k['name']} AS name,
                       EXISTS (SELECT 1 FROM {k['storage']} s
                               WHERE s.{k['iid']} = i.{k['iid']} AND s.id_branch = %s) AS in_stock
                FROM {k['item']} i
                JOIN {k['owner']} o ON o.{k['iid']} = i.{k['iid']}
                WHERE o.id_business = %s
                ORDER BY i.{k['name']}""",
            (branch_id, user["id_business"]),
        )
        items = cur.fetchall()
    for i in items:
        i["in_stock"] = bool(i["in_stock"])
    return {"ok": True, "items": items}


class AddBody(BaseModel):
    kind: str
    id_item: int
    id_store: int | None = None
    quantity: int = 0
    mfg_date: date | None = None   # วันผลิต (YYYY-MM-DD)
    exp_date: date | None = None   # วันหมดอายุ


@router.post("/api/stock/add")
def add_to_stock(body: AddBody, request: Request):
    user = get_user(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบ", 401)
    k = KINDS.get(body.kind)
    if not k:
        return error("ประเภทไม่ถูกต้อง")
    if not (0 <= body.quantity <= MAX_QTY):
        return error("จำนวนต้องอยู่ระหว่าง 0 ถึง 1,000,000")
    if body.mfg_date and body.exp_date and body.exp_date < body.mfg_date:
        return error("วันหมดอายุต้องอยู่หลังวันผลิต")

    with get_db() as conn, conn.cursor() as cur:
        branch_id, err = resolve_branch(cur, user, body.id_store)
        if err:
            return error(err)
        if branch_id is None:
            return error("กรุณาเลือกสาขา")

        # สินค้าต้องเป็นของร้านเรา (เช็กผ่าน carete_product / carete_equipment)
        cur.execute(
            f"SELECT 1 FROM {k['owner']} WHERE {k['iid']} = %s AND id_business = %s",
            (body.id_item, user["id_business"]),
        )
        if not cur.fetchone():
            return error("ไม่พบสินค้านี้ในร้านของคุณ", 404)

        try:
            # สร้างแถวสต็อกด้วยจำนวน 0 ก่อน ...
            cur.execute(
                f"""INSERT INTO {k['storage']} (id_branch, {k['iid']}, quantity, mfg_date, exp_date)
                    VALUES (%s, %s, 0, %s, %s)""",
                (branch_id, body.id_item, body.mfg_date, body.exp_date),
            )
        except pymysql.err.IntegrityError:  # ชน UNIQUE (สาขา, สินค้า)
            return error("สินค้านี้มีอยู่ในสต็อกของสาขานี้แล้ว")
        new_id = cur.lastrowid

        # ... แล้วถ้ามีจำนวนเริ่มต้น ให้ลงเป็น "รับเข้า" จะได้มีประวัติ
        if body.quantity > 0:
            try:
                record_movement(
                    cur, user, branch_id, "receive", "ยอดตั้งต้น", None, None,
                    [{"kind": body.kind, "id_storage": new_id, "quantity": body.quantity}],
                )
            except MovementError as e:
                conn.rollback()
                return error(str(e))
        conn.commit()

    return {"ok": True}
