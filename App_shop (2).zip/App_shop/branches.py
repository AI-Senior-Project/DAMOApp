"""
API ของหน้าสาขา — ใช้ได้เฉพาะเจ้าของร้าน (จัดการสาขาของร้านที่เลือกอยู่)
  GET    /api/branches          สาขาทั้งหมด + ตัวเลขสรุป (พนักงาน สต็อก ยอดขายวันนี้)
  POST   /api/branches          เพิ่มสาขา
  POST   /api/branches/{id}     แก้ไขชื่อ / ที่ตั้ง
  DELETE /api/branches/{id}     ลบ (ได้เฉพาะสาขาที่ไม่มีพนักงาน ไม่มีสต็อก และไม่มีบิล)

ทุกการเปลี่ยนแปลงบันทึกลง history_transaction_user
"""
import pymysql
from fastapi import APIRouter, Request
from pydantic import BaseModel

from common import error
from config import LOW_STOCK_LIMIT
from db import get_db
from products import get_owner, log_edit

router = APIRouter()

FIELDS = ("branch_name", "location")


def select_branch(cur, user, branch_id, lock=False):
    cur.execute(
        """SELECT b.id_branch AS id, b.branch_name, b.location
           FROM branch b JOIN carete_branch cb ON cb.id_branch = b.id_branch
           WHERE b.id_branch = %s AND cb.id_business = %s""" + (" FOR UPDATE" if lock else ""),
        (branch_id, user["id_business"]),
    )
    return cur.fetchone()


@router.get("/api/branches")
def list_branches(request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    with get_db() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT b.id_branch AS id, b.branch_name, b.location, cb.carete_date,
                 (SELECT COUNT(*) FROM carete_employee ce WHERE ce.id_branch = b.id_branch) AS employees,
                 (SELECT COUNT(*) FROM storage_product sp WHERE sp.id_branch = b.id_branch) AS products,
                 (SELECT COUNT(*) FROM storage_equipment se WHERE se.id_branch = b.id_branch) AS equipment,
                 (SELECT COUNT(*) FROM storage_product sp WHERE sp.id_branch = b.id_branch AND sp.quantity <= %s)
                 + (SELECT COUNT(*) FROM storage_equipment se WHERE se.id_branch = b.id_branch AND se.quantity <= %s) AS low_stock,
                 (SELECT COUNT(*) FROM bill bl WHERE bl.id_branch = b.id_branch AND DATE(bl.sell_date) = CURDATE()) AS bills_today,
                 (SELECT COALESCE(SUM(bl.total_price), 0) FROM bill bl
                   WHERE bl.id_branch = b.id_branch AND DATE(bl.sell_date) = CURDATE()) AS sales_today,
                 (SELECT COUNT(*) FROM bill bl WHERE bl.id_branch = b.id_branch) AS bills
               FROM branch b JOIN carete_branch cb ON cb.id_branch = b.id_branch
               WHERE cb.id_business = %s
               ORDER BY b.id_branch""",
            (LOW_STOCK_LIMIT, LOW_STOCK_LIMIT, user["id_business"]),
        )
        rows = cur.fetchall()
    for r in rows:
        r["sales_today"] = float(r["sales_today"])
        r["low_stock"] = int(r["low_stock"])
        r["carete_date"] = r["carete_date"].strftime("%d/%m/%Y") if r["carete_date"] else None
    return {"ok": True, "current": user.get("id_branch"), "items": rows}


class BranchBody(BaseModel):
    branch_name: str
    location: str = ""


def clean_body(body: BranchBody):
    name = body.branch_name.strip()[:100]
    if not name:
        return None, "กรุณาใส่ชื่อสาขา"
    return {"branch_name": name, "location": body.location.strip()[:255] or None}, None


def name_taken(cur, user, name, skip_id=None):
    cur.execute(
        """SELECT 1 FROM branch b JOIN carete_branch cb ON cb.id_branch = b.id_branch
           WHERE cb.id_business = %s AND b.branch_name = %s AND b.id_branch <> %s""",
        (user["id_business"], name, skip_id or 0),
    )
    return cur.fetchone() is not None


@router.post("/api/branches")
def create_branch(body: BranchBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    v, err = clean_body(body)
    if err:
        return error(err)
    with get_db() as conn, conn.cursor() as cur:
        if name_taken(cur, user, v["branch_name"]):
            return error("มีสาขาชื่อนี้อยู่แล้ว")
        cur.execute("INSERT INTO branch (branch_name, location) VALUES (%s, %s)", (v["branch_name"], v["location"]))
        new_id = cur.lastrowid
        cur.execute("INSERT INTO carete_branch (id_branch, id_business) VALUES (%s, %s)", (new_id, user["id_business"]))
        log_edit(cur, {**user, "id_branch": new_id}, "branch", new_id, "create", new=v)
        conn.commit()
    return {"ok": True, "id": new_id}


@router.post("/api/branches/{branch_id}")
def update_branch(branch_id: int, body: BranchBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    v, err = clean_body(body)
    if err:
        return error(err)
    with get_db() as conn, conn.cursor() as cur:
        old = select_branch(cur, user, branch_id, lock=True)
        if not old:
            return error("ไม่พบสาขานี้ในร้านของคุณ", 404)
        changed = [f for f in FIELDS if old[f] != v[f]]
        if not changed:
            return {"ok": True, "changed": False}
        if "branch_name" in changed and name_taken(cur, user, v["branch_name"], branch_id):
            return error("มีสาขาชื่อนี้อยู่แล้ว")
        cur.execute("UPDATE branch SET branch_name = %s, location = %s WHERE id_branch = %s",
                    (v["branch_name"], v["location"], branch_id))
        log_edit(cur, {**user, "id_branch": branch_id}, "branch", branch_id, "update",
                 old={f: old[f] for f in changed}, new={f: v[f] for f in changed})
        conn.commit()
    return {"ok": True, "changed": True}


@router.delete("/api/branches/{branch_id}")
def delete_branch(branch_id: int, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    with get_db() as conn, conn.cursor() as cur:
        old = select_branch(cur, user, branch_id, lock=True)
        if not old:
            return error("ไม่พบสาขานี้ในร้านของคุณ", 404)
        cur.execute("SELECT COUNT(*) AS n FROM carete_branch WHERE id_business = %s", (user["id_business"],))
        if cur.fetchone()["n"] <= 1:
            return error("ลบไม่ได้ ร้านต้องมีอย่างน้อย 1 สาขา")
        cur.execute(
            """SELECT (SELECT COUNT(*) FROM carete_employee WHERE id_branch = %s) AS emp,
                      (SELECT COUNT(*) FROM storage_product WHERE id_branch = %s)
                    + (SELECT COUNT(*) FROM storage_equipment WHERE id_branch = %s) AS stock,
                      (SELECT COUNT(*) FROM bill WHERE id_branch = %s) AS bills""",
            (branch_id,) * 4,
        )
        used = cur.fetchone()
        if used["emp"]:
            return error(f"ลบไม่ได้ ยังมีพนักงาน {used['emp']} คน ย้ายไปสาขาอื่นก่อน")
        if used["stock"] or used["bills"]:
            return error("ลบไม่ได้ เพราะสาขานี้มีสต็อกหรือบิลขายแล้ว")
        try:
            # ประวัติการแก้ไขยังเก็บไว้ แค่ตัดการผูกกับสาขานี้
            cur.execute("UPDATE history_transaction_user SET id_branch = NULL WHERE id_branch = %s", (branch_id,))
            cur.execute("DELETE FROM branch WHERE id_branch = %s", (branch_id,))  # carete_branch ลบตาม (CASCADE)
        except pymysql.err.IntegrityError:
            conn.rollback()
            return error("ลบไม่ได้ เพราะสาขานี้ยังถูกใช้งานอยู่")
        log_edit(cur, {**user, "id_branch": None}, "branch", branch_id, "delete", old=old)
        conn.commit()
    # ถ้าลบสาขาที่เลือกใช้อยู่ ให้เปลี่ยนเป็น "ทุกสาขา"
    if user.get("id_branch") == branch_id:
        request.session["user"] = {**user, "id_branch": None}
    return {"ok": True}
