"""
เพิ่มบัญชี / สาขา ลงฐานข้อมูล (รหัสผ่านถูก hash ให้อัตโนมัติ)

ใช้แบบนี้ (พิมพ์ใน PowerShell ที่โฟลเดอร์ App_shop):

  เพิ่มเจ้าของร้าน + ร้านใหม่
    py add_account.py owner <อีเมล> <รหัสผ่าน> "<ชื่อเจ้าของ>" "<ชื่อร้าน>"
    py add_account.py owner somsri@mail.com 1234 "สมศรี" "ร้านขนมสมศรี"

  เพิ่มสาขาให้ร้าน (อ้างอิงร้านจากอีเมลเจ้าของ)
    py add_account.py branch <อีเมลเจ้าของ> "<ชื่อสาขา>" "<ที่ตั้ง>"
    py add_account.py branch somsri@mail.com "สาขาบางนา" "กรุงเทพ"

  เพิ่มพนักงาน (ใส่เลขสาขา — ดูได้จากคำสั่ง list)
    py add_account.py employee <รหัสพนักงาน> <รหัสผ่าน> "<ชื่อ>" <เลขสาขา> [ตำแหน่ง]
    py add_account.py employee emp002 1234 "สมหญิง" 1 cashier

  ดูบัญชีทั้งหมด
    py add_account.py list
"""
import sys

import bcrypt
import pymysql

from db import get_db


def hash_pw(password: str) -> str:
    if len(password.encode("utf-8")) > 72:
        sys.exit("❌ รหัสผ่านยาวเกินไป (ไม่เกิน 72 ตัวอักษรภาษาอังกฤษ)")
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def usage():
    print(__doc__)
    sys.exit(1)


def add_owner(cur, email, password, name, shop):
    cur.execute(
        "INSERT INTO `user` (name, email, password) VALUES (%s, %s, %s)",
        (name, email, hash_pw(password)),
    )
    id_user = cur.lastrowid
    cur.execute(
        "INSERT INTO business (id_user, name_model, name_brand) VALUES (%s, %s, %s)",
        (id_user, shop, shop),
    )
    print(f"✅ เพิ่มเจ้าของร้าน {name} ({email}) และร้าน \"{shop}\" แล้ว")
    print("   ต่อไป: เพิ่มสาขาด้วยคำสั่ง branch")


def add_branch(cur, owner_email, branch_name, location):
    cur.execute(
        """SELECT b.id_business FROM business b JOIN `user` u ON u.id_user = b.id_user
           WHERE u.email = %s ORDER BY b.id_business LIMIT 1""",
        (owner_email,),
    )
    row = cur.fetchone()
    if not row:
        sys.exit(f"❌ ไม่เจอร้านของ {owner_email} (เพิ่มเจ้าของร้านก่อน)")
    cur.execute("INSERT INTO branch (branch_name, location) VALUES (%s, %s)", (branch_name, location))
    id_branch = cur.lastrowid
    cur.execute(
        "INSERT INTO carete_branch (id_branch, id_business) VALUES (%s, %s)",
        (id_branch, row["id_business"]),
    )
    print(f"✅ เพิ่มสาขา \"{branch_name}\" แล้ว  → เลขสาขา = {id_branch}")


def add_employee(cur, id_login, password, name, id_branch, position):
    cur.execute("SELECT branch_name FROM branch WHERE id_branch = %s", (id_branch,))
    row = cur.fetchone()
    if not row:
        sys.exit(f"❌ ไม่มีสาขาเลข {id_branch} (ดูเลขสาขาด้วยคำสั่ง list)")
    cur.execute(
        "INSERT INTO employee (name, position, id_login, password_login) VALUES (%s, %s, %s, %s)",
        (name, position, id_login, hash_pw(password)),
    )
    cur.execute(
        "INSERT INTO carete_employee (id_employee, id_branch) VALUES (%s, %s)",
        (cur.lastrowid, id_branch),
    )
    print(f"✅ เพิ่มพนักงาน {name} (รหัส {id_login}) ที่ {row['branch_name']} แล้ว")


def list_all(cur):
    cur.execute(
        """SELECT u.email, u.name AS owner, b.name_brand
           FROM `user` u LEFT JOIN business b ON b.id_user = u.id_user ORDER BY u.id_user"""
    )
    print("\n== เจ้าของร้าน ==")
    for r in cur.fetchall():
        print(f"  {r['email']:<28} {r['owner']}  ร้าน: {r['name_brand'] or '-'}")

    cur.execute(
        """SELECT br.id_branch, br.branch_name, b.name_brand
           FROM branch br
           LEFT JOIN carete_branch cb ON cb.id_branch = br.id_branch
           LEFT JOIN business b ON b.id_business = cb.id_business
           ORDER BY br.id_branch"""
    )
    print("\n== สาขา ==")
    for r in cur.fetchall():
        print(f"  เลข {r['id_branch']:<4} {r['branch_name']}  ({r['name_brand'] or 'ไม่มีร้าน'})")

    cur.execute(
        """SELECT e.id_login, e.name, br.branch_name
           FROM employee e
           LEFT JOIN carete_employee ce ON ce.id_employee = e.id_employee
           LEFT JOIN branch br ON br.id_branch = ce.id_branch
           ORDER BY e.id_employee"""
    )
    print("\n== พนักงาน ==")
    for r in cur.fetchall():
        print(f"  {r['id_login']:<12} {r['name']}  ({r['branch_name'] or 'ไม่มีสาขา'})")
    print()


def main():
    args = sys.argv[1:]
    if not args:
        usage()
    cmd = args[0]

    with get_db() as conn, conn.cursor() as cur:
        try:
            if cmd == "owner" and len(args) == 5:
                add_owner(cur, *args[1:])
            elif cmd == "branch" and len(args) in (3, 4):
                add_branch(cur, args[1], args[2], args[3] if len(args) == 4 else None)
            elif cmd == "employee" and len(args) in (5, 6):
                if not args[4].isdigit():
                    sys.exit("❌ เลขสาขาต้องเป็นตัวเลข")
                add_employee(cur, args[1], args[2], args[3], int(args[4]), args[5] if len(args) == 6 else None)
            elif cmd == "list" and len(args) == 1:
                list_all(cur)
                return
            else:
                usage()
        except pymysql.err.IntegrityError as e:
            conn.rollback()
            if e.args and e.args[0] == 1062:  # ค่าซ้ำ
                sys.exit("❌ อีเมล / รหัสพนักงานนี้มีอยู่แล้ว")
            raise
        conn.commit()


if __name__ == "__main__":
    main()
