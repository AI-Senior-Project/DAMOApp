"""
API ของหน้าพนักงาน — ใช้ได้เฉพาะเจ้าของร้าน
  GET    /api/employees?store=          พนักงานของร้าน (กรองสาขาได้)
  POST   /api/employees                 เพิ่ม
  POST   /api/employees/{id}            แก้ไข (ชื่อ ตำแหน่ง เงินเดือน ย้ายสาขา)
  POST   /api/employees/{id}/password   รีเซ็ตรหัสผ่าน
  DELETE /api/employees/{id}            ลบ (ได้เฉพาะคนที่ยังไม่เคยขายของ/ทำรายการสต็อก)

ทุกการเปลี่ยนแปลงบันทึกลง history_transaction_user (ไม่บันทึกรหัสผ่าน)
"""
from decimal import Decimal

import bcrypt
import pymysql
from fastapi import APIRouter, Request
from pydantic import BaseModel

from common import error, resolve_branch
from db import get_db
from products import get_owner, log_edit

router = APIRouter()

FIELDS = ("name", "position", "salary", "id_branch")


def hash_pw(password: str):
    if not (4 <= len(password) and len(password.encode("utf-8")) <= 72):
        return None
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def branch_in_business(cur, user, id_branch):
    cur.execute(
        "SELECT 1 FROM carete_branch WHERE id_branch = %s AND id_business = %s",
        (id_branch, user["id_business"]),
    )
    return cur.fetchone() is not None


def select_employee(cur, user, emp_id, lock=False):
    cur.execute(
        """SELECT e.id_employee AS id, e.name, e.position, e.salary, e.id_login, ce.id_branch
           FROM employee e
           JOIN carete_employee ce ON ce.id_employee = e.id_employee
           JOIN carete_branch cb   ON cb.id_branch = ce.id_branch
           WHERE e.id_employee = %s AND cb.id_business = %s""" + (" FOR UPDATE" if lock else ""),
        (emp_id, user["id_business"]),
    )
    row = cur.fetchone()
    if row and isinstance(row["salary"], Decimal):
        row["salary"] = float(row["salary"])
    return row


# -----------------------------------------------------------------
# รายการ
# -----------------------------------------------------------------
@router.get("/api/employees")
def list_employees(request: Request, store: str | None = None):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    with get_db() as conn, conn.cursor() as cur:
        branch_id, err = resolve_branch(cur, user, store)
        if err:
            return error(err)
        sql = """
            SELECT e.id_employee AS id, e.name, e.position, e.salary, e.id_login,
                   b.id_branch, b.branch_name, ce.carete_date
            FROM employee e
            JOIN carete_employee ce ON ce.id_employee = e.id_employee
            JOIN carete_branch cb   ON cb.id_branch = ce.id_branch
            JOIN branch b           ON b.id_branch = ce.id_branch
            WHERE cb.id_business = %s
        """
        args = [user["id_business"]]
        if branch_id is not None:
            sql += " AND ce.id_branch = %s"
            args.append(branch_id)
        sql += " ORDER BY b.id_branch, e.name"
        cur.execute(sql, args)
        rows = cur.fetchall()
    for r in rows:
        r["salary"] = float(r["salary"]) if r["salary"] is not None else None
        r["carete_date"] = r["carete_date"].strftime("%d/%m/%Y") if r["carete_date"] else None
    return {"ok": True, "items": rows}


# -----------------------------------------------------------------
# เพิ่ม / แก้ไข
# -----------------------------------------------------------------
class EmployeeBody(BaseModel):
    name: str
    position: str = ""
    salary: float | None = None
    id_branch: int
    id_login: str = ""      # ใช้ตอนเพิ่มเท่านั้น
    password: str = ""      # ใช้ตอนเพิ่มเท่านั้น


def clean_body(body: EmployeeBody):
    name = body.name.strip()[:100]
    if not name:
        return None, "กรุณาใส่ชื่อ"
    if body.salary is not None and not (0 <= body.salary <= 10_000_000):
        return None, "เงินเดือนไม่ถูกต้อง"
    return {
        "name": name,
        "position": body.position.strip()[:50] or None,
        "salary": round(body.salary, 2) if body.salary is not None else None,
        "id_branch": body.id_branch,
    }, None


@router.post("/api/employees")
def create_employee(body: EmployeeBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    v, err = clean_body(body)
    if err:
        return error(err)
    id_login = body.id_login.strip()[:50]
    if not id_login:
        return error("กรุณาใส่รหัสพนักงาน (ใช้ล็อกอิน)")
    hashed = hash_pw(body.password)
    if not hashed:
        return error("รหัสผ่านต้องยาว 4 ตัวขึ้นไป")

    with get_db() as conn, conn.cursor() as cur:
        if not branch_in_business(cur, user, v["id_branch"]):
            return error("ไม่พบสาขานี้ในร้านของคุณ")
        try:
            cur.execute(
                "INSERT INTO employee (name, position, salary, id_login, password_login) VALUES (%s, %s, %s, %s, %s)",
                (v["name"], v["position"], v["salary"], id_login, hashed),
            )
        except pymysql.err.IntegrityError:
            return error("รหัสพนักงานนี้มีคนใช้แล้ว")
        new_id = cur.lastrowid
        cur.execute("INSERT INTO carete_employee (id_employee, id_branch) VALUES (%s, %s)", (new_id, v["id_branch"]))
        log_edit(cur, {**user, "id_branch": v["id_branch"]}, "employee", new_id, "create", new={**v, "id_login": id_login})
        conn.commit()
    return {"ok": True, "id": new_id}


@router.post("/api/employees/{emp_id}")
def update_employee(emp_id: int, body: EmployeeBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    v, err = clean_body(body)
    if err:
        return error(err)
    with get_db() as conn, conn.cursor() as cur:
        old = select_employee(cur, user, emp_id, lock=True)
        if not old:
            return error("ไม่พบพนักงานคนนี้ในร้านของคุณ", 404)
        if v["id_branch"] != old["id_branch"] and not branch_in_business(cur, user, v["id_branch"]):
            return error("ไม่พบสาขานี้ในร้านของคุณ")
        changed = [f for f in FIELDS if old[f] != v[f]]
        if not changed:
            return {"ok": True, "changed": False}
        cur.execute(
            "UPDATE employee SET name = %s, position = %s, salary = %s WHERE id_employee = %s",
            (v["name"], v["position"], v["salary"], emp_id),
        )
        if "id_branch" in changed:  # ย้ายสาขา
            cur.execute(
                "UPDATE carete_employee SET id_branch = %s, carete_date = NOW() WHERE id_employee = %s",
                (v["id_branch"], emp_id),
            )
        log_edit(cur, {**user, "id_branch": v["id_branch"]}, "employee", emp_id, "update",
                 old={f: old[f] for f in changed}, new={f: v[f] for f in changed})
        conn.commit()
    return {"ok": True, "changed": True}


class PasswordBody(BaseModel):
    password: str


@router.post("/api/employees/{emp_id}/password")
def reset_password(emp_id: int, body: PasswordBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    hashed = hash_pw(body.password)
    if not hashed:
        return error("รหัสผ่านต้องยาว 4 ตัวขึ้นไป")
    with get_db() as conn, conn.cursor() as cur:
        old = select_employee(cur, user, emp_id, lock=True)
        if not old:
            return error("ไม่พบพนักงานคนนี้ในร้านของคุณ", 404)
        cur.execute("UPDATE employee SET password_login = %s WHERE id_employee = %s", (hashed, emp_id))
        # บันทึกว่ามีการรีเซ็ต แต่ไม่เก็บรหัสผ่าน
        log_edit(cur, {**user, "id_branch": old["id_branch"]}, "employee", emp_id, "update",
                 old={"password": "***"}, new={"password": "reset"})
        conn.commit()
    return {"ok": True}


@router.delete("/api/employees/{emp_id}")
def delete_employee(emp_id: int, request: Request):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    with get_db() as conn, conn.cursor() as cur:
        old = select_employee(cur, user, emp_id, lock=True)
        if not old:
            return error("ไม่พบพนักงานคนนี้ในร้านของคุณ", 404)
        try:
            # carete_employee ถูกลบตามอัตโนมัติ (ON DELETE CASCADE)
            cur.execute("DELETE FROM employee WHERE id_employee = %s", (emp_id,))
        except pymysql.err.IntegrityError:
            conn.rollback()
            return error("ลบไม่ได้ เพราะพนักงานคนนี้เคยขายของหรือทำรายการสต็อกแล้ว ให้เปลี่ยนรหัสผ่านเพื่อปิดการเข้าใช้แทน")
        log_edit(cur, {**user, "id_branch": old["id_branch"]}, "employee", emp_id, "delete", old=old)
        conn.commit()
    return {"ok": True}
