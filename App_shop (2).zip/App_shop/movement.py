"""
API ของหน้า รับเข้า / เบิกออก / ปรับยอด
  POST /api/movement     ทำรายการ (ใส่ได้หลายสินค้าในครั้งเดียว)
  GET  /api/movement     ประวัติย้อนหลัง

ตาราง (ตาม ERD): transaction_product / transaction_equipment  — 1 แถว = สินค้า 1 รายการ
ทำหลายรายการพร้อมกัน → ทุกแถวได้ created_at เดียวกัน หน้าประวัติเลยจับกลุ่มกลับเป็น "ครั้งเดียวกัน" ได้

ทุกการเปลี่ยนจำนวนสต็อกต้องผ่าน record_movement() เท่านั้น
(ฝั่ง AI ก็ให้เรียกฟังก์ชันนี้ด้วย)
"""
from datetime import date

from fastapi import APIRouter, Request
from pydantic import BaseModel

from common import KINDS, MAX_QTY, error, get_user, resolve_branch
from db import get_db

router = APIRouter()

TYPE_LABEL = {"receive": "รับเข้า", "issue": "เบิกออก", "adjust": "ปรับยอด"}
MAX_LINES = 50


class MovementError(Exception):
    """ทำรายการไม่ได้ (ข้อความนี้ส่งกลับไปให้ผู้ใช้อ่าน)"""


def record_movement(cur, user, branch_id, mtype, reason, note, reference_no, lines):
    """
    ปรับสต็อก + บันทึกประวัติ (ยังไม่ commit — ให้คนเรียก commit เอง)
    lines = [{"kind": "product", "id_storage": 1, "quantity": 5,
              "mfg_date": date | None, "exp_date": date | None}, ...]   ← วัน: ไม่ส่ง/None = ไม่เปลี่ยน
      receive → quantity = จำนวนที่รับเข้า (> 0)
      issue   → quantity = จำนวนที่เบิกออก (> 0)
      adjust  → quantity = จำนวนที่นับได้จริง (>= 0)
    """
    if mtype not in TYPE_LABEL:
        raise MovementError("ประเภทรายการไม่ถูกต้อง")
    if not lines:
        raise MovementError("ต้องมีอย่างน้อย 1 รายการ")
    if len(lines) > MAX_LINES:
        raise MovementError(f"ใส่ได้ไม่เกิน {MAX_LINES} รายการต่อครั้ง")

    seen = set()
    for ln in lines:
        if ln["kind"] not in KINDS:
            raise MovementError("ประเภทสินค้าไม่ถูกต้อง")
        key = (ln["kind"], ln["id_storage"])
        if key in seen:
            raise MovementError("มีสินค้าซ้ำกัน ให้รวมเป็นบรรทัดเดียว")
        seen.add(key)
        q = ln["quantity"]
        if mtype == "adjust":
            if not (0 <= q <= MAX_QTY):
                raise MovementError("จำนวนที่นับได้ต้องอยู่ระหว่าง 0 ถึง 1,000,000")
        elif not (0 < q <= MAX_QTY):
            raise MovementError("จำนวนต้องมากกว่า 0")
        mfg, exp = ln.get("mfg_date"), ln.get("exp_date")
        if mfg and exp and exp < mfg:
            raise MovementError("วันหมดอายุต้องอยู่หลังวันผลิต")

    # รวม เหตุผล + หมายเหตุ ลงช่อง details
    details = " · ".join(x.strip() for x in (reason or "", note or "") if x and x.strip())[:255] or None
    reference_no = (reference_no or "").strip()[:50] or None
    id_employee = user["id"] if user["role"] == "employee" else None  # NULL = เจ้าของร้าน

    # ใช้เวลาเดียวกันทุกแถว → หน้าประวัติจับกลุ่มได้
    cur.execute("SELECT NOW() AS now")
    now = cur.fetchone()["now"]

    results = []
    for ln in lines:
        k = KINDS[ln["kind"]]
        # เช็กว่าเป็นสต็อกของสาขานี้ + ล็อกแถวไว้จนกว่าจะ commit (FOR UPDATE กันแก้พร้อมกัน)
        cur.execute(
            f"""SELECT s.quantity, i.{k['name']} AS name
                FROM {k['storage']} s JOIN {k['item']} i ON i.{k['iid']} = s.{k['iid']}
                WHERE s.{k['sid']} = %s AND s.id_branch = %s
                FOR UPDATE""",
            (ln["id_storage"], branch_id),
        )
        row = cur.fetchone()
        if not row:
            raise MovementError("มีรายการที่ไม่อยู่ในสต็อกของสาขานี้")

        before = row["quantity"]
        q = ln["quantity"]
        change = q if mtype == "receive" else -q if mtype == "issue" else q - before
        after = before + change
        if after < 0:
            raise MovementError(f"{row['name']} มีไม่พอให้เบิก (เหลือ {before}, จะเบิก {q})")

        # วันผลิต / หมดอายุ: ส่งมาเฉพาะช่องที่จะเปลี่ยน (None = คงค่าเดิม)
        mfg, exp = ln.get("mfg_date"), ln.get("exp_date")
        cur.execute(
            f"""UPDATE {k['storage']}
                SET quantity = %s, mfg_date = COALESCE(%s, mfg_date), exp_date = COALESCE(%s, exp_date)
                WHERE {k['sid']} = %s""",
            (after, mfg, exp, ln["id_storage"]),
        )
        cur.execute(
            f"""INSERT INTO {k['tx']}
                  (id_employee, {k['sid']}, transaction_type, quantity_changed,
                   balance_before, balance_after, details, reference_no, mfg_date, exp_date, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (id_employee, ln["id_storage"], mtype, change, before, after, details, reference_no, mfg, exp, now),
        )
        results.append({"name": row["name"], "dates": dates_text(mfg, exp), "before": before, "change": change, "after": after})

    return results


def dates_text(mfg, exp):
    parts = []
    if mfg:
        parts.append(f"ผลิต {mfg.strftime('%d/%m/%Y')}")
    if exp:
        parts.append(f"หมดอายุ {exp.strftime('%d/%m/%Y')}")
    return " · ".join(parts) or None


# -----------------------------------------------------------------
# ทำรายการ
# -----------------------------------------------------------------
class Line(BaseModel):
    kind: str
    id_storage: int
    quantity: int
    mfg_date: date | None = None
    exp_date: date | None = None


class MovementBody(BaseModel):
    type: str
    id_store: int | None = None
    reason: str | None = None
    note: str | None = None
    reference_no: str | None = None
    lines: list[Line]


@router.post("/api/movement")
def create_movement(body: MovementBody, request: Request):
    user = get_user(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบ", 401)

    with get_db() as conn, conn.cursor() as cur:
        branch_id, err = resolve_branch(cur, user, body.id_store)
        if err:
            return error(err)
        if branch_id is None:
            return error("กรุณาเลือกสาขา")
        try:
            results = record_movement(
                cur, user, branch_id, body.type, body.reason, body.note, body.reference_no,
                [ln.model_dump() for ln in body.lines],
            )
        except MovementError as e:
            conn.rollback()  # ยกเลิกทั้งหมด ไม่มีรายการไหนถูกบันทึกครึ่งๆ กลางๆ
            return error(str(e))
        conn.commit()

    return {"ok": True, "results": results}


# -----------------------------------------------------------------
# ประวัติ
# -----------------------------------------------------------------
def _history_sql(k):
    return f"""
        SELECT '{k['item']}' AS kind, t.{k['txid']} AS id, t.transaction_type, t.quantity_changed,
               t.balance_before, t.balance_after, t.details, t.reference_no, t.created_at,
               t.mfg_date, t.exp_date,
               t.id_employee, e.name AS emp_name, i.{k['name']} AS name,
               b.id_branch, b.branch_name
        FROM {k['tx']} t
        JOIN {k['storage']} s      ON s.{k['sid']} = t.{k['sid']}
        JOIN {k['item']} i         ON i.{k['iid']} = s.{k['iid']}
        JOIN branch b              ON b.id_branch = s.id_branch
        JOIN carete_branch cb      ON cb.id_branch = s.id_branch
        LEFT JOIN employee e       ON e.id_employee = t.id_employee
        WHERE cb.id_business = %s {{branch}} {{type}}
    """


@router.get("/api/movement")
def list_movements(request: Request, store: str | None = None, type: str = "", limit: int = 300):
    user = get_user(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบ", 401)
    limit = max(1, min(limit, 1000))

    with get_db() as conn, conn.cursor() as cur:
        branch_id, err = resolve_branch(cur, user, store)
        if err:
            return error(err)

        branch_sql = "" if branch_id is None else "AND s.id_branch = %s"
        type_sql = "AND t.transaction_type = %s" if type in TYPE_LABEL else ""
        one_args = [user["id_business"]]
        if branch_id is not None:
            one_args.append(branch_id)
        if type_sql:
            one_args.append(type)

        parts = [_history_sql(k).format(branch=branch_sql, type=type_sql) for k in KINDS.values()]
        sql = " UNION ALL ".join(f"({p})" for p in parts) + " ORDER BY created_at DESC, id DESC LIMIT %s"
        cur.execute(sql, one_args * len(parts) + [limit])
        rows = cur.fetchall()

        # ชื่อเจ้าของร้าน (ใช้แสดงแถวที่ id_employee = NULL)
        cur.execute(
            "SELECT u.name FROM business b JOIN `user` u ON u.id_user = b.id_user WHERE b.id_business = %s",
            (user["id_business"],),
        )
        owner = cur.fetchone()
        owner_name = owner["name"] if owner else "เจ้าของร้าน"

    # จับกลุ่มแถวที่ทำพร้อมกัน (เวลาเดียวกัน + คนเดียวกัน + ประเภทเดียวกัน + สาขาเดียวกัน)
    groups = {}
    for r in rows:
        key = (r["created_at"], r["id_employee"], r["transaction_type"], r["id_branch"], r["details"], r["reference_no"])
        g = groups.get(key)
        if not g:
            g = groups[key] = {
                "type": r["transaction_type"],
                "type_label": TYPE_LABEL[r["transaction_type"]],
                "details": r["details"],
                "reference_no": r["reference_no"],
                "created_at": r["created_at"].strftime("%d/%m/%Y %H:%M"),
                "branch_name": r["branch_name"],
                "who": r["emp_name"] or owner_name,
                "lines": [],
            }
        g["lines"].append({
            "name": r["name"],
            "dates": dates_text(r["mfg_date"], r["exp_date"]),
            "qty_before": r["balance_before"],
            "qty_change": r["quantity_changed"],
            "qty_after": r["balance_after"],
        })
    return {"ok": True, "items": list(groups.values())}
