"""การเชื่อมต่อ MySQL — ไฟล์อื่นเรียก get_db() จากที่นี่"""
import pymysql
from pymysql.constants import CLIENT

import config

DB_CONFIG = {
    "host": config.DB_HOST,
    "port": config.DB_PORT,
    "user": config.DB_USER,
    "password": config.DB_PASSWORD,
    "database": config.DB_NAME,
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor,  # ให้ผลลัพธ์ออกมาเป็น dict
    # ให้ UPDATE นับแถวที่ "เจอ" ไม่ใช่แค่แถวที่ "ค่าเปลี่ยน"
    # (ไม่งั้นตั้งจำนวนเป็นค่าเดิม จะได้ 0 แถว แล้วนึกว่าไม่เจอข้อมูล)
    "client_flag": CLIENT.FOUND_ROWS,
}


def get_db():
    return pymysql.connect(**DB_CONFIG)
