"""
เครื่องมือที่ผู้ช่วย AI เรียกใช้ได้ (ย้ายมาจาก Ai_shop/tools.py ให้ใช้ตารางตาม ERD_App_16)

หลักสำคัญ (เหมือนเดิม):
- AI แค่บอกว่าอยากเรียกเครื่องมือไหน ด้วยค่าอะไร โค้ดเป็นคนตรวจและทำจริง
- ร้าน / สาขา / คนสั่ง มาจาก session ที่ล็อกอินเสมอ AI เลือกเองไม่ได้
- ตัวเลขทุกตัว (ยอดคงเหลือ ราคาหลังลด) คำนวณในโค้ด

เครื่องมือมี 2 แบบ:
- แบบอ่าน (READ_TOOLS)   ทำทันที คืน dict
- แบบแก้ไข (WRITE_TOOLS) คืน (ข้อความสรุป, do) — do(cur) คือฟังก์ชันที่ทำจริง เรียกหลังผู้ใช้กดยืนยัน
  do คืน dict ที่มี target_table / target_id ไว้ลง ai_action_log

ทุกฟังก์ชันรับ ctx (ข้อมูลคนที่ล็อกอิน) กับ cur (cursor ของ DB) เป็นสองค่าแรก
ctx = {"user": dict ใน session, "id_business": .., "id_branch": .. หรือ None, "branch_name": ..}

สิ่งที่เปลี่ยนจากเวอร์ชันเก่า:
- สต็อกแยกตามสาขา: ดูจำนวน = สาขาที่เลือกอยู่ (ถ้าเลือก "ทุกสาขา" = รวมทุกสาขา)
  เพิ่ม/ลดสต็อก ต้องเลือกสาขาก่อน และผ่าน record_movement() เหมือนหน้ารับเข้า/เบิกออก
- โปรที่ AI สร้าง = เปิดใช้เลย (active) เพราะเจ้าของกดยืนยันในแชทแล้ว
- รูป: ผู้ใช้กดแนบรูปในหน้าแชท ระบบเก็บไฟล์ไว้ที่ uploads/ แล้วส่งที่อยู่มาในข้อความ
"""
import calendar
import datetime
import inspect
import math
import re
from pathlib import Path

from common import KINDS, MAX_QTY
from movement import MovementError, record_movement
from products import log_edit

MAX_PRICE = 99_999_999.99      # เท่ากับที่ DECIMAL(10,2) เก็บได้
AI_REASON = "สั่งผ่านผู้ช่วย AI"
UPLOAD_DIR = Path(__file__).resolve().parent / "uploads"

LABEL = {"product": "สินค้า", "equipment": "อุปกรณ์"}


class ToolError(Exception):
    """ข้อผิดพลาดที่อธิบายให้โมเดลกับผู้ใช้อ่านได้ เช่น ไม่พบสินค้า"""


# =====================================================================
# ตัวช่วยตรวจค่า
# =====================================================================
def _is_blank(value):
    return value is None or str(value).strip() == ""


def _to_number(value, label):
    """โมเดลตัวเล็กชอบส่งตัวเลขมาเป็นข้อความ"""
    if isinstance(value, bool) or _is_blank(value):
        raise ToolError(f"{label} ต้องเป็นตัวเลข")
    try:
        number = float(str(value).replace(",", "").strip())
    except ValueError:
        raise ToolError(f"{label} ต้องเป็นตัวเลข แต่ได้รับ '{value}'") from None
    if not math.isfinite(number):
        raise ToolError(f"{label} ต้องเป็นตัวเลข")
    return number


def _to_int(value, label):
    number = _to_number(value, label)
    if number != int(number):
        raise ToolError(f"{label} ต้องเป็นจำนวนเต็ม")
    return int(number)


def _to_price(value, label="ราคา"):
    price = round(_to_number(value, label), 2)
    if price < 0:
        raise ToolError(f"{label} ห้ามติดลบ")
    if price > MAX_PRICE:
        raise ToolError(f"{label} สูงเกินไป")
    return price


def _to_qty(value, label="จำนวน"):
    q = 0 if _is_blank(value) else _to_int(value, label)
    if q < 0:
        raise ToolError(f"{label}ห้ามติดลบ")
    if q > MAX_QTY:
        raise ToolError(f"{label}มากเกินไป (ไม่เกิน {MAX_QTY:,})")
    return q


def _to_datetime(value, label, end_of_day=False):
    """รับวันที่แบบ YYYY-MM-DD (จะมีเวลาต่อท้ายหรือไม่ก็ได้) ปี พ.ศ. แปลงเป็น ค.ศ. ให้"""
    text = "" if value is None else str(value).strip().replace("T", " ")
    result = None
    for pattern in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            result = datetime.datetime.strptime(text, pattern)
            break
        except ValueError:
            pass
    if result is None:
        try:
            result = datetime.datetime.strptime(text, "%Y-%m-%d")
        except ValueError:
            raise ToolError(f"{label} ต้องอยู่ในรูปแบบ YYYY-MM-DD แต่ได้รับ '{value}'") from None
        if end_of_day:
            result = result.replace(hour=23, minute=59)
    if result.year >= 2400:
        try:
            result = result.replace(year=result.year - 543)
        except ValueError:
            raise ToolError(f"{label} ไม่ถูกต้อง: '{value}'") from None
    return result.replace(second=0)


def _money(amount):
    return f"{float(amount):,.2f}"


def _like(text):
    """ใช้ | เป็นตัว escape กันกรณีชื่อมี % หรือ _"""
    return "%" + str(text).replace("|", "||").replace("%", "|%").replace("_", "|_") + "%"


def _need_branch(ctx):
    if ctx["id_branch"] is None:
        raise ToolError("ตอนนี้เลือก 'ทุกสาขา' อยู่ ให้บอกผู้ใช้เลือกสาขาที่ช่องด้านบนของหน้าแชทก่อน "
                        "แล้วค่อยสั่งเพิ่มหรือลดจำนวนใหม่")
    return ctx["id_branch"]


# =====================================================================
# หาสินค้า / อุปกรณ์ / พนักงาน
# =====================================================================
def _select_items(cur, ctx, kind, where="", args=(), limit=50):
    """สินค้า/อุปกรณ์ของร้าน + จำนวนคงเหลือ (สาขาที่เลือก หรือรวมทุกสาขา)"""
    k = KINDS[kind]
    if ctx["id_branch"] is not None:
        qty_sql = f"(SELECT s.quantity FROM {k['storage']} s WHERE s.{k['iid']} = i.{k['iid']} AND s.id_branch = %s)"
        qty_args = (ctx["id_branch"],)
    else:
        qty_sql = (f"(SELECT SUM(s.quantity) FROM {k['storage']} s JOIN carete_branch cb ON cb.id_branch = s.id_branch "
                   f"WHERE s.{k['iid']} = i.{k['iid']} AND cb.id_business = %s)")
        qty_args = (ctx["id_business"],)
    cur.execute(
        f"""SELECT * FROM (
              SELECT i.{k['iid']} AS id, i.{k['name']} AS name, i.price, i.type, i.details, i.image,
                     {qty_sql} AS quantity
              FROM {k['item']} i JOIN {k['owner']} o ON o.{k['iid']} = i.{k['iid']}
              WHERE o.id_business = %s
            ) x {where} ORDER BY name LIMIT {int(limit)}""",
        (*qty_args, ctx["id_business"], *args),
    )
    return cur.fetchall()


def _view(row):
    """ข้อมูลที่ส่งกลับให้โมเดล — quantity None = ยังไม่มีในสต็อกสาขานี้"""
    return {
        "name": row["name"],
        "quantity": None if row["quantity"] is None else int(row["quantity"]),
        "price": float(row["price"]),
        "type": row["type"],
        "details": row["details"],
        "has_image": bool(row.get("image")),
    }


def _names_like(cur, ctx, kind, name):
    return ", ".join(r["name"] for r in _select_items(cur, ctx, kind, "WHERE name LIKE %s ESCAPE '|'", (_like(name),), 6))


def _find(cur, ctx, kind, item_name):
    """หาจากชื่อ ในร้านนี้เท่านั้น — ชื่อตรงก่อน ไม่เจอค่อยหาแบบมีคำนี้ เจอหลายตัวไม่เดา"""
    label = LABEL[kind]
    if _is_blank(item_name):
        raise ToolError(f"ต้องระบุชื่อ{label}")
    name = str(item_name).strip()
    rows = _select_items(cur, ctx, kind, "WHERE name = %s", (name,), 1)
    if rows:
        return rows[0]
    rows = _select_items(cur, ctx, kind, "WHERE name LIKE %s ESCAPE '|'", (_like(name),), 6)
    if len(rows) == 1:
        return rows[0]
    if not rows:
        other = "equipment" if kind == "product" else "product"
        found = _names_like(cur, ctx, other, name)
        if found:
            raise ToolError(f"ไม่พบ{label}ชื่อ '{name}' แต่มีในรายการ{LABEL[other]}: {found} "
                            f"ถ้าหมายถึง{LABEL[other]} ให้ใช้เครื่องมือของ{LABEL[other]}แทน")
        raise ToolError(f"ไม่พบ{label}ชื่อ '{name}' ในร้าน")
    raise ToolError(f"มี{label}หลายตัวที่ชื่อคล้าย '{name}': {', '.join(r['name'] for r in rows)} "
                    "ให้ถามผู้ใช้ว่าหมายถึงตัวไหน")


def _name_taken(cur, ctx, kind, name, except_id=None):
    rows = _select_items(cur, ctx, kind, "WHERE name = %s", (name,), 1)
    return bool(rows) and rows[0]["id"] != except_id

def list_employees(ctx, cur, keyword=None):
    where = ["cb.id_business = %s"]
    args = [ctx["id_business"]]
    if ctx["id_branch"] is not None:
        where.append("ce.id_branch = %s")
        args.append(ctx["id_branch"])
    if not _is_blank(keyword):
        text = str(keyword).strip()
        conds = ["e.name LIKE %s ESCAPE '|'", "e.position LIKE %s ESCAPE '|'"]
        cond_args = [_like(text), _like(text)]
        if text.isdigit():
            conds.append("e.id_employee = %s")
            cond_args.append(int(text))
        where.append("(" + " OR ".join(conds) + ")")
        args += cond_args
    cur.execute(
        f"""SELECT e.id_employee, e.name, e.position, b.branch_name, e.salary
        FROM employee e
        JOIN carete_employee ce ON ce.id_employee = e.id_employee
        JOIN carete_branch cb ON cb.id_branch = ce.id_branch
        JOIN branch b ON b.id_branch = ce.id_branch
        WHERE {' AND '.join(where)}
        ORDER BY b.branch_name, e.name LIMIT 100""",
        args,
    )
    rows = cur.fetchall()
    return {"ok": True, "branch": ctx["branch_name"], "count": len(rows),
            "note": "ชื่อและตำแหน่งให้ตอบตามค่าในข้อมูลนี้ทุกตัวอักษร ห้ามแปล ทับศัพท์ หรือเปลี่ยนเป็นภาษาอื่น แยกข้อมูลเป็นของใครของมัน",
            "employees": [{"employee_code": r["id_employee"], "name": r["name"], "position": r["position"],
                           "salary": r["salary"], "branch": r["branch_name"]} for r in rows]}
# =====================================================================
# แบบอ่าน
# =====================================================================
def list_products(ctx, cur, keyword=None, low_stock_below=None):
    keyword = None if _is_blank(keyword) else str(keyword).strip()
    low = None if _is_blank(low_stock_below) else _to_int(low_stock_below, "low_stock_below")

    def search(word, below):
        where, args = [], []
        if word is not None:
            where.append("name LIKE %s ESCAPE '|'")
            args.append(_like(word))
        if below is not None:
            where.append("COALESCE(quantity, 0) < %s")
            args.append(below)
        return _select_items(cur, ctx, "product", ("WHERE " + " AND ".join(where)) if where else "", args)

    rows, note = search(keyword, low), None
    # โมเดลชอบใส่เงื่อนไขเกิน ถ้าใส่สองเงื่อนไขแล้วไม่เจอ ลองทีละเงื่อนไขแล้วบอกตรง ๆ
    if not rows and keyword is not None and low is not None:
        rows = search(keyword, None)
        if rows:
            note = f"ไม่มี '{keyword}' ที่เหลือน้อยกว่า {low} ชิ้น รายการนี้คือสินค้าที่ชื่อมีคำว่า '{keyword}' ทั้งหมด"
        else:
            rows = search(None, low)
            if rows:
                note = f"ไม่พบสินค้าที่ชื่อมีคำว่า '{keyword}' รายการนี้คือสินค้าทั้งหมดที่เหลือน้อยกว่า {low} ชิ้น"
    result = {"ok": True, "branch": ctx["branch_name"], "count": len(rows), "products": [_view(r) for r in rows]}
    if note:
        result["note"] = note
    return result


def get_product(ctx, cur, product_name):
    return {"ok": True, "branch": ctx["branch_name"], "product": _view(_find(cur, ctx, "product", product_name))}


def list_equipment(ctx, cur, keyword=None):
    if _is_blank(keyword):
        rows = _select_items(cur, ctx, "equipment")
    else:
        rows = _select_items(cur, ctx, "equipment", "WHERE name LIKE %s ESCAPE '|'", (_like(str(keyword).strip()),))
    return {"ok": True, "branch": ctx["branch_name"], "count": len(rows), "equipment": [_view(r) for r in rows]}


# =====================================================================
# แบบแก้ไข: คืน (ข้อความสรุป, do)
# =====================================================================
def _add_item(ctx, cur, kind, name, price, quantity, type, details):
    label = LABEL[kind]
    k = KINDS[kind]
    if _is_blank(name):
        raise ToolError(f"ต้องระบุชื่อ{label}")
    name = str(name).strip()[:150]
    quantity = _to_qty(quantity)
    item_type = None if _is_blank(type) else str(type).strip()[:50]
    item_details = None if _is_blank(details) else str(details).strip()
    if quantity > 0:
        _need_branch(ctx)
    if _name_taken(cur, ctx, kind, name):
        raise ToolError(f"มี{label}ชื่อ '{name}' อยู่แล้ว ถ้าจะเพิ่มจำนวนของเดิม ให้ปรับจำนวนแทน")

    summary = f"เพิ่ม{label}ใหม่ '{name}' ราคา {_money(price)} บาท"
    if ctx["id_branch"] is not None:
        summary += f"\n  จำนวนเริ่มต้นที่{ctx['branch_name']}: {quantity:,}"
    if item_type:
        summary += f"\n  ประเภท: {item_type}"
    if item_details:
        summary += f"\n  รายละเอียด: {item_details}"

    def do(cur):
        cur.execute(
            f"INSERT INTO {k['item']} ({k['name']}, price, type, details) VALUES (%s, %s, %s, %s)",
            (name, price, item_type, item_details),
        )
        new_id = cur.lastrowid
        cur.execute(f"INSERT INTO {k['owner']} ({k['iid']}, id_business) VALUES (%s, %s)", (new_id, ctx["id_business"]))
        log_edit(cur, ctx["user"], kind, new_id, "create",
                 new={"name": name, "price": price, "type": item_type, "details": item_details, "by": "AI"})
        if ctx["id_branch"] is not None:  # ใส่ในสต็อกของสาขาที่เลือกอยู่ด้วย
            cur.execute(f"INSERT INTO {k['storage']} (id_branch, {k['iid']}, quantity) VALUES (%s, %s, 0)",
                        (ctx["id_branch"], new_id))
            if quantity > 0:
                record_movement(cur, ctx["user"], ctx["id_branch"], "receive", "ยอดตั้งต้น", AI_REASON, None,
                                [{"kind": kind, "id_storage": cur.lastrowid, "quantity": quantity}])
        return {"ok": True, "target_table": k["item"], "target_id": new_id,
                kind: {"name": name, "price": price, "quantity": quantity, "type": item_type, "details": item_details}}

    return summary, do


def add_product(ctx, cur, name, price, quantity=0, type=None, details=None):
    return _add_item(ctx, cur, "product", name, _to_price(price), quantity, type, details)


def add_equipment(ctx, cur, name, quantity=0, price=None, type=None, details=None):
    price = 0 if _is_blank(price) else _to_price(price, "ราคาต่อชิ้น")
    return _add_item(ctx, cur, "equipment", name, price, quantity, type, details)


def edit_product(ctx, cur, product_name, new_name=None, new_price=None, new_type=None, new_details=None):
    p = _find(cur, ctx, "product", product_name)
    changes, old, lines = {}, {}, []   # ชื่อคอลัมน์เรากำหนดเอง ไม่ได้มาจากโมเดล

    if not _is_blank(new_name) and str(new_name).strip() != p["name"]:
        value = str(new_name).strip()[:150]
        if _name_taken(cur, ctx, "product", value, except_id=p["id"]):
            raise ToolError(f"มีสินค้าชื่อ '{value}' อยู่แล้ว")
        changes["name_product"], old["name_product"] = value, p["name"]
        lines.append(f"ชื่อ: {p['name']} → {value}")
    if not _is_blank(new_price):
        value = _to_price(new_price)
        if value != float(p["price"]):
            changes["price"], old["price"] = value, float(p["price"])
            lines.append(f"ราคา: {_money(p['price'])} → {_money(value)} บาท")
    if not _is_blank(new_type) and str(new_type).strip() != (p["type"] or ""):
        value = str(new_type).strip()[:50]
        changes["type"], old["type"] = value, p["type"]
        lines.append(f"ประเภท: {p['type'] or '-'} → {value}")
    if not _is_blank(new_details) and str(new_details).strip() != (p["details"] or ""):
        value = str(new_details).strip()
        changes["details"], old["details"] = value, p["details"]
        lines.append(f"รายละเอียด: {p['details'] or '-'} → {value}")
    if not changes:
        raise ToolError("ไม่มีอะไรให้แก้ ต้องระบุชื่อใหม่ ราคาใหม่ ประเภทใหม่ หรือรายละเอียดใหม่ที่ต่างจากเดิม")

    summary = f"แก้ไขสินค้า '{p['name']}'\n  " + "\n  ".join(lines)

    def do(cur):
        assignments = ", ".join(f"{col} = %s" for col in changes)
        cur.execute(f"UPDATE product SET {assignments} WHERE id_product = %s", (*changes.values(), p["id"]))
        log_edit(cur, ctx["user"], "product", p["id"], "update", old=old, new={**changes, "by": "AI"})
        row = _select_items(cur, ctx, "product", "WHERE id = %s", (p["id"],), 1)[0]
        return {"ok": True, "target_table": "product", "target_id": p["id"], "product": _view(row)}

    return summary, do


def _update_stock(ctx, cur, kind, item_name, change):
    label = LABEL[kind]
    k = KINDS[kind]
    branch = _need_branch(ctx)
    item = _find(cur, ctx, kind, item_name)
    change = _to_int(change, "จำนวนที่เปลี่ยน")
    if change == 0:
        raise ToolError("จำนวนที่เปลี่ยนต้องไม่เป็น 0")
    if abs(change) > MAX_QTY:
        raise ToolError("จำนวนมากเกินไป")
    before = int(item["quantity"] or 0)
    after = before + change
    if after < 0:
        raise ToolError(f"ลดไม่ได้ '{item['name']}' ที่{ctx['branch_name']}เหลือแค่ {before:,} แต่ขอลด {abs(change):,}")
    action = "เพิ่ม" if change > 0 else "ลด"
    summary = (f"{action}{label} '{item['name']}' {abs(change):,} ชิ้น ที่{ctx['branch_name']}\n"
               f"  จาก {before:,} เป็น {after:,}")
    if item["quantity"] is None:
        summary += f"\n  (ยังไม่มีในสต็อกสาขานี้ จะเพิ่มเข้าสต็อกให้)"

    def do(cur):
        cur.execute(f"SELECT {k['sid']} AS sid FROM {k['storage']} WHERE id_branch = %s AND {k['iid']} = %s",
                    (branch, item["id"]))
        row = cur.fetchone()
        if row:
            sid = row["sid"]
        else:
            cur.execute(f"INSERT INTO {k['storage']} (id_branch, {k['iid']}, quantity) VALUES (%s, %s, 0)",
                        (branch, item["id"]))
            sid = cur.lastrowid
        try:
            # เช็กยอดซ้ำตอนทำจริง เผื่อมีคนขายของไประหว่างรอยืนยัน
            res = record_movement(cur, ctx["user"], branch, "receive" if change > 0 else "issue",
                                  AI_REASON, None, None, [{"kind": kind, "id_storage": sid, "quantity": abs(change)}])[0]
        except MovementError as e:
            raise ToolError(str(e)) from None
        return {"ok": True, "target_table": k["storage"], "target_id": sid, "name": item["name"],
                "branch": ctx["branch_name"], "change": change,
                "quantity_before": res["before"], "quantity_after": res["after"]}

    return summary, do


def update_stock(ctx, cur, product_name, change):
    return _update_stock(ctx, cur, "product", product_name, change)


def update_equipment_stock(ctx, cur, equipment_name, change):
    return _update_stock(ctx, cur, "equipment", equipment_name, change)

# ---------- แก้ไขพนักงาน ----------
def _find_employee(cur, ctx, keyword):
    text = "" if _is_blank(keyword) else str(keyword).strip()
    if not text:
        raise ToolError("ต้องระบุชื่อหรือรหัสพนักงาน")
    base = """SELECT e.id_employee, e.name, e.position, e.salary, ce.id_branch, b.branch_name
              FROM employee e
              JOIN carete_employee ce ON ce.id_employee = e.id_employee
              JOIN carete_branch cb ON cb.id_branch = ce.id_branch
              JOIN branch b ON b.id_branch = ce.id_branch
              WHERE cb.id_business = %s"""
    rows = []
    if text.isdigit():
        cur.execute(base + " AND e.id_employee = %s", (ctx["id_business"], int(text)))
        rows = cur.fetchall()
    if not rows:
        cur.execute(base + " AND e.name = %s", (ctx["id_business"], text))
        rows = cur.fetchall()
    if not rows:
        cur.execute(base + " AND e.name LIKE %s ESCAPE '|' LIMIT 6", (ctx["id_business"], _like(text)))
        rows = cur.fetchall()
    if not rows:
        raise ToolError(f"ไม่พบพนักงาน '{text}' ในร้าน")
    if len(rows) > 1:
        raise ToolError("มีพนักงานหลายคนที่ตรงกับ '" + text + "': "
                        + ", ".join(f"{r['name']} (รหัส {r['id_employee']})" for r in rows)
                        + " ให้ถามผู้ใช้ว่าหมายถึงคนไหน หรือให้ใช้รหัสพนักงาน")
    return rows[0]


def edit_employee(ctx, cur, employee_name, new_name=None, new_position=None, new_salary=None, new_branch=None):
    e = _find_employee(cur, ctx, employee_name)
    emp_changes, old, lines = {}, {}, []
    branch_id = None

    if not _is_blank(new_name) and str(new_name).strip() != e["name"]:
        value = str(new_name).strip()[:100]
        emp_changes["name"], old["name"] = value, e["name"]
        lines.append(f"ชื่อ: {e['name']} → {value}")
    if not _is_blank(new_position) and str(new_position).strip() != (e["position"] or ""):
        value = str(new_position).strip()[:50]
        emp_changes["position"], old["position"] = value, e["position"]
        lines.append(f"ตำแหน่ง: {e['position'] or '-'} → {value}")
    if not _is_blank(new_salary):
        value = round(_to_number(new_salary, "เงินเดือน"), 2)
        if value < 0:
            raise ToolError("เงินเดือนห้ามติดลบ")
        if value > MAX_PRICE:
            raise ToolError("เงินเดือนสูงเกินไป")
        before = float(e["salary"] or 0)
        if value != before:
            emp_changes["salary"], old["salary"] = value, before
            lines.append(f"เงินเดือน: {_money(before)} → {_money(value)} บาท")
    if not _is_blank(new_branch) and str(new_branch).strip() != e["branch_name"]:
        cur.execute("""SELECT b.id_branch, b.branch_name FROM branch b
                       JOIN carete_branch cb ON cb.id_branch = b.id_branch
                       WHERE cb.id_business = %s AND b.branch_name = %s LIMIT 1""",
                    (ctx["id_business"], str(new_branch).strip()))
        target = cur.fetchone()
        if not target:
            raise ToolError(f"ไม่พบสาขาชื่อ '{str(new_branch).strip()}' ในร้าน")
        if target["id_branch"] != e["id_branch"]:
            branch_id = target["id_branch"]
            old["id_branch"] = e["id_branch"]
            lines.append(f"สาขา: {e['branch_name']} → {target['branch_name']}")
    if not emp_changes and branch_id is None:
        raise ToolError("ไม่มีอะไรให้แก้ ต้องระบุชื่อใหม่ ตำแหน่งใหม่ เงินเดือนใหม่ หรือสาขาใหม่ที่ต่างจากเดิม")

    summary = f"แก้ไขพนักงาน '{e['name']}' (รหัส {e['id_employee']})\n  " + "\n  ".join(lines)

    def do(cur):
        if emp_changes:
            assignments = ", ".join(f"{col} = %s" for col in emp_changes)
            cur.execute(f"UPDATE employee SET {assignments} WHERE id_employee = %s",
                        (*emp_changes.values(), e["id_employee"]))
        if branch_id is not None:
            cur.execute("UPDATE carete_employee SET id_branch = %s, carete_date = NOW() WHERE id_employee = %s",
                        (branch_id, e["id_employee"]))
        new = {**emp_changes, **({"id_branch": branch_id} if branch_id is not None else {}), "by": "AI"}
        log_edit(cur, {**ctx["user"], "id_branch": e["id_branch"]}, "employee", e["id_employee"], "update",
                 old=old, new=new)
        return {"ok": True, "target_table": "employee", "target_id": e["id_employee"],
                "employee": e["name"], "changes": lines}

    return summary, do

# ---------- รูป ----------
_UPLOAD_PATH = re.compile(r"/uploads/shop_\d+/[A-Za-z0-9_.-]+\.(?:jpe?g|png|webp|gif)", re.I)


def find_image_paths(text):
    return _UPLOAD_PATH.findall(str(text))


def fix_image_path(name, arguments, user_texts):
    """ใช้ที่อยู่รูปตามที่ระบบแนบมาในข้อความผู้ใช้จริง ไม่ใช้ที่โมเดลพิมพ์ต่อ"""
    if name != "set_image":
        return arguments
    found = []
    for text in reversed(list(user_texts)):          # ข้อความล่าสุดก่อน
        found += find_image_paths(text)
    if not found:
        raise ToolError("ผู้ใช้ยังไม่ได้แนบรูป ให้บอกผู้ใช้กดปุ่มแนบรูป (รูปภูเขา) ข้างช่องพิมพ์")
    given = str(arguments.get("image_path") or "")
    return {**arguments, "image_path": given if given in found else found[0]}


def set_image(ctx, cur, item_name, image_path):
    """ใส่หรือเปลี่ยนรูปของสินค้าหรืออุปกรณ์"""
    try:
        kind, item = "product", _find(cur, ctx, "product", item_name)
    except ToolError as e:
        if not str(e).startswith("ไม่พบ"):
            raise
        try:
            kind, item = "equipment", _find(cur, ctx, "equipment", item_name)
        except ToolError as e2:
            if str(e2).startswith("ไม่พบ"):
                raise ToolError(f"ไม่พบสินค้าหรืออุปกรณ์ชื่อ '{str(item_name).strip()}' ในร้าน") from None
            raise
    path = str(image_path or "").strip()
    m = _UPLOAD_PATH.fullmatch(path)
    if not m or not path.startswith(f"/uploads/shop_{int(ctx['id_business'])}/"):
        raise ToolError("ที่อยู่รูปไม่ถูกต้อง ให้ผู้ใช้กดแนบรูปใหม่")
    if not (UPLOAD_DIR / path[len("/uploads/"):]).is_file():
        raise ToolError("หาไฟล์รูปไม่เจอ ให้ผู้ใช้กดแนบรูปใหม่")
    k = KINDS[kind]
    summary = f"ใส่รูปให้{LABEL[kind]} '{item['name']}'"
    if item.get("image"):
        summary += "\n  (แทนรูปเดิม)"

    def do(cur):
        cur.execute(f"UPDATE {k['item']} SET image = %s WHERE {k['iid']} = %s", (path, item["id"]))
        log_edit(cur, ctx["user"], kind, item["id"], "update", old={"image": item.get("image")}, new={"image": path, "by": "AI"})
        return {"ok": True, "target_table": k["item"], "target_id": item["id"], "name": item["name"], "image": path}

    return summary, do

# ---------- โปรโมชัน ----------
_DISCOUNT_TYPES = {
    "percent": "percent", "%": "percent", "percentage": "percent", "เปอร์เซ็นต์": "percent",
    "amount": "amount", "baht": "amount", "บาท": "amount",
}


def _active_promotions(cur, ctx, id_product=None):
    """โปรที่เปิดอยู่และยังไม่หมดเวลา"""
    sql = """SELECT p.id_product, p.name, p.end_date FROM promotions p
             JOIN carete_promotions cp ON cp.id_promotions = p.id_promotions
             WHERE cp.id_business = %s AND p.status = 'active' AND p.end_date >= NOW()"""
    args = [ctx["id_business"]]
    if id_product is not None:
        sql += " AND p.id_product = %s"
        args.append(id_product)
    cur.execute(sql, args)
    return cur.fetchall()


def _promo_label(row):
    return f"โปร '{row['name']}' (ถึง {str(row['end_date'])[:10]})"


def create_promotion(ctx, cur, product_name, promotion_name, discount_type, discount_value, start_date, end_date):
    p = _find(cur, ctx, "product", product_name)
    if _is_blank(promotion_name):
        raise ToolError("ต้องระบุชื่อโปรโมชั่น")
    promotion_name = str(promotion_name).strip()[:150]
    kind = _DISCOUNT_TYPES.get(str(discount_type or "").strip().lower())
    if kind is None:
        raise ToolError("discount_type ต้องเป็น 'percent' (ลดเป็นเปอร์เซ็นต์) หรือ 'amount' (ลดเป็นบาท)")
    value = round(_to_number(discount_value, "ส่วนลด"), 2)
    price = float(p["price"])
    if value <= 0:
        raise ToolError("ส่วนลดต้องมากกว่า 0")
    if kind == "percent":
        if value > 100:
            raise ToolError("ส่วนลดแบบเปอร์เซ็นต์ห้ามเกิน 100")
        price_after = round(price * (1 - value / 100), 2)
        discount_text = f"ลด {value:g}%"
    else:
        if value > price:
            raise ToolError(f"ส่วนลด {_money(value)} บาท มากกว่าราคาสินค้า ({_money(price)} บาท)")
        price_after = round(price - value, 2)
        discount_text = f"ลด {_money(value)} บาท"
    start = _to_datetime(start_date, "วันเริ่ม")
    end = _to_datetime(end_date, "วันสิ้นสุด", end_of_day=True)
    if end <= start:
        raise ToolError("วันสิ้นสุดต้องอยู่หลังวันเริ่ม")
    if end < datetime.datetime.now():
        raise ToolError(f"วันสิ้นสุด {end:%Y-%m-%d} ผ่านมาแล้ว ให้เช็กปีและวันที่อีกครั้ง")

    summary = (f"สร้างโปรโมชั่น '{promotion_name}' สำหรับ '{p['name']}'\n"
               f"  {discount_text}: ราคา {_money(price)} → {_money(price_after)} บาท\n"
               f"  ช่วงเวลา: {start:%Y-%m-%d} ถึง {end:%Y-%m-%d}\n"
               f"  สถานะ: เปิดใช้ทันที (ลดราคาตอนขายเมื่อถึงวันเริ่ม)")
    for row in _active_promotions(cur, ctx, p["id"]):
        summary += f"\n  หมายเหตุ: สินค้านี้มี{_promo_label(row)} เปิดอยู่แล้ว"

    def do(cur):
        cur.execute(
            """INSERT INTO promotions (id_product, name, discount_type, discount_value, start_date, end_date, status)
               VALUES (%s, %s, %s, %s, %s, %s, 'active')""",
            (p["id"], promotion_name, kind, value, start, end),
        )
        new_id = cur.lastrowid
        cur.execute("INSERT INTO carete_promotions (id_promotions, id_business) VALUES (%s, %s)", (new_id, ctx["id_business"]))
        log_edit(cur, ctx["user"], "promotions", new_id, "create",
                 new={"name": promotion_name, "product": p["name"], "discount_type": kind, "discount_value": value,
                      "start_date": f"{start:%Y-%m-%d %H:%M}", "end_date": f"{end:%Y-%m-%d %H:%M}",
                      "status": "active", "by": "AI"})
        return {"ok": True, "target_table": "promotions", "target_id": new_id, "promotion_name": promotion_name,
                "product": p["name"], "discount_type": kind, "discount_value": value,
                "price_before": price, "price_after": price_after,
                "start_date": f"{start:%Y-%m-%d}", "end_date": f"{end:%Y-%m-%d}", "status": "เปิดใช้แล้ว"}

    return summary, do


# ---------- ช่วยคิดโปร ----------
SALES_WINDOW_DAYS = 30        # ดูยอดขายย้อนหลังกี่วัน
SLOW_COVER_DAYS = 60          # ถ้าขายเท่าเดิมต้องใช้เกินกี่วันกว่าของจะหมด ถือว่าขายช้า
MIN_QUANTITY = 5              # ของเหลือน้อยกว่านี้ไม่ต้องทำโปร
DISCOUNT_CHOICES = (5, 10, 15)


def suggest_promotions(ctx, cur, product_name=None):
    """แนะนำสินค้าที่น่าทำโปร ไม่ได้สร้างโปร (ดูของรวมทุกสาขาของร้าน)"""
    all_ctx = {**ctx, "id_branch": None}
    named = not _is_blank(product_name)
    if named:
        products = [_find(cur, all_ctx, "product", product_name)]
    else:
        products = [p for p in _select_items(cur, all_ctx, "product", limit=500) if (p["quantity"] or 0) > 0]

    since = datetime.datetime.now() - datetime.timedelta(days=SALES_WINDOW_DAYS)
    cur.execute(
        """SELECT sp.id_product, SUM(bi.volume) AS sold
           FROM bill_item bi
           JOIN bill b ON b.id_bill = bi.id_bill
           JOIN carete_branch cb ON cb.id_branch = b.id_branch
           JOIN storage_product sp ON sp.id_storage_product = bi.id_storage_product
           WHERE cb.id_business = %s AND b.sell_date >= %s
           GROUP BY sp.id_product""",
        (ctx["id_business"], since),
    )
    sales = {r["id_product"]: int(r["sold"] or 0) for r in cur.fetchall()}
    sales_known = sum(sales.values()) > 0
    busy = {r["id_product"]: _promo_label(r) for r in _active_promotions(cur, ctx)}

    quantities = sorted(int(p["quantity"] or 0) for p in products) or [0]
    median = quantities[len(quantities) // 2]
    suggestions, skipped = [], []
    for p in products:
        quantity, price = int(p["quantity"] or 0), float(p["price"])
        if p["id"] in busy and not named:
            skipped.append(f"{p['name']} (มี{busy[p['id']]} อยู่แล้ว)")
            continue
        sold = sales.get(p["id"], 0) if sales_known else None
        if named:
            reason = "ผู้ใช้เลือกสินค้านี้เอง"
        elif quantity < MIN_QUANTITY:
            continue
        elif sales_known:
            if sold == 0:
                reason = f"{SALES_WINDOW_DAYS} วันที่ผ่านมาขายไม่ได้เลย แต่ยังมีของ {quantity:,} ชิ้น"
            else:
                cover_days = round(quantity / (sold / SALES_WINDOW_DAYS))
                if cover_days < SLOW_COVER_DAYS:
                    continue
                reason = (f"{SALES_WINDOW_DAYS} วันที่ผ่านมาขายได้ {sold:,} ชิ้น แต่มีของ {quantity:,} ชิ้น "
                          f"ถ้าขายเท่าเดิมต้องใช้ประมาณ {cover_days:,} วันกว่าจะหมด")
        else:
            if quantity <= median or quantity < 20:
                continue
            reason = f"มีของ {quantity:,} ชิ้น เยอะกว่าสินค้าส่วนใหญ่ในร้าน"
        suggestions.append({
            "product": p["name"], "quantity": quantity, "price": price,
            "sold_last_30_days": sold, "stock_value": round(quantity * price, 2), "reason": reason,
            "discount_options": [{"percent": pct, "price_after": round(price * (1 - pct / 100), 2)}
                                 for pct in DISCOUNT_CHOICES] if price > 0 else [],
            **({"existing_promotion": busy[p["id"]]} if p["id"] in busy else {}),
        })
    suggestions.sort(key=lambda x: x["stock_value"], reverse=True)   # เงินจมในสต็อกมากสุดก่อน
    result = {
        "ok": True,
        "based_on": (f"ยอดขาย {SALES_WINDOW_DAYS} วันล่าสุดเทียบกับของที่มี (รวมทุกสาขา)" if sales_known
                     else "จำนวนของในสต็อกอย่างเดียว เพราะยังไม่มีข้อมูลการขาย"),
        "suggestions": suggestions[:5],
        "note": ("นี่เป็นแค่คำแนะนำ ยังไม่ได้สร้างโปร ให้ผู้ใช้เลือกสินค้า ส่วนลด วันเริ่ม และวันสิ้นสุดเอง "
                 "ระบบไม่รู้ต้นทุนสินค้า ให้ผู้ใช้เช็กว่าลดแล้วยังมีกำไร"),
    }
    if skipped:
        result["already_has_promotion"] = skipped
    if not suggestions:
        result["message"] = "ตอนนี้ยังไม่มีสินค้าที่น่าทำโปร"
    return result


# =====================================================================
# กันโมเดลแต่งค่าเอง (เหมือนเวอร์ชันเก่า)
# =====================================================================
USER_DECIDED = {
    "add_product": {"price": "ราคา", "quantity": "จำนวน"},
    "add_equipment": {"price": "ราคา", "quantity": "จำนวน"},
    "edit_product": {"new_price": "ราคาใหม่"},
    "create_promotion": {"discount_value": "ส่วนลด", "start_date": "วันเริ่ม", "end_date": "วันสิ้นสุด"},
    "edit_employee": {"new_salary": "เงินเดือนใหม่"},
}
_NUMBER_IN_TEXT = re.compile(r"\d+(?:,\d{3})*(?:\.\d+)?")
_DATE_IN_TEXT = re.compile(r"(\d{4})-(\d{1,2})-(\d{1,2})")


def check_user_said(name, arguments, user_texts, today=None):
    """ค่าที่ผู้ใช้ต้องตัดสินใจเอง ต้องมีอยู่ในสิ่งที่ผู้ใช้พิมพ์มาจริง"""
    fields = USER_DECIDED.get(name)
    if not fields:
        return
    today = today or datetime.date.today()
    text = " ".join(user_texts)
    numbers = {float(n.replace(",", "")) for n in _NUMBER_IN_TEXT.findall(text)}
    if "โหล" in text:
        numbers |= {n * 12 for n in numbers} | {12.0}
    dates = set()
    for year, month, day in _DATE_IN_TEXT.findall(text):
        year = int(year) - 543 if int(year) >= 2400 else int(year)
        try:
            dates.add(datetime.date(year, int(month), int(day)))
        except ValueError:
            pass
    month_end = today.replace(day=calendar.monthrange(today.year, today.month)[1])
    relative = {"วันนี้": today, "พรุ่งนี้": today + datetime.timedelta(days=1),
                "มะรืน": today + datetime.timedelta(days=2), "สิ้นเดือน": month_end}
    dates |= {d for word, d in relative.items() if word in text}

    missing = []
    for field, label in fields.items():
        value = arguments.get(field)
        if _is_blank(value):
            continue
        if field.endswith("_date"):
            try:
                day = _to_datetime(value, label).date()
            except ToolError:
                continue
            if day not in dates and float(day.day) not in numbers:
                missing.append(label)
        else:
            try:
                number = float(str(value).replace(",", "").strip())
            except ValueError:
                continue
            if field == "quantity" and number == 0:
                continue
            if number not in numbers:
                missing.append(label)
    if missing:
        raise ToolError(f"ผู้ใช้ยังไม่ได้บอก{' '.join(missing)} ห้ามใส่ค่าเอง ให้ถามผู้ใช้ก่อน")


DETAIL_FIELDS = {
    "add_product": ("details", "name"),
    "edit_product": ("new_details", "product_name"),
    "add_equipment": ("details", "name"),
}


def fix_details(name, arguments, user_texts):
    """รายละเอียดต้องเป็นข้อความที่ผู้ใช้พิมพ์จริงครบทุกคำ"""
    if name not in DETAIL_FIELDS or not user_texts:
        return arguments
    detail_key, item_key = DETAIL_FIELDS[name]
    value = arguments.get(detail_key)
    if _is_blank(value):
        return arguments
    value = " ".join(str(value).split())
    item = str(arguments.get(item_key) or "")
    for text in reversed([" ".join(str(t).split()) for t in user_texts]):
        start = text.find(value)
        if start < 0:
            continue
        word_start = text.rfind(" ", 0, start) + 1
        prefix = text[word_start:start]
        if len(prefix) >= 2 and prefix in item:
            value = prefix + value
        return {**arguments, detail_key: value}
    raise ToolError("รายละเอียดต้องเป็นข้อความที่ผู้ใช้พิมพ์มาครบทุกคำ ห้ามตัด ห้ามย่อ ห้ามแต่งเพิ่ม "
                    "ให้คัดลอกส่วนที่ผู้ใช้บอกว่าเป็นรายละเอียดมาใส่ใหม่")


# =====================================================================
# ทะเบียนเครื่องมือ + คำอธิบายที่ส่งให้โมเดล
# =====================================================================
READ_TOOLS = {
    "list_products": list_products,
    "get_product": get_product,
    "list_equipment": list_equipment,
    "suggest_promotions": suggest_promotions,
    "list_employees": list_employees,
}
WRITE_TOOLS = {
    "add_product": add_product,
    "edit_product": edit_product,
    "update_stock": update_stock,
    "create_promotion": create_promotion,
    "update_equipment_stock": update_equipment_stock,
    "add_equipment": add_equipment,
    "set_image": set_image,
    "edit_employee": edit_employee,
}


def check_arguments(function, arguments):
    """ชื่อค่าต้องครบและไม่มีชื่อแปลกปลอม ก่อนเรียกฟังก์ชันจริง"""
    if not isinstance(arguments, dict):
        raise ToolError("ค่าที่ส่งมาต้องเป็นชุดของชื่อกับค่า")
    allowed = [n for n in inspect.signature(function).parameters if n not in ("ctx", "cur")]
    unknown = [n for n in arguments if n not in allowed]
    if unknown:
        raise ToolError(f"ไม่รู้จักค่า {', '.join(unknown)} ค่าที่ใช้ได้คือ {', '.join(allowed)}")
    try:
        inspect.signature(function).bind(None, None, **arguments)
    except TypeError:
        raise ToolError(f"ส่งค่ามาไม่ครบ ค่าที่ใช้ได้คือ {', '.join(allowed)}") from None


def _tool(name, description, properties, required):
    return {"type": "function", "function": {
        "name": name, "description": description,
        "parameters": {"type": "object", "properties": properties, "required": required}}}


CONFIRM_NOTE = " เรียกได้ทันทีเมื่อข้อมูลครบ ระบบจะถามผู้ใช้ยืนยันก่อนบันทึกเอง ไม่ต้องถามผู้ใช้ก่อน"
PRODUCT_NAME = {"type": "string", "description": "ชื่อหรือคำที่ผู้ใช้ใช้เรียกสินค้า เช่น โค้ก ไม่ต้องเป็นชื่อเต็ม ใส่แค่ชื่อสินค้า"}
DETAILS = "คัดลอกข้อความที่ผู้ใช้พิมพ์มาครบทุกคำ แม้จะซ้ำกับชื่อสินค้า ห้ามตัด ห้ามย่อ ห้ามแต่งเพิ่ม"

TOOL_SCHEMAS = [
    _tool("suggest_promotions",
          "ช่วยคิดว่าควรทำโปรโมชั่นให้สินค้าตัวไหน โดยดูจากยอดขายและของที่เหลือ ใช้เมื่อผู้ใช้ขอให้ช่วยคิดโปร"
          " หรือถามว่าควรทำโปรอะไรดี เครื่องมือนี้ไม่ได้สร้างโปร ให้เล่าสินค้าที่แนะนำ เหตุผล และราคาหลังลด"
          " ตามที่เครื่องมือให้มา แล้วถามผู้ใช้ว่าจะเอาตัวไหน ลดเท่าไหร่ เริ่มและจบวันไหน",
          {"product_name": {"type": "string", "description": "ใส่เฉพาะเมื่อผู้ใช้ระบุสินค้ามาแล้ว ถ้าให้คิดทั้งร้านไม่ต้องใส่"}},
          []),
    _tool("list_products",
          "ดูรายการสินค้าในร้านพร้อมจำนวนคงเหลือ (ของสาขาที่เลือกอยู่) และราคา ใช้เมื่อผู้ใช้ถามภาพรวม หรืออยากรู้ว่าสินค้าไหนใกล้หมด"
          " quantity เป็น null แปลว่าสาขานี้ยังไม่มีสินค้านี้ในสต็อก",
          {"keyword": {"type": "string", "description": "ชื่อสินค้าที่จะค้น ใส่แค่ชื่อ เช่น ขนมปัง ไม่ใส่คือดูทั้งหมด"},
           "low_stock_below": {"type": "integer", "description": "ใส่เฉพาะตอนผู้ใช้ถามหาของใกล้หมด จะแสดงเฉพาะสินค้าที่เหลือน้อยกว่าจำนวนนี้"}},
          []),
    _tool("get_product",
          "ดูข้อมูลสินค้าหนึ่งตัว: จำนวนคงเหลือ ราคา ประเภท ใช้เมื่อผู้ใช้ถามว่าสินค้าเหลือเท่าไหร่ หรือราคาเท่าไหร่",
          {"product_name": PRODUCT_NAME}, ["product_name"]),
    _tool("add_product",
          "เพิ่มสินค้าใหม่ที่ยังไม่เคยมีในร้าน ต้องรู้ชื่อและราคาจากผู้ใช้ก่อน ถ้าผู้ใช้ยังไม่บอกราคา ห้ามเรียก ให้ถามผู้ใช้" + CONFIRM_NOTE,
          {"name": {"type": "string", "description": "ชื่อสินค้าใหม่"},
           "price": {"type": "number", "description": "ราคาขายต่อชิ้น หน่วยบาท ต้องเป็นราคาที่ผู้ใช้บอกเท่านั้น ห้ามเดา"},
           "quantity": {"type": "integer", "description": "จำนวนเริ่มต้น ไม่ใส่คือ 0"},
           "type": {"type": "string", "description": "ประเภทสินค้า เช่น เครื่องดื่ม"},
           "details": {"type": "string", "description": "รายละเอียดเพิ่มเติม " + DETAILS}},
          ["name", "price"]),
    _tool("edit_product",
          "แก้ชื่อ ราคาขาย ประเภท หรือรายละเอียดของสินค้าที่มีอยู่แล้ว เช่น ขึ้นราคา เปลี่ยนชื่อ ใส่หรือเพิ่มรายละเอียด"
          " (ผู้ใช้พูดว่า เพิ่มรายละเอียด ก็ใช้ตัวนี้ ไม่ใช่เพิ่มสินค้าใหม่) ใส่เฉพาะค่าที่ต้องการเปลี่ยน"
          " ห้ามใช้แก้จำนวน ให้ใช้ update_stock แทน" + CONFIRM_NOTE,
          {"product_name": PRODUCT_NAME,
           "new_name": {"type": "string", "description": "ชื่อใหม่"},
           "new_price": {"type": "number", "description": "ราคาใหม่ หน่วยบาท"},
           "new_type": {"type": "string", "description": "ประเภทใหม่"},
           "new_details": {"type": "string", "description": "รายละเอียดใหม่ " + DETAILS}},
          ["product_name"]),
    _tool("update_stock",
          "เพิ่มหรือลดจำนวนสินค้าในสต็อกของสาขาที่เลือกอยู่ ของเข้าใส่เลขบวก ส่วนขายไป เอาออก ตัดออก ของเสีย หรือหมดอายุ ใส่เลขลบ" + CONFIRM_NOTE,
          {"product_name": PRODUCT_NAME,
           "change": {"type": "integer", "description": "จำนวนที่เปลี่ยน เช่น 24 คือเพิ่ม 24 ชิ้น, -5 คือลด 5 ชิ้น"}},
          ["product_name", "change"]),
    _tool("create_promotion",
          "สร้างโปรโมชั่นลดราคาให้สินค้าหนึ่งตัว พอผู้ใช้ยืนยันแล้วโปรจะเปิดใช้ทันที "
          "ส่วนลดและวันที่ต้องมาจากผู้ใช้เท่านั้น" + CONFIRM_NOTE,
          {"product_name": PRODUCT_NAME,
           "promotion_name": {"type": "string", "description": "ชื่อโปรโมชั่น"},
           "discount_type": {"type": "string", "enum": ["percent", "amount"],
                             "description": "percent คือลดเป็นเปอร์เซ็นต์, amount คือลดเป็นบาท"},
           "discount_value": {"type": "number", "description": "ตัวเลขส่วนลด เช่น 10"},
           "start_date": {"type": "string", "description": "วันเริ่ม รูปแบบ YYYY-MM-DD"},
           "end_date": {"type": "string", "description": "วันสิ้นสุด รูปแบบ YYYY-MM-DD"}},
          ["product_name", "promotion_name", "discount_type", "discount_value", "start_date", "end_date"]),
    _tool("list_equipment",
          "ดูรายการอุปกรณ์ของร้านพร้อมจำนวนคงเหลือ อุปกรณ์คือของที่ร้านใช้เองแต่ไม่ได้ขาย เช่น แก้ว หลอด ถุง "
          "ใช้เมื่อผู้ใช้ถามถึงอุปกรณ์ หรือค้นในสินค้าแล้วไม่เจอ",
          {"keyword": {"type": "string", "description": "ชื่ออุปกรณ์ที่จะค้น ใส่แค่ชื่อ เช่น หลอด ไม่ใส่คือดูทั้งหมด"}},
          []),
    _tool("update_equipment_stock",
          "เพิ่มหรือลดจำนวนอุปกรณ์ของสาขาที่เลือกอยู่ อุปกรณ์คือของที่ร้านใช้เองแต่ไม่ได้ขาย เช่น แก้ว หลอด ถุง"
          " ของเข้าใส่เลขบวก ใช้ไป เสีย หรือทิ้ง ใส่เลขลบ ห้ามใช้กับสินค้าที่ขาย ให้ใช้ update_stock แทน" + CONFIRM_NOTE,
          {"equipment_name": {"type": "string", "description": "ชื่อหรือคำที่ผู้ใช้ใช้เรียกอุปกรณ์ เช่น หลอด ไม่ต้องเป็นชื่อเต็ม"},
           "change": {"type": "integer", "description": "จำนวนที่เปลี่ยน เช่น 100 คือเพิ่ม 100 ชิ้น, -20 คือลด 20 ชิ้น"}},
          ["equipment_name", "change"]),
    _tool("add_equipment",
          "เพิ่มอุปกรณ์ใหม่ที่ยังไม่เคยมีในร้าน อุปกรณ์คือของที่ร้านใช้เองแต่ไม่ได้ขาย เช่น แก้ว หลอด ถุง ไม่ต้องมีราคาก็ได้" + CONFIRM_NOTE,
          {"name": {"type": "string", "description": "ชื่ออุปกรณ์ใหม่"},
           "quantity": {"type": "integer", "description": "จำนวนเริ่มต้น ไม่ใส่คือ 0"},
           "price": {"type": "number", "description": "ราคาต่อชิ้น หน่วยบาท ใส่เฉพาะเมื่อผู้ใช้บอก ห้ามเดา"},
           "type": {"type": "string", "description": "ประเภท เช่น บรรจุภัณฑ์"},
           "details": {"type": "string", "description": "รายละเอียดเพิ่มเติม " + DETAILS}},
          ["name"]),
    _tool("list_employees",
          "ค้นหาพนักงานในสาขาที่เลือกอยู่ (ถ้าเลือกทุกสาขาจะแสดงทุกสาขา) พร้อมรหัสพนักงาน ตำแหน่ง เงินเดือน และชื่อสาขา"
          " ใช้เมื่อผู้ใช้ถามว่ามีพนักงานใครบ้าง หรือถามข้อมูลพนักงานจากชื่อ รหัสพนักงาน หรือตำแหน่ง"
          " ตำแหน่งต้องตอบตามค่าที่เครื่องมือให้มาเท่านั้น ห้ามแปลเป็นภาษาไทย",
          {"keyword": {"type": "string", "description": "ชื่อ ตำแหน่ง หรือรหัสพนักงาน (ตัวเลข) ที่จะค้น เช่น สมชาย, cashier, 1 ไม่ใส่คือดูทั้งหมด"}},
          []),
    _tool("set_image",
          "ใส่หรือเปลี่ยนรูปของสินค้าหรืออุปกรณ์ที่มีอยู่แล้ว ใช้ได้เมื่อข้อความผู้ใช้มีที่อยู่รูป /uploads/... แล้วเท่านั้น"
          " ถ้ายังไม่มี ให้บอกผู้ใช้กดปุ่มแนบรูปข้างช่องพิมพ์ คุณมองไม่เห็นรูป จึงห้ามบรรยายว่าในรูปมีอะไร" + CONFIRM_NOTE,
          {"item_name": {"type": "string", "description": "ชื่อสินค้าหรืออุปกรณ์ที่จะใส่รูป เช่น โค้ก ไม่ต้องเป็นชื่อเต็ม"},
           "image_path": {"type": "string", "description": "ที่อยู่รูปที่ขึ้นต้นด้วย /uploads/ ตามที่อยู่ในข้อความผู้ใช้ ห้ามแต่งเอง"}},
          ["item_name", "image_path"]),
    _tool("edit_employee",
          "แก้ข้อมูลพนักงานที่มีอยู่แล้ว เช่น เปลี่ยนชื่อ เปลี่ยนตำแหน่ง ปรับเงินเดือน หรือย้ายไปสาขาอื่น"
          " ใส่เฉพาะค่าที่ต้องการเปลี่ยน ห้ามแก้รหัสล็อกอินหรือรหัสผ่าน"
          " ตำแหน่งและเงินเดือนต้องมาจากผู้ใช้เท่านั้น" + CONFIRM_NOTE,
          {"employee_name": {"type": "string", "description": "ชื่อหรือรหัสพนักงาน (ตัวเลข) ที่จะแก้"},
           "new_name": {"type": "string", "description": "ชื่อใหม่"},
           "new_position": {"type": "string", "description": "ตำแหน่งใหม่ ตามที่ผู้ใช้บอก"},
           "new_salary": {"type": "number", "description": "เงินเดือนใหม่ หน่วยบาทต่อเดือน ต้องเป็นตัวเลขที่ผู้ใช้บอกเท่านั้น ห้ามเดา"},
           "new_branch": {"type": "string", "description": "ชื่อสาขาใหม่ที่จะย้ายพนักงานไป"}},
          ["employee_name"]),
]
