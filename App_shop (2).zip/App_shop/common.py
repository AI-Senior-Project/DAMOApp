"""ของที่ใช้ร่วมกันหลายไฟล์ (app.py, stock.py, movement.py)"""
from fastapi import Request
from fastapi.responses import JSONResponse

# ชื่อตาราง/คอลัมน์ของแต่ละประเภท — ใส่ชื่อตารางลง SQL ได้เฉพาะจาก dict นี้เท่านั้น
# (ห้ามเอาข้อความที่ผู้ใช้ส่งมาไปต่อเป็นชื่อตารางตรงๆ)
KINDS = {
    "product": {
        "item": "product", "iid": "id_product", "name": "name_product",
        "owner": "carete_product",                       # สินค้า ↔ ร้าน
        "storage": "storage_product", "sid": "id_storage_product",
        "tx": "transaction_product", "txid": "id_transaction_product",
    },
    "equipment": {
        "item": "equipment", "iid": "id_equipment", "name": "name_equipment",
        "owner": "carete_equipment",
        "storage": "storage_equipment", "sid": "id_storage_equipment",
        "tx": "transaction_equipment", "txid": "id_transaction_equipment",
    },
}

MAX_QTY = 1_000_000


def error(message: str, status: int = 400):
    return JSONResponse({"ok": False, "message": message}, status_code=status)


def get_login(request: Request):
    """คนที่ล็อกอินอยู่ (ยังไม่สนว่าเลือกร้านหรือยัง) — session เวอร์ชันเก่าที่ไม่มี id_branch = ยังไม่ล็อกอิน"""
    user = request.session.get("user")
    if not user or "id_branch" not in user:
        return None
    return user


def get_user(request: Request):
    """คนที่ล็อกอินแล้ว + มีร้านที่กำลังใช้งาน (เจ้าของต้องเลือกร้านที่หน้า /brands ก่อน)"""
    user = get_login(request)
    if not user or user.get("id_business") is None:
        return None
    return user


def resolve_branch(cur, user, requested):
    """
    คืนค่า (id_branch, error)
      พนักงาน → บังคับเป็นสาขาตัวเองเสมอ ไม่สนค่าที่ส่งมา
      เจ้าของ  → ไม่ระบุ = สาขาที่เลือกไว้ / "all" = ทุกสาขา / ถ้าระบุเลขมา ต้องเป็นสาขาในร้านตัวเอง
    """
    if user["role"] == "employee":
        return user["id_branch"], None
    if requested is None or requested == "":
        return user.get("id_branch"), None   # ไม่ได้ระบุ → ใช้สาขาที่เลือกไว้ตอนเข้า (None = ทุกสาขา)
    if requested == "all":
        return None, None
    try:
        branch_id = int(requested)
    except (TypeError, ValueError):
        return None, "สาขาไม่ถูกต้อง"
    cur.execute(
        "SELECT 1 FROM carete_branch WHERE id_branch = %s AND id_business = %s",
        (branch_id, user["id_business"]),
    )
    if not cur.fetchone():
        return None, "ไม่พบสาขานี้ในร้านของคุณ"
    return branch_id, None
