"""
API ของหน้าภาพรวมร้าน (แดชบอร์ด) — ใช้ได้เฉพาะเจ้าของร้าน
  GET /api/dashboard?date_from=&date_to=&store=all|<id_branch>

ส่งกลับทีเดียวทั้งหน้า:
  summary / previous  ยอดช่วงนี้ + ช่วงก่อนหน้าที่ยาวเท่ากัน (ไว้คำนวณ % เพิ่ม/ลด)
  by_day              ยอดรายวัน (ช่วงนี้ + ช่วงก่อนหน้า วางเทียบวันต่อวัน)
  by_branch           เทียบแต่ละสาขา: ยอดขาย บิล พนักงาน ของใกล้หมด/ใกล้หมดอายุ
  by_hour             ยอดขายตามชั่วโมง (ดูช่วงเวลาขายดี)
  top / slow          สินค้าขายดี / ของค้างสต็อกที่ไม่ขายเลยในช่วงนี้
  by_pay / by_seller  แยกตามวิธีจ่าย / คนขาย
  alerts              ของใกล้หมด หมดอายุ ใกล้หมดอายุ
  extra               โปรที่เปิดอยู่ งานที่ AI ทำ
"""
from datetime import date, timedelta
from decimal import Decimal

from fastapi import APIRouter, Request

from common import error, resolve_branch
from config import LOW_STOCK_LIMIT
from db import get_db
from products import get_owner
from sell import PAY_TYPES

router = APIRouter()

EXPIRE_SOON_DAYS = 7


def f(x):
    return float(x) if isinstance(x, Decimal) else (x or 0)


def pct(now, before):
    if not before:
        return None   # ช่วงก่อนไม่มียอด เทียบ % ไม่ได้
    return round((now - before) / before * 100, 1)


@router.get("/api/dashboard")
def dashboard(request: Request, date_from: date | None = None, date_to: date | None = None, store: str = "all"):
    user = get_owner(request)
    if not user:
        return error("หน้านี้สำหรับเจ้าของร้านเท่านั้น", 401)
    date_to = date_to or date.today()
    date_from = date_from or date_to - timedelta(days=6)
    if date_from > date_to:
        return error("วันเริ่มต้องไม่อยู่หลังวันสิ้นสุด")
    days = (date_to - date_from).days + 1
    if days > 366:
        return error("ดูได้ครั้งละไม่เกิน 1 ปี")
    prev_from = date_from - timedelta(days=days)
    biz = user["id_business"]

    with get_db() as conn, conn.cursor() as cur:
        branch_id, err = resolve_branch(cur, user, store)
        if err:
            return error(err)
        bsql = " AND b.id_branch = %s" if branch_id else ""
        barg = (branch_id,) if branch_id else ()
        bill_where = f"""FROM bill b JOIN carete_branch cb ON cb.id_branch = b.id_branch
                         WHERE cb.id_business = %s AND b.sell_date >= %s AND b.sell_date < %s{bsql}"""

        def period(a, z):
            return (biz, a, z + timedelta(days=1)) + barg

        # ---------- สรุป ช่วงนี้ / ช่วงก่อน ----------
        def summary(a, z):
            cur.execute(f"""SELECT COUNT(*) AS bills, COALESCE(SUM(b.total_price),0) AS total,
                                   COALESCE(SUM(b.discount),0) AS discount,
                                   COALESCE(SUM((SELECT SUM(volume) FROM bill_item bi WHERE bi.id_bill = b.id_bill)),0) AS items
                            {bill_where}""", period(a, z))
            r = cur.fetchone()
            total = f(r["total"])
            return {"bills": r["bills"], "total": total, "discount": f(r["discount"]), "items": int(f(r["items"])),
                    "avg": round(total / r["bills"], 2) if r["bills"] else 0}

        now_s = summary(date_from, date_to)
        prev_s = summary(prev_from, date_from - timedelta(days=1))
        change = {k: pct(now_s[k], prev_s[k]) for k in ("total", "bills", "avg", "items")}

        # ---------- รายวัน ----------
        def per_day(a, z):
            cur.execute(f"SELECT DATE(b.sell_date) AS d, COUNT(*) AS n, SUM(b.total_price) AS t {bill_where} GROUP BY DATE(b.sell_date)",
                        period(a, z))
            return {r["d"]: (r["n"], f(r["t"])) for r in cur.fetchall()}
        cur_days, prev_days = per_day(date_from, date_to), per_day(prev_from, date_from - timedelta(days=1))
        by_day = []
        for i in range(days):
            d, pd = date_from + timedelta(days=i), prev_from + timedelta(days=i)
            n, t = cur_days.get(d, (0, 0))
            by_day.append({"date": d.strftime("%d/%m"), "bills": n, "total": t,
                           "prev_date": pd.strftime("%d/%m"), "prev_total": prev_days.get(pd, (0, 0))[1]})

        # ---------- ตามชั่วโมง ----------
        cur.execute(f"SELECT HOUR(b.sell_date) AS h, COUNT(*) AS n, SUM(b.total_price) AS t {bill_where} GROUP BY HOUR(b.sell_date)",
                    period(date_from, date_to))
        hours = {r["h"]: (r["n"], f(r["t"])) for r in cur.fetchall()}
        by_hour = [{"hour": h, "bills": hours.get(h, (0, 0))[0], "total": hours.get(h, (0, 0))[1]} for h in range(24)]

        # ---------- เทียบสาขา ----------
        cur.execute(
            f"""SELECT br.id_branch AS id, br.branch_name AS name,
                  (SELECT COUNT(*) FROM bill b WHERE b.id_branch = br.id_branch AND b.sell_date >= %s AND b.sell_date < %s) AS bills,
                  (SELECT COALESCE(SUM(b.total_price),0) FROM bill b WHERE b.id_branch = br.id_branch AND b.sell_date >= %s AND b.sell_date < %s) AS total,
                  (SELECT COALESCE(SUM(b.total_price),0) FROM bill b WHERE b.id_branch = br.id_branch AND b.sell_date >= %s AND b.sell_date < %s) AS prev_total,
                  (SELECT COUNT(*) FROM carete_employee ce WHERE ce.id_branch = br.id_branch) AS employees,
                  (SELECT COUNT(*) FROM storage_product s WHERE s.id_branch = br.id_branch AND s.quantity <= %s)
                + (SELECT COUNT(*) FROM storage_equipment s WHERE s.id_branch = br.id_branch AND s.quantity <= %s) AS low_stock,
                  (SELECT COUNT(*) FROM storage_product s WHERE s.id_branch = br.id_branch AND s.quantity > 0
                     AND s.exp_date IS NOT NULL AND s.exp_date <= CURDATE() + INTERVAL %s DAY) AS expiring
                FROM branch br JOIN carete_branch cb ON cb.id_branch = br.id_branch
                WHERE cb.id_business = %s ORDER BY br.id_branch""",
            (date_from, date_to + timedelta(days=1), date_from, date_to + timedelta(days=1),
             prev_from, date_from, LOW_STOCK_LIMIT, LOW_STOCK_LIMIT, EXPIRE_SOON_DAYS, biz),
        )
        by_branch = []
        for r in cur.fetchall():
            t = f(r["total"])
            by_branch.append({"id": r["id"], "name": r["name"], "bills": r["bills"], "total": t,
                              "avg": round(t / r["bills"], 2) if r["bills"] else 0,
                              "change": pct(t, f(r["prev_total"])), "employees": r["employees"],
                              "low_stock": int(r["low_stock"]), "expiring": int(r["expiring"])})

        # ---------- สินค้าขายดี ----------
        cur.execute(
            f"""SELECT p.id_product AS id, p.name_product AS name, SUM(bi.volume) AS qty, SUM(bi.volume * bi.price) AS total
                FROM bill_item bi
                JOIN storage_product sp ON sp.id_storage_product = bi.id_storage_product
                JOIN product p ON p.id_product = sp.id_product
                WHERE bi.id_bill IN (SELECT b.id_bill {bill_where})
                GROUP BY p.id_product, p.name_product ORDER BY total DESC LIMIT 6""",
            period(date_from, date_to),
        )
        top = [{"name": r["name"], "qty": int(r["qty"]), "total": f(r["total"])} for r in cur.fetchall()]

        # ---------- ของค้างสต็อก: มีของ แต่ไม่ขายเลยในช่วงนี้ ----------
        ssql = " AND s.id_branch = %s" if branch_id else ""
        cur.execute(
            f"""SELECT p.name_product AS name, SUM(s.quantity) AS qty, SUM(s.quantity) * p.price AS value
                FROM storage_product s
                JOIN product p ON p.id_product = s.id_product
                JOIN carete_branch cb ON cb.id_branch = s.id_branch
                WHERE cb.id_business = %s AND s.quantity > 0{ssql}
                  AND NOT EXISTS (SELECT 1 FROM bill_item bi JOIN bill b ON b.id_bill = bi.id_bill
                                  JOIN storage_product s2 ON s2.id_storage_product = bi.id_storage_product
                                  WHERE s2.id_product = p.id_product AND b.sell_date >= %s AND b.sell_date < %s)
                GROUP BY p.id_product, p.name_product, p.price ORDER BY value DESC LIMIT 5""",
            (biz,) + barg + (date_from, date_to + timedelta(days=1)),
        )
        slow = [{"name": r["name"], "qty": int(r["qty"]), "value": f(r["value"])} for r in cur.fetchall()]

        # ---------- วิธีจ่าย / คนขาย ----------
        cur.execute(f"SELECT b.type_pay, COUNT(*) AS n, SUM(b.total_price) AS t {bill_where} GROUP BY b.type_pay ORDER BY t DESC",
                    period(date_from, date_to))
        by_pay = [{"label": PAY_TYPES.get(r["type_pay"], r["type_pay"]), "bills": r["n"], "total": f(r["t"])} for r in cur.fetchall()]
        cur.execute(
            f"""SELECT COALESCE(e.name, 'เจ้าของร้าน') AS name, COUNT(*) AS n, SUM(b.total_price) AS t
                FROM bill b JOIN carete_branch cb ON cb.id_branch = b.id_branch
                LEFT JOIN employee e ON e.id_employee = b.id_employee
                WHERE cb.id_business = %s AND b.sell_date >= %s AND b.sell_date < %s{bsql}
                GROUP BY b.id_employee, e.name ORDER BY t DESC LIMIT 8""",
            period(date_from, date_to),
        )
        by_seller = [{"name": r["name"], "bills": r["n"], "total": f(r["t"])} for r in cur.fetchall()]

        # ---------- เรื่องที่ต้องดู ----------
        alerts = []
        for kind, k_item, k_iid, k_name, k_storage in (
            ("สินค้า", "product", "id_product", "name_product", "storage_product"),
            ("อุปกรณ์", "equipment", "id_equipment", "name_equipment", "storage_equipment"),
        ):
            cur.execute(
                f"""SELECT i.{k_name} AS name, br.branch_name AS branch, s.quantity, s.exp_date,
                           DATEDIFF(s.exp_date, CURDATE()) AS days_left
                    FROM {k_storage} s
                    JOIN {k_item} i ON i.{k_iid} = s.{k_iid}
                    JOIN branch br ON br.id_branch = s.id_branch
                    JOIN carete_branch cb ON cb.id_branch = s.id_branch
                    WHERE cb.id_business = %s{ssql}
                      AND (s.quantity <= %s OR (s.quantity > 0 AND s.exp_date IS NOT NULL AND s.exp_date <= CURDATE() + INTERVAL %s DAY))
                    ORDER BY s.quantity, s.exp_date LIMIT 30""",
                (biz,) + barg + (LOW_STOCK_LIMIT, EXPIRE_SOON_DAYS),
            )
            for r in cur.fetchall():
                dl = r["days_left"]
                if r["quantity"] > 0 and dl is not None and dl < 0:
                    level, text = "critical", f"หมดอายุแล้ว {-dl} วัน (เหลือ {r['quantity']})"
                elif r["quantity"] <= 0:
                    level, text = "critical", "ของหมด"
                elif r["quantity"] > 0 and dl is not None and dl <= EXPIRE_SOON_DAYS:
                    level, text = "warning", ("หมดอายุวันนี้" if dl == 0 else f"หมดอายุใน {dl} วัน") + f" (เหลือ {r['quantity']})"
                else:
                    level, text = "warning", f"ใกล้หมด เหลือ {r['quantity']}"
                alerts.append({"kind": kind, "name": r["name"], "branch": r["branch"], "level": level, "text": text})
        alerts.sort(key=lambda a: a["level"] != "critical")

        # ---------- อื่น ๆ ----------
        cur.execute(
            """SELECT COUNT(*) AS n FROM promotions p JOIN carete_promotions cp ON cp.id_promotions = p.id_promotions
               WHERE cp.id_business = %s AND p.status = 'active' AND NOW() BETWEEN p.start_date AND p.end_date""",
            (biz,),
        )
        promos = cur.fetchone()["n"]
        cur.execute(
            """SELECT COUNT(*) AS n FROM ai_action_log a
               JOIN message_box m ON m.id_message = a.id_message
               JOIN conversation c ON c.id_conversation = m.id_conversation
               WHERE c.id_business = %s AND a.status = 'success' AND a.created_date >= %s AND a.created_date < %s""",
            (biz, date_from, date_to + timedelta(days=1)),
        )
        ai_done = cur.fetchone()["n"]
        cur.execute("SELECT name_brand FROM business WHERE id_business = %s", (biz,))
        brand = cur.fetchone()["name_brand"]

    return {
        "ok": True, "brand": brand, "branch_id": branch_id,
        "date_from": date_from.isoformat(), "date_to": date_to.isoformat(),
        "prev_from": prev_from.strftime("%d/%m"), "prev_to": (date_from - timedelta(days=1)).strftime("%d/%m"),
        "summary": now_s, "previous": prev_s, "change": change,
        "by_day": by_day, "by_hour": by_hour, "by_branch": by_branch,
        "top": top, "slow": slow, "by_pay": by_pay, "by_seller": by_seller,
        "alerts": alerts[:12], "alerts_total": len(alerts),
        "extra": {"promotions": promos, "ai_done": ai_done},
    }
