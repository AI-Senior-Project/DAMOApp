"""
API ของหน้าเลือกร้าน (Brand) — ใช้ได้เฉพาะเจ้าของร้าน
  GET  /api/brands          ร้านทั้งหมดของเจ้าของคนนี้
  GET  /api/brands/{id}/branches   สาขาของร้านนั้น (ขั้นที่ 2: เลือกสาขา)
  POST /api/brands/{id}/branches   เพิ่มสาขาใหม่ให้ร้านนั้น
  POST /api/brands/select   เลือกร้าน + สาขาที่จะใช้งาน (เก็บลง session)
  POST /api/brands          เพิ่มร้านใหม่
"""
import json

from fastapi import Request
from fastapi import APIRouter
from pydantic import BaseModel

from common import error, get_login
from db import get_db

router = APIRouter()


def get_owner(request: Request):
    user = get_login(request)
    if not user or user["role"] != "owner":
        return None
    return user


@router.get("/api/brands")
def list_brands(request: Request):
    user = get_owner(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบด้วยบัญชีเจ้าของร้าน", 401)
    with get_db() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT b.id_business, b.name_brand, b.name_model, b.logo_brand,
                      (SELECT COUNT(*) FROM carete_branch cb WHERE cb.id_business = b.id_business) AS branches,
                      (SELECT COUNT(*) FROM carete_product cp WHERE cp.id_business = b.id_business) AS products
               FROM business b
               WHERE b.id_user = %s
               ORDER BY b.id_business""",
            (user["id"],),
        )
        rows = cur.fetchall()
    return {"ok": True, "name": user["name"], "current": user.get("id_business"), "brands": rows}


def owns_brand(cur, user, id_business):
    cur.execute(
        "SELECT name_brand FROM business WHERE id_business = %s AND id_user = %s",
        (id_business, user["id"]),
    )
    return cur.fetchone()


@router.get("/api/brands/{id_business}/branches")
def list_branches(id_business: int, request: Request):
    user = get_owner(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบด้วยบัญชีเจ้าของร้าน", 401)
    with get_db() as conn, conn.cursor() as cur:
        brand = owns_brand(cur, user, id_business)
        if not brand:
            return error("ไม่พบร้านนี้ในบัญชีของคุณ", 404)
        cur.execute(
            """SELECT b.id_branch, b.branch_name, b.location,
                      (SELECT COUNT(*) FROM carete_employee ce WHERE ce.id_branch = b.id_branch) AS employees
               FROM branch b JOIN carete_branch cb ON cb.id_branch = b.id_branch
               WHERE cb.id_business = %s ORDER BY b.id_branch""",
            (id_business,),
        )
        rows = cur.fetchall()
    return {
        "ok": True,
        "brand": brand["name_brand"],
        "current": user.get("id_branch") if user.get("id_business") == id_business else None,
        "branches": rows,
    }


class NewBranchBody(BaseModel):
    branch_name: str
    location: str = ""


@router.post("/api/brands/{id_business}/branches")
def create_branch(id_business: int, body: NewBranchBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบด้วยบัญชีเจ้าของร้าน", 401)
    name = body.branch_name.strip()[:100]
    location = body.location.strip()[:255] or None
    if not name:
        return error("กรุณาใส่ชื่อสาขา")
    with get_db() as conn, conn.cursor() as cur:
        if not owns_brand(cur, user, id_business):
            return error("ไม่พบร้านนี้ในบัญชีของคุณ", 404)
        cur.execute("INSERT INTO branch (branch_name, location) VALUES (%s, %s)", (name, location))
        new_id = cur.lastrowid
        cur.execute("INSERT INTO carete_branch (id_branch, id_business) VALUES (%s, %s)", (new_id, id_business))
        cur.execute(
            """INSERT INTO history_transaction_user (id_branch, target_table, target_id, action, new_value)
               VALUES (%s, 'branch', %s, 'create', %s)""",
            (new_id, new_id, json.dumps({"branch_name": name, "location": location}, ensure_ascii=False)),
        )
        conn.commit()
    return {"ok": True, "id_branch": new_id}


class SelectBody(BaseModel):
    id_business: int
    id_branch: int | None = None   # None = ทุกสาขา


@router.post("/api/brands/select")
def select_brand(body: SelectBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบด้วยบัญชีเจ้าของร้าน", 401)
    with get_db() as conn, conn.cursor() as cur:
        # ร้านต้องเป็นของเจ้าของคนนี้ และสาขาต้องอยู่ในร้านนั้น
        if not owns_brand(cur, user, body.id_business):
            return error("ไม่พบร้านนี้ในบัญชีของคุณ", 404)
        if body.id_branch is not None:
            cur.execute(
                "SELECT 1 FROM carete_branch WHERE id_branch = %s AND id_business = %s",
                (body.id_branch, body.id_business),
            )
            if not cur.fetchone():
                return error("ไม่พบสาขานี้ในร้าน", 404)
    # ต้องแทนค่า dict ใหม่ทั้งก้อน session ถึงจะถูกบันทึก
    request.session["user"] = {**user, "id_business": body.id_business, "id_branch": body.id_branch}
    return {"ok": True}


class NewBrandBody(BaseModel):
    name_brand: str
    name_model: str = ""


@router.post("/api/brands")
def create_brand(body: NewBrandBody, request: Request):
    user = get_owner(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบด้วยบัญชีเจ้าของร้าน", 401)
    name_brand = body.name_brand.strip()[:100]
    name_model = (body.name_model.strip() or "ร้านค้า")[:100]
    if not name_brand:
        return error("กรุณาใส่ชื่อร้าน")

    with get_db() as conn, conn.cursor() as cur:
        cur.execute(
            "INSERT INTO business (id_user, name_model, name_brand) VALUES (%s, %s, %s)",
            (user["id"], name_model, name_brand),
        )
        new_id = cur.lastrowid
        # บันทึกประวัติการแก้ไขข้อมูลของเจ้าของร้าน
        cur.execute(
            """INSERT INTO history_transaction_user (id_branch, target_table, target_id, action, new_value)
               VALUES (NULL, 'business', %s, 'create', %s)""",
            (new_id, json.dumps({"name_brand": name_brand, "name_model": name_model}, ensure_ascii=False)),
        )
        conn.commit()
    return {"ok": True, "id_business": new_id}
