"""
API ของหน้าขายสินค้า — ใช้ได้ทั้งเจ้าของร้านและพนักงาน
  GET  /api/sell/items?store=   สินค้าในสต็อกของสาขา + ราคาหลังโปร
  POST /api/sell                ออกบิล + ตัดสต็อก (ทั้งหมดใน transaction เดียว)

ราคา/โปรคำนวณใหม่ที่ฝั่งเซิร์ฟเวอร์เสมอ (ไม่เชื่อราคาที่หน้าเว็บส่งมา)
  bill_item.price  = ราคาต่อชิ้นหลังหักโปร (ราคาที่ลูกค้าจ่ายจริง)
  bill.discount    = ส่วนลดรวมทั้งบิล
  bill.total_price = ยอดสุทธิ
  bill.id_promotions = โปรที่ให้ส่วนลดมากที่สุดในบิล (บิลมีช่องเก็บได้ 1 โปร)
ตัดสต็อกผ่าน record_movement() แบบ "เบิกออก" เหตุผล "ขาย" อ้างอิงเลขบิล
"""
from decimal import ROUND_HALF_UP, Decimal

from fastapi import APIRouter, Request
from pydantic import BaseModel

from common import MAX_QTY, error, get_user, resolve_branch
from db import get_db
from movement import MovementError, record_movement

router = APIRouter()

PAY_TYPES = {"cash": "เงินสด", "transfer": "โอน", "qr": "QR พร้อมเพย์", "card": "บัตร", "other": "อื่นๆ"}
MAX_LINES = 50
CENT = Decimal("0.01")


def money(x):
    return Decimal(x).quantize(CENT, rounding=ROUND_HALF_UP)


def best_promos(cur, id_business, product_ids):
    """โปรที่ใช้ได้ตอนนี้ของสินค้าแต่ละตัว → {id_product: [promo, ...]}"""
    if not product_ids:
        return {}
    marks = ",".join(["%s"] * len(product_ids))
    cur.execute(
        f"""SELECT p.id_promotions AS id, p.id_product, p.name, p.discount_type, p.discount_value
            FROM promotions p JOIN carete_promotions cp ON cp.id_promotions = p.id_promotions
            WHERE cp.id_business = %s AND p.status = 'active'
              AND NOW() BETWEEN p.start_date AND p.end_date
              AND p.id_product IN ({marks})""",
        (id_business, *product_ids),
    )
    out = {}
    for r in cur.fetchall():
        out.setdefault(r["id_product"], []).append(r)
    return out


def apply_promo(price: Decimal, promos):
    """เลือกโปรที่ลดได้มากที่สุด → (ราคาหลังลด, โปร หรือ None)"""
    best, best_price = None, price
    for p in promos or []:
        v = Decimal(p["discount_value"])
        cut = price * v / 100 if p["discount_type"] == "percent" else v
        new_price = max(money(price - cut), Decimal("0"))
        if new_price < best_price:
            best, best_price = p, new_price
    return best_price, best


def pick_branch(cur, user, store):
    branch_id, err = resolve_branch(cur, user, store)
    if err:
        return None, err
    if branch_id is None:
        return None, "กรุณาเลือกสาขาที่จะขาย"
    return branch_id, None


# -----------------------------------------------------------------
# รายการสินค้าที่ขายได้
# -----------------------------------------------------------------
@router.get("/api/sell/items")
def sell_items(request: Request, store: str | None = None):
    user = get_user(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบ", 401)
    with get_db() as conn, conn.cursor() as cur:
        branch_id, err = pick_branch(cur, user, store)
        if err:
            return error(err)
        cur.execute(
            """SELECT s.id_storage_product AS id_storage, p.id_product, p.name_product AS name, p.image, p.type,
                      p.price, s.quantity, s.exp_date, DATEDIFF(s.exp_date, CURDATE()) AS days_left
               FROM storage_product s JOIN product p ON p.id_product = s.id_product
               WHERE s.id_branch = %s
               ORDER BY p.type, p.name_product""",
            (branch_id,),
        )
        rows = cur.fetchall()
        promos = best_promos(cur, user["id_business"], [r["id_product"] for r in rows])
    for r in rows:
        price = money(r["price"])
        sale, promo = apply_promo(price, promos.get(r["id_product"]))
        r["price"] = float(price)
        r["sale_price"] = float(sale)
        r["promo"] = promo["name"] if promo else None
        r["exp_date"] = r["exp_date"].strftime("%d/%m/%Y") if r["exp_date"] else None
    return {"ok": True, "id_branch": branch_id, "items": rows, "pay_types": PAY_TYPES}


# -----------------------------------------------------------------
# ออกบิล
# -----------------------------------------------------------------
class SellLine(BaseModel):
    id_storage: int
    quantity: int


class SellBody(BaseModel):
    id_store: int | None = None
    type_pay: str = "cash"
    received: float | None = None   # เงินที่รับมา (เงินสด) ไว้คำนวณเงินทอน
    lines: list[SellLine]


@router.post("/api/sell")
def create_bill(body: SellBody, request: Request):
    user = get_user(request)
    if not user:
        return error("กรุณาเข้าสู่ระบบ", 401)
    if body.type_pay not in PAY_TYPES:
        return error("วิธีจ่ายเงินไม่ถูกต้อง")
    if not body.lines:
        return error("ยังไม่มีสินค้าในบิล")
    if len(body.lines) > MAX_LINES:
        return error(f"ใส่ได้ไม่เกิน {MAX_LINES} รายการต่อบิล")
    ids = [ln.id_storage for ln in body.lines]
    if len(set(ids)) != len(ids):
        return error("มีสินค้าซ้ำกัน ให้รวมเป็นบรรทัดเดียว")
    if any(not (0 < ln.quantity <= MAX_QTY) for ln in body.lines):
        return error("จำนวนต้องมากกว่า 0")

    with get_db() as conn, conn.cursor() as cur:
        branch_id, err = pick_branch(cur, user, body.id_store)
        if err:
            return error(err)

        # ราคาจริงจาก DB (สินค้าต้องอยู่ในสต็อกของสาขานี้)
        marks = ",".join(["%s"] * len(ids))
        cur.execute(
            f"""SELECT s.id_storage_product AS id_storage, p.id_product, p.name_product AS name, p.price
                FROM storage_product s JOIN product p ON p.id_product = s.id_product
                WHERE s.id_branch = %s AND s.id_storage_product IN ({marks})""",
            (branch_id, *ids),
        )
        info = {r["id_storage"]: r for r in cur.fetchall()}
        if len(info) != len(ids):
            return error("มีสินค้าที่ไม่อยู่ในสต็อกของสาขานี้ ลองรีเฟรชหน้า")
        promos = best_promos(cur, user["id_business"], list({r["id_product"] for r in info.values()}))

        lines, subtotal, total = [], Decimal("0"), Decimal("0")
        promo_cut = {}  # id โปร → ส่วนลดรวม
        for ln in body.lines:
            r = info[ln.id_storage]
            price = money(r["price"])
            sale, promo = apply_promo(price, promos.get(r["id_product"]))
            subtotal += price * ln.quantity
            total += sale * ln.quantity
            if promo:
                promo_cut[promo["id"]] = promo_cut.get(promo["id"], 0) + (price - sale) * ln.quantity
            lines.append({"id_storage": ln.id_storage, "name": r["name"], "quantity": ln.quantity,
                          "price": price, "sale_price": sale, "promo": promo["name"] if promo else None})
        discount = subtotal - total
        main_promo = max(promo_cut, key=promo_cut.get) if promo_cut else None

        change = None
        if body.type_pay == "cash" and body.received is not None:
            received = money(body.received)
            if received < total:
                return error(f"รับเงินมาไม่พอ (ยอด ฿{total:,.2f})")
            change = received - total

        id_employee = user["id"] if user["role"] == "employee" else None
        cur.execute(
            """INSERT INTO bill (id_employee, id_branch, total_price, discount, id_promotions, type_pay)
               VALUES (%s, %s, %s, %s, %s, %s)""",
            (id_employee, branch_id, total, discount, main_promo, body.type_pay),
        )
        bill_id = cur.lastrowid
        cur.executemany(
            "INSERT INTO bill_item (id_bill, id_storage_product, volume, price) VALUES (%s, %s, %s, %s)",
            [(bill_id, ln["id_storage"], ln["quantity"], ln["sale_price"]) for ln in lines],
        )
        try:
            record_movement(
                cur, user, branch_id, "issue", "ขาย", None, f"BILL-{bill_id}",
                [{"kind": "product", "id_storage": ln["id_storage"], "quantity": ln["quantity"]} for ln in lines],
            )
        except MovementError as e:
            conn.rollback()  # ของไม่พอ → ยกเลิกทั้งบิล
            return error(str(e))
        cur.execute("SELECT sell_date FROM bill WHERE id_bill = %s", (bill_id,))
        sell_date = cur.fetchone()["sell_date"]
        cur.execute("SELECT branch_name FROM branch WHERE id_branch = %s", (branch_id,))
        branch_name = cur.fetchone()["branch_name"]
        conn.commit()

    return {
        "ok": True,
        "bill": {
            "id": bill_id,
            "no": f"BILL-{bill_id}",
            "branch": branch_name,
            "seller": user["name"],
            "date": sell_date.strftime("%d/%m/%Y %H:%M"),
            "type_pay": PAY_TYPES[body.type_pay],
            "lines": [{**ln, "price": float(ln["price"]), "sale_price": float(ln["sale_price"]),
                       "amount": float(ln["sale_price"] * ln["quantity"])} for ln in lines],
            "subtotal": float(subtotal),
            "discount": float(discount),
            "total": float(total),
            "received": float(body.received) if change is not None else None,
            "change": float(change) if change is not None else None,
        },
    }
