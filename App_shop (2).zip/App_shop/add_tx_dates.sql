-- ให้ประวัติ รับเข้า/เบิกออก เก็บวันผลิต / วันหมดอายุ ที่ตั้งในแต่ละรายการ
-- รันครั้งเดียว (ข้อมูลเดิมไม่หาย)
USE ai_end;
ALTER TABLE transaction_product
  ADD COLUMN mfg_date DATE NULL AFTER reference_no,
  ADD COLUMN exp_date DATE NULL AFTER mfg_date;
ALTER TABLE transaction_equipment
  ADD COLUMN mfg_date DATE NULL AFTER reference_no,
  ADD COLUMN exp_date DATE NULL AFTER mfg_date;
